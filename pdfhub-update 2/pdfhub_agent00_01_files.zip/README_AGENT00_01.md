# PDF Hub Agent 00 + Agent 01 Files

These files were generated as a patch payload, not committed directly to GitHub.

## Agent 00

- `docs/IMPLEMENTATION_PLAN_REDESIGN.md`
- `docs/OPERATION_CONTRACT.md`
- `docs/AGENT_WORK_OWNERSHIP.md`
- `docs/REDESIGN_GAP_REGISTER.md`
- `docs/PERFORMANCE_BENCHMARKS.md`
- `frontend/src/core/commands/types.ts`
- `frontend/src/core/commands/registry.ts`
- `frontend/src/core/commands/store.ts`
- `frontend/src/core/commands/history.ts`
- `frontend/src/core/commands/validators.ts`

## Agent 01

- `frontend/src/core/editor/types.ts`
- `frontend/src/core/editor/store.ts`
- `frontend/src/components/shell/AppShell.tsx`
- `frontend/src/components/shell/TopNav.tsx`
- `frontend/src/components/shell/ToolbarBand.tsx`
- `frontend/src/components/shell/LeftRail.tsx`
- `frontend/src/components/shell/SidebarPanel.tsx`
- `frontend/src/components/shell/DocumentWorkspace.tsx`
- `frontend/src/components/shell/InspectorPanel.tsx`
- `frontend/src/components/shell/StatusBar.tsx`

Copy the folder contents into the repository root.
