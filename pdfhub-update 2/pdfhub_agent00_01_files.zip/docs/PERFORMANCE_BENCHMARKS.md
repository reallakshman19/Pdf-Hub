# Performance Benchmarks

## Current risks

- Full PDF bytes loaded before first page.
- Page dimensions are not guaranteed before render.
- Fast scroll may show blank canvases.
- Text layer parsing can repeat unnecessarily.
- Thumbnail generation can saturate the UI thread.

## Target metrics

### Time to first page

- Small PDF: under 500 ms.
- 100-page text PDF: under 1.5 s.
- Large remote PDF with range streaming: under 2 s to first page.

### Layout stability

- No visible page height jump after page metrics are loaded.
- Scroll-to-page remains accurate.

### Memory

- Visible pages plus limited cache only.
- Default PDF page proxy cache size: 8 pages.
- Thumbnail render concurrency: max 2.

### Text layer

- Text items cached by document key, page number and scale bucket.
- Search does not re-parse every page repeatedly.

## Required implementation

- Page metrics prefetch.
- LRU page cache.
- Render cancellation.
- Thumbnail queue.
- Range streaming in server mode.
