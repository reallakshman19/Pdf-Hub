# Agent Work Ownership

## Agent 00 – Contract owner

Owns:

- `docs/IMPLEMENTATION_PLAN_REDESIGN.md`
- `docs/OPERATION_CONTRACT.md`
- `docs/AGENT_WORK_OWNERSHIP.md`
- `docs/REDESIGN_GAP_REGISTER.md`
- `docs/PERFORMANCE_BENCHMARKS.md`
- `frontend/src/core/commands/*`

Pass gates:

- Command types compile.
- Destructive commands are explicitly marked.
- AI and macro commands cannot bypass the command model.

## Agent 01 – Shell and mode UX

Owns:

- `frontend/src/components/shell/*`
- `frontend/src/components/toolbar/*`
- `frontend/src/core/editor/*`

Pass gates:

- Six modes exist.
- Toolbar content changes by mode.
- Unsupported tools are disabled, not faked.
- Write mode does not claim true PDF text editing.
- Redaction apply is not exposed until backend redaction exists.

## Agent 02 – Viewer and performance

Owns viewer, page metrics, render cache and text layer.

## Agent 03 – Write overlay

Owns overlay writing tools.

## Agent 04 – Organize and thumbnails

Owns page selection, thumbnails and page operations.

## Agent 05 – OCR

Owns OCR queue, OCR store and OCR UI.

## Agent 06 – Inspector, search and bookmarks

Owns inspector tabs, unified search and bookmarks.

## Agent 07 – Generate and macros

Owns AI command planning and macro execution.

## Agent 08 – Redaction

Owns preview/apply redaction.

## Agent 09 – QA and benchmark

Owns verification and performance tests.
