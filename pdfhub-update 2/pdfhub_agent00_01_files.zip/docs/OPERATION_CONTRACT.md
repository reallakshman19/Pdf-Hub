# Operation Contract

This contract governs all PDF Hub / DocCraft actions.

## Command structure

Each command includes:

- `id`
- `type`
- `source`
- `risk`
- `createdAt`
- `documentKey`
- `payload`

## Lifecycle

```text
create
validate
preview if destructive
confirm if required
execute
record history
persist/save/export
```

## Risk levels

- `safe`
- `destructive-preview-required`
- `destructive-confirm-required`
- `server-only`

## Invariants

- Commands must be JSON serializable.
- Validators must not mutate the document.
- Destructive operations require preview or confirmation.
- AI/macro operations must still create normal commands.
- Redaction preview is not final redaction.
- Write overlay is not true existing-text editing.

## Extension rule

New commands must extend `PdfCommandBase` and be added to the `PdfCommand` union.
