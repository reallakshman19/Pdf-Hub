# Redesign Gap Register

This document records the major gaps between the envisioned PDF Hub / DocCraft workbench and the implementation state reviewed during the redesign audit.

## 1. Write mode ambiguity

The design includes a rich Write toolbar with font selection, alignment, tables, images and links. Without clear scoping this can mislead users into believing the application provides full word-processor-style editing. True editing of PDF content streams is technically complex and risky.

### Gaps

- Lack of separation between overlay writing, PDF content editing and new document authoring.
- No UI warning that overlay writing does not modify existing PDF text.
- No stable writer overlay data model.
- No command boundary between adding an overlay and destructively rewriting a PDF.

### Required work

1. Implement separate scopes for overlay writing, advanced content edit and document authoring.
2. Add clear labels and warnings to communicate scope.
3. Persist overlay objects separately from the base document until commit/export.
4. Map every write operation to a command.

### Acceptance gates

- UI says “add text overlay”, not “edit PDF text”, until true content editing exists.
- Text box, image, table and link overlays are stored as objects.
- Save/export can flatten overlays into a PDF.
- Undo/redo works for overlay create/update/delete.

## 2. High-risk redaction

Redaction cannot be implemented as a simple black rectangle overlay. A redaction tool must permanently remove underlying text, images, annotations and OCR text from the final PDF.

### Gaps

- No preview/apply workflow for redaction.
- No audit logging or verification of removed content.
- No safe default to force saving as a new file.
- No text-search verification after apply.

### Required work

1. Implement `REDACTION_PREVIEW` and `REDACTION_APPLY` commands.
2. Require destructive confirmation before final apply.
3. Use backend PDF rewrite logic to remove text, images, annotations and OCR text.
4. Produce an audit report describing what was removed.
5. Save as a new file by default.

### Acceptance gates

- Black rectangle overlay cannot be exported as final redaction.
- Apply requires explicit confirmation.
- Search cannot find redacted native text or OCR text.
- Audit report is produced.

## 3. Organize mode and thumbnails

The design calls for robust page manipulation: insert, delete, duplicate, rotate, replace, merge, extract and split. For professional PDF work this panel must support multi-selection and drag/drop interactions.

### Gaps

- No professional thumbnail component or page selection model.
- No multi-select, shift-select or ctrl/cmd-select support.
- No drag-reorder or visual insertion markers.
- No preview before destructive page operations.

### Required work

1. Create a thumbnail panel with badges for page labels, sizes, rotation, annotations and OCR status.
2. Implement range selection and additive selection.
3. Add drag/drop reordering and cross-document merge/drop support.
4. Route all operations through `PAGES_ORGANIZE` commands.
5. Add undo/redo for page operations.

### Acceptance gates

- Single select works.
- Shift range select works.
- Ctrl/Cmd toggle select works.
- Multi-page drag reorder works.
- External PDF drop creates insert/merge preview.
- Delete/replace/split require preview confirmation.

## 4. OCR workflow

The design mentions Auto OCR and Region OCR but leaves many workflow details undefined. Scanned books often have hundreds of pages and OCR must be resumable, inspectable and searchable.

### Gaps

- No OCR queue or per-page status display.
- No language selection.
- No searchable text-layer toggle.
- No confidence metrics or OCR debug view.
- No equation correction workflow.
- No failure recovery for large documents.

### Required work

1. Introduce an OCR store and progress panel.
2. Provide language selection and page-range selection.
3. Allow re-OCR on selected pages or selected regions.
4. Render OCR results with confidence indicators.
5. Preserve partial results and recover failed jobs.
6. Commit searchable OCR text only through a command.

### Acceptance gates

- OCR job queue shows progress.
- Each page shows OCR status.
- Failed pages can be retried.
- Low-confidence pages are visible.
- OCR text can be searched.
- OCR text can be exported.

## 5. AI / Generate guardrails

Generate mode includes macros, smart fill, Ask AI and other powerful tools. Without guardrails, these features could unexpectedly mutate documents.

### Gaps

- No infrastructure for generated command plans.
- No diff preview for AI-generated operations.
- No validation layer for AI-proposed changes.
- No audit history showing source = ai.

### Required work

1. Require every AI suggestion to produce command JSON.
2. Validate proposed commands before preview.
3. Show a diff/impact preview.
4. Require user confirmation before mutation.
5. Record all executed AI commands in history.

### Acceptance gates

- AI never mutates the PDF directly.
- Invalid command plans are rejected.
- User confirmation is required.
- Undo works after applying AI-generated commands.
- History shows the AI source and exact commands.
