# Implementation Plan – DocCraft Redesign

This document converts the PDF Hub redesign into a phased implementation plan. The redesign should be treated as a PDF workbench architecture, not only a UI theme.

## Core doctrine

Every user-visible operation must pass through a command contract.

```text
UI intent
  -> validated command object
  -> preview/diff if destructive
  -> execute command
  -> update document/session state
  -> mark dirty
  -> write undo/redo entry
  -> save/export pipeline
```

## Wave 0 – Contract and documentation

- Add command model.
- Add command registry.
- Add history stack.
- Add validators.
- Add redesign gap register.
- Add performance benchmarks.
- Add agent ownership document.

## Wave 1 – Foundation shell

- Top navigation.
- Mode tabs.
- Contextual toolbar.
- Left rail.
- Sidebar.
- Document workspace.
- Right inspector.
- Status bar.

Mode list:

```text
view
annotate
draw
write
organize
generate
```

Unavailable features must be disabled and honestly labelled.

## Wave 2 – Viewer and performance

- PDF.js worker configuration.
- Page metrics prefetch.
- Virtualized rendering.
- LRU page cache.
- Render cancellation.
- Text layer cache.
- Thumbnail queue.

## Wave 3 – Command history

- Dispatch commands through registry.
- Add undo/redo.
- Add dirty-state tracking.
- Add destructive preview hooks.

## Wave 4 – Write overlay

- Text box overlay.
- Image overlay.
- Table overlay.
- Link overlay.
- Flatten/export pipeline.

Do not claim true PDF text editing until content stream editing exists.

## Wave 5 – Organize

- Multi-select thumbnails.
- Shift range selection.
- Ctrl/Cmd additive selection.
- Drag reorder.
- External PDF drop.
- Extract/split/replace preview.
- Undo/redo.

## Wave 6 – Search, bookmarks and inspector

- Unified search.
- Native text search.
- OCR text search.
- Annotation search.
- Bookmark search.
- Inspector tabs.
- TOC generation.

## Wave 7 – OCR

- OCR queue.
- Per-page status.
- Language selection.
- Region OCR.
- Confidence/debug view.
- Retry/resume.
- Searchable text layer.

## Wave 8 – Generate and macros

- Macro builder.
- AI command planner.
- Diff preview.
- User confirmation.
- Auditable command history.

## Wave 9 – Redaction

Redaction is last because it depends on accurate coordinates, text extraction, OCR handling, PDF rewrite and verification.

## Definition of done

- Every tool maps to a command.
- Every destructive command has preview/confirmation.
- Every save/export path is deterministic.
- Write mode is honestly scoped.
- OCR is inspectable and recoverable.
- Redaction destructively removes content.
- AI produces auditable command plans only.
