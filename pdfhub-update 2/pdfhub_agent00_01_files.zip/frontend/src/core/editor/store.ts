import type { EditorState, SidebarTab, WorkbenchMode } from './types';

export type EditorListener = (state: EditorState) => void;

const initialState: EditorState = {
  mode: 'view',
  sidebarTab: 'pages',
  inspectorVisible: true,
  sidebarVisible: true,
};

export class EditorStore {
  private state: EditorState = { ...initialState };
  private listeners = new Set<EditorListener>();

  getState(): EditorState {
    return { ...this.state };
  }

  setMode(mode: WorkbenchMode): void {
    this.state = { ...this.state, mode };
    this.emit();
  }

  setSidebarTab(sidebarTab: SidebarTab): void {
    this.state = { ...this.state, sidebarTab };
    this.emit();
  }

  setInspectorVisible(inspectorVisible: boolean): void {
    this.state = { ...this.state, inspectorVisible };
    this.emit();
  }

  setSidebarVisible(sidebarVisible: boolean): void {
    this.state = { ...this.state, sidebarVisible };
    this.emit();
  }

  reset(): void {
    this.state = { ...initialState };
    this.emit();
  }

  subscribe(listener: EditorListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(): void {
    const snapshot = this.getState();
    for (const listener of this.listeners) {
      listener(snapshot);
    }
  }
}

export const editorStore = new EditorStore();
