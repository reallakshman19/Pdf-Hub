export type WorkbenchMode =
  | 'view'
  | 'annotate'
  | 'draw'
  | 'write'
  | 'organize'
  | 'generate';

export type SidebarTab =
  | 'pages'
  | 'search'
  | 'comments'
  | 'macros'
  | 'bookmarks';

export interface EditorState {
  mode: WorkbenchMode;
  sidebarTab: SidebarTab;
  inspectorVisible: boolean;
  sidebarVisible: boolean;
}
