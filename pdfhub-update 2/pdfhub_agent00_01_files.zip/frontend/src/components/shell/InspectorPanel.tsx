import React from 'react';

const tabs = ['Properties', 'Style', 'Geometry', 'Accessibility', 'History', 'Raw PDF'];

export function InspectorPanel(): JSX.Element {
  return (
    <aside className="doccraft-inspector-panel" data-testid="inspector-panel">
      <h2>Inspector</h2>
      <div className="doccraft-inspector-panel__tabs">
        {tabs.map((tab) => (
          <button key={tab} type="button">
            {tab}
          </button>
        ))}
      </div>
    </aside>
  );
}
