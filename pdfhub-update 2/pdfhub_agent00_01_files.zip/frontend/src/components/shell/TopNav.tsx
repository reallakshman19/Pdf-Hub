import React from 'react';

export function TopNav(): JSX.Element {
  return (
    <header className="doccraft-topnav" data-testid="top-nav">
      <div className="doccraft-topnav__brand">PDF Hub</div>
      <div className="doccraft-topnav__document">No document loaded</div>
      <input
        className="doccraft-topnav__command-search"
        aria-label="Command search"
        placeholder="Search commands"
      />
    </header>
  );
}
