import React from 'react';

export function SidebarPanel(): JSX.Element {
  return (
    <aside className="doccraft-sidebar-panel" data-testid="sidebar-panel">
      <h2>Pages</h2>
      <p>Thumbnail and search panels will appear here.</p>
    </aside>
  );
}
