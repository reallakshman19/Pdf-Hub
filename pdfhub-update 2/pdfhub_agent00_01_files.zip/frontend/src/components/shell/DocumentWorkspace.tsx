import React from 'react';

export function DocumentWorkspace(): JSX.Element {
  return (
    <main className="doccraft-document-workspace" data-testid="document-workspace">
      <section className="doccraft-empty-state">
        <h1>Open a PDF to begin</h1>
        <p>Viewer, overlays and page operations will render in this workspace.</p>
      </section>
    </main>
  );
}
