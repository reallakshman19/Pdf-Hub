import React from 'react';
import { TopNav } from './TopNav';
import { ToolbarBand } from './ToolbarBand';
import { LeftRail } from './LeftRail';
import { SidebarPanel } from './SidebarPanel';
import { DocumentWorkspace } from './DocumentWorkspace';
import { InspectorPanel } from './InspectorPanel';
import { StatusBar } from './StatusBar';

export function AppShell(): JSX.Element {
  return (
    <div className="doccraft-shell" data-testid="doccraft-shell">
      <TopNav />
      <ToolbarBand />
      <div className="doccraft-shell__body">
        <LeftRail />
        <SidebarPanel />
        <DocumentWorkspace />
        <InspectorPanel />
      </div>
      <StatusBar />
    </div>
  );
}
