import React from 'react';

export function StatusBar(): JSX.Element {
  return (
    <footer className="doccraft-status-bar" data-testid="status-bar">
      Ready
    </footer>
  );
}
