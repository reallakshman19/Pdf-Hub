import React from 'react';

const modes = ['view', 'annotate', 'draw', 'write', 'organize', 'generate'] as const;

export function ToolbarBand(): JSX.Element {
  return (
    <nav className="doccraft-toolbar" aria-label="PDF workbench modes">
      {modes.map((mode) => (
        <button key={mode} type="button" data-mode={mode}>
          {mode}
        </button>
      ))}
    </nav>
  );
}
