import React from 'react';

const tabs = ['pages', 'search', 'comments', 'macros', 'bookmarks'] as const;

export function LeftRail(): JSX.Element {
  return (
    <aside className="doccraft-left-rail" aria-label="Navigation rail">
      {tabs.map((tab) => (
        <button key={tab} type="button" data-sidebar-tab={tab}>
          {tab}
        </button>
      ))}
    </aside>
  );
}
