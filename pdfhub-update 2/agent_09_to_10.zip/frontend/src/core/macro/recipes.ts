/*
 * Built-in macro recipes.
 *
 * This module defines a handful of simple macros that can be loaded
 * by default.  Each macro contains a descriptive name and a list of
 * commands.  In preview mode the command lists are empty; the
 * macros serve only as examples.  When server‑side or full
 * implementation of commands is available these macros could be
 * populated with real command objects.
 */

import type { Macro } from './types';

export const builtinMacros: Macro[] = [
  {
    id: 'macro-rotate-90',
    name: 'Rotate pages 90°',
    description: 'Rotate selected pages by 90 degrees clockwise.',
    commands: [],
  },
  {
    id: 'macro-add-page-numbers',
    name: 'Add page numbers',
    description: 'Add simple page numbers to each page.',
    commands: [],
  },
  {
    id: 'macro-extract-pages',
    name: 'Extract selected pages',
    description: 'Extract selected pages into a new document.',
    commands: [],
  },
];