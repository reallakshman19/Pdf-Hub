/*
 * Macro type definitions.
 *
 * A macro is a reusable set of PDF commands that can be applied as a
 * single operation.  Macros are created and edited on the client in
 * preview mode.  Each macro contains a list of commands and a
 * descriptive name.  When run, the macro executes its commands
 * through the command dispatcher.
 */

import type { PdfCommand } from '../commands/types';

export interface Macro {
  id: string;
  name: string;
  description?: string;
  commands: PdfCommand[];
}