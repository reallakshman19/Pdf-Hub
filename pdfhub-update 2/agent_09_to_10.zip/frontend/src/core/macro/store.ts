/*
 * Macro store.
 *
 * Keeps track of user-defined macros in preview mode.  Each macro
 * consists of a list of commands that can be executed together.
 * Macros are stored in memory only; they are not persisted across
 * sessions.  Running a macro will simply return its commands to be
 * executed by the caller.
 */

import type { Macro } from './types';
import type { PdfCommand } from '../commands/types';

function makeId(): string {
  return Math.random().toString(36).substr(2, 9);
}

export class MacroStore {
  private macros: Map<string, Macro> = new Map();

  /**
   * Create a new macro with the given name and commands.  The new
   * macro is added to the store and returned.
   */
  createMacro(name: string, commands: PdfCommand[], description?: string): Macro {
    const macro: Macro = {
      id: makeId(),
      name,
      description,
      commands: [...commands],
    };
    this.macros.set(macro.id, macro);
    return macro;
  }

  /**
   * Update an existing macro.  Returns the updated macro or undefined
   * if no macro with the given ID exists.
   */
  updateMacro(id: string, fields: Partial<Omit<Macro, 'id'>>): Macro | undefined {
    const existing = this.macros.get(id);
    if (!existing) return undefined;
    const updated: Macro = {
      ...existing,
      ...fields,
    };
    this.macros.set(id, updated);
    return updated;
  }

  /**
   * Remove a macro from the store.
   */
  deleteMacro(id: string): void {
    this.macros.delete(id);
  }

  /**
   * Get all macros as an array.
   */
  getMacros(): Macro[] {
    return Array.from(this.macros.values());
  }

  /**
   * Get a macro by ID.
   */
  getMacro(id: string): Macro | undefined {
    return this.macros.get(id);
  }

  /**
   * Run a macro by returning its list of commands.  In preview mode
   * this does not execute the commands.  It is up to the caller to
   * dispatch them via the command system.
   */
  runMacro(id: string): PdfCommand[] {
    const macro = this.macros.get(id);
    if (!macro) return [];
    // Return a shallow copy to prevent mutation by the caller.
    return [...macro.commands];
  }
}