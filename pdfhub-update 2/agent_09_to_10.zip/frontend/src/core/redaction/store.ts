/**
 * Simple in‑memory store for redaction preview data. This store follows the
 * pattern used by other core stores in the project (such as annotations and
 * pages). It does not persist data to any back‑end and is intended solely
 * for previewing potential redactions. Persisting and applying redactions
 * requires server support and is therefore deferred. See
 * `docs/REMAINING_BACKEND_DEFERRED_REGISTER.md` for details.
 */

import { RedactionState, RedactionRegion, PdfRect } from './types';

type Listener = () => void;

/**
 * Internal mutable state for the redaction store. The state is not exported
 * directly; consumers must interact via the exported API functions.
 */
const state: RedactionState = {
  regions: [],
  nextId: 1,
};

const listeners: Listener[] = [];

/** Notify all subscribers of a state change. */
function notify(): void {
  listeners.forEach((listener) => listener());
}

/**
 * Subscribe to state changes. Returns an unsubscribe function that can be
 * called to remove the listener.
 */
export function subscribe(listener: Listener): () => void {
  listeners.push(listener);
  return () => {
    const index = listeners.indexOf(listener);
    if (index >= 0) listeners.splice(index, 1);
  };
}

/**
 * Retrieve a shallow copy of the current redaction state. Consumers should
 * treat the returned object as immutable.
 */
export function getState(): RedactionState {
  return {
    regions: state.regions.slice(),
    nextId: state.nextId,
  };
}

/**
 * Create a new redaction region. Returns the newly created region. The
 * `rect` parameter must already be in PDF coordinate space (points). The
 * caller should ensure that page numbers and coordinates are valid.
 */
export function addRegion(pageNumber: number, rect: PdfRect, reason?: string): RedactionRegion {
  const id = `r${state.nextId++}`;
  const region: RedactionRegion = {
    id,
    pageNumber,
    rect: { ...rect },
    reason,
    status: 'preview',
  };
  state.regions.push(region);
  notify();
  return region;
}

/**
 * Update an existing redaction region. Only mutable properties (rect and
 * reason) may be patched. Returns the updated region or undefined if the
 * region could not be found.
 */
export function updateRegion(
  regionId: string,
  patch: Partial<{ rect: PdfRect; reason: string }>
): RedactionRegion | undefined {
  const region = state.regions.find((r) => r.id === regionId);
  if (!region) return undefined;
  if (patch.rect) {
    region.rect = { ...patch.rect };
  }
  if (patch.reason !== undefined) {
    region.reason = patch.reason;
  }
  notify();
  return region;
}

/**
 * Remove one or more redaction regions by ID. Returns the number of
 * removed regions.
 */
export function deleteRegions(regionIds: string[]): number {
  let removed = 0;
  for (const id of regionIds) {
    const index = state.regions.findIndex((r) => r.id === id);
    if (index >= 0) {
      state.regions.splice(index, 1);
      removed++;
    }
  }
  if (removed > 0) notify();
  return removed;
}

/**
 * Remove all redaction regions. This does not reset the ID counter.
 */
export function clearRegions(): void {
  if (state.regions.length > 0) {
    state.regions.length = 0;
    notify();
  }
}

/**
 * Construct a JSON serialisable representation of the current redaction plan.
 * This function returns a plain object that can be passed to
 * `JSON.stringify`. The structure includes all pages with their respective
 * redaction rectangles.
 */
export function exportPlan(): {
  documentKey: string;
  pages: Array<{ pageNumber: number; rects: PdfRect[] }>;
} {
  // In this preview version the document key is unknown; the caller should
  // substitute the correct key before persisting the plan. Use an empty
  // string placeholder here.
  const pagesMap: Record<number, PdfRect[]> = {};
  for (const region of state.regions) {
    if (!pagesMap[region.pageNumber]) {
      pagesMap[region.pageNumber] = [];
    }
    pagesMap[region.pageNumber].push({ ...region.rect });
  }
  return {
    documentKey: '',
    pages: Object.keys(pagesMap).map((numStr) => {
      const pageNumber = parseInt(numStr, 10);
      return { pageNumber, rects: pagesMap[pageNumber].slice() };
    }),
  };
}