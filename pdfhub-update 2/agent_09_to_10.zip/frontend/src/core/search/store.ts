/*
 * Search store for DocCraft.
 *
 * This store manages the current search query and results.  It is a
 * minimal implementation that allows the search panel to update its
 * state.  Real search indexing and result highlighting are handled by
 * the search engine module and the viewer overlay.
 */

import type { SearchQuery, SearchResult } from './types';

export class SearchStore {
  private query: SearchQuery | null = null;
  private results: SearchResult[] = [];
  private currentIndex = 0;

  /**
   * Sets a new search query and resets results.  This does not
   * automatically run the search; that is left to the caller via the
   * search engine.
   */
  setQuery(query: SearchQuery): void {
    this.query = { ...query };
    this.results = [];
    this.currentIndex = 0;
  }

  /**
   * Returns the current query or null if none has been set.
   */
  getQuery(): SearchQuery | null {
    return this.query ? { ...this.query } : null;
  }

  /**
   * Sets the current search results and resets the current index.
   */
  setResults(results: SearchResult[]): void {
    this.results = results.slice();
    this.currentIndex = 0;
  }

  /**
   * Returns a copy of the current results.
   */
  getResults(): SearchResult[] {
    return this.results.slice();
  }

  /**
   * Gets the currently selected search result index.
   */
  getCurrentIndex(): number {
    return this.currentIndex;
  }

  /**
   * Moves to the next result.  Wraps around at the end.
   */
  nextResult(): void {
    if (this.results.length === 0) {
      return;
    }
    this.currentIndex = (this.currentIndex + 1) % this.results.length;
  }

  /**
   * Moves to the previous result.  Wraps around at the beginning.
   */
  previousResult(): void {
    if (this.results.length === 0) {
      return;
    }
    this.currentIndex = (this.currentIndex - 1 + this.results.length) % this.results.length;
  }
}