/*
 * Search types for DocCraft.
 *
 * These definitions describe the structure of search queries and
 * results.  The search system can cover native text, OCR text,
 * annotations, bookmarks and page labels.  Additional scopes may be
 * added in the future.
 */

export type SearchScope =
  | 'nativeText'
  | 'ocrText'
  | 'annotations'
  | 'bookmarks'
  | 'pageLabels';

export interface SearchQuery {
  /**
   * The query string.  Regular expression support is controlled by the
   * `regex` flag.
   */
  text: string;
  /**
   * The scopes to search within.  At least one scope must be provided.
   */
  scopes: SearchScope[];
  /**
   * Whether the query is treated as an exact phrase.
   */
  exactPhrase?: boolean;
  /**
   * Whether to interpret the query as a regular expression.
   */
  regex?: boolean;
  /**
   * Whether the search is case sensitive.
   */
  caseSensitive?: boolean;
  /**
   * Whether to restrict the search to selected pages only.
   */
  selectedPagesOnly?: boolean;
  /**
   * Optional list of specific page numbers to search within.  When
   * provided, this overrides `selectedPagesOnly`.
   */
  pageNumbers?: number[];
}

export interface SearchResult {
  /**
   * A unique identifier for the result.  This may be used for tracking
   * or retrieving additional context.
   */
  id: string;
  /**
   * The scope that produced the result.
   */
  scope: SearchScope;
  /**
   * The page number where the result occurs.
   */
  pageNumber: number;
  /**
   * A snippet of text or label providing context for the result.
   */
  snippet: string;
  /**
   * Rectangles representing the bounding boxes of the result within the
   * page.  Coordinates are in PDF points (0,0 top left).
   */
  rects: Array<{ x: number; y: number; width: number; height: number }>;
  /**
   * A deep link or identifier that can be used to navigate directly to
   * the result in the viewer.
   */
  deepLink: string;
}