/*
 * Bookmark and table of contents types for DocCraft.
 *
 * These interfaces describe the shape of bookmark trees used in the
 * bookmarks panel.  The tree structure mirrors the nested outline of a
 * PDF.  Additional metadata may be added later (e.g. creation source).
 */

export interface BookmarkNode {
  /**
   * Unique identifier for this bookmark node.
   */
  id: string;
  /**
   * The display title of the bookmark.
   */
  title: string;
  /**
   * The page number this bookmark points to.  One‑based numbering.
   */
  pageNumber: number;
  /**
   * Optional x and y coordinates within the page.  When undefined the
   * bookmark jumps to the top of the page.
   */
  x?: number;
  y?: number;
  /**
   * Child bookmarks nested beneath this node.
   */
  children: BookmarkNode[];
  /**
   * The source of the bookmark.  'pdf-outline' indicates it originates
   * from the embedded outline; 'user' indicates it was created by the
   * user; 'generated' indicates it was generated automatically (e.g. by
   * a TOC generator).
   */
  source: 'pdf-outline' | 'user' | 'generated';
}