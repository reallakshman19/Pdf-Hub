/**
 * Test utility functions for DocCraft front‑end.  These utilities can be
 * imported by unit or integration tests to render components and simulate
 * user interactions without duplicating boilerplate. The utilities are
 * intentionally minimal to avoid pulling in heavy dependencies.
 */

import React from 'react';
import { render, RenderResult } from '@testing-library/react';

/**
 * Render a React component into a detached DOM container. Returns the
 * RenderResult from React Testing Library. Tests may use this to access
 * DOM nodes and simulate events.
 */
export function renderComponent(ui: React.ReactElement): RenderResult {
  return render(ui);
}