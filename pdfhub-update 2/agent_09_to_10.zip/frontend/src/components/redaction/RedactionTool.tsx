import React from 'react';

/**
 * Placeholder component for the Redaction tool. In the preview
 * implementation of DocCraft there is no ability to perform true
 * redaction—removing PDF content requires a server‑side pipeline. This
 * component communicates that limitation to the user and provides a simple
 * affordance for enabling redaction preview mode when integrated with the
 * viewer (not implemented here).
 */

export const RedactionTool: React.FC = () => {
  return (
    <div
      style={{
        padding: '0.5rem 1rem',
        background: '#ffeeee',
        border: '1px solid #dd4444',
        borderRadius: '4px',
        color: '#660000',
        fontSize: '0.875rem',
      }}
    >
      <strong>Redaction (Preview only)</strong>
      <br />
      You can mark regions to be redacted, but final secure redaction is
      disabled. Use the Redaction panel to export a JSON plan for later
      application when server support is available.
    </div>
  );
};

export default RedactionTool;