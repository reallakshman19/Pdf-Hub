/*
 * Search panel component.
 *
 * This panel allows the user to enter a query and displays search
 * results.  It interacts with the search store and the provided search
 * engine to perform simple searches across scopes.  Result navigation
 * (next/prev) is also provided.
 */

import React, { useState } from 'react';
import type { SearchQuery, SearchResult, SearchScope } from '../../core/search/types';
import { SearchStore } from '../../core/search/store';
import { runSearch } from '../../core/search/searchEngine';

export interface SearchPanelProps {
  searchStore: SearchStore;
  providers: Partial<
    Record<
      SearchScope,
      (query: SearchQuery) => Array<Omit<SearchResult, 'id' | 'scope'>>
    >
  >;
}

export default function SearchPanel({ searchStore, providers }: SearchPanelProps): JSX.Element {
  const [queryText, setQueryText] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query: SearchQuery = {
      text: queryText,
      scopes: ['nativeText', 'ocrText', 'annotations', 'bookmarks', 'pageLabels'],
    };
    searchStore.setQuery(query);
    const results = runSearch(query, providers);
    searchStore.setResults(results);
  };

  const results = searchStore.getResults();
  const currentIndex = searchStore.getCurrentIndex();

  return (
    <div className="doccraft-search-panel">
      <form onSubmit={handleSearch}>
        <input
          type="text"
          value={queryText}
          onChange={(e) => setQueryText(e.target.value)}
          placeholder="Search..."
        />
        <button type="submit">Search</button>
      </form>
      {results.length > 0 && (
        <div className="doccraft-search-results">
          <p>
            {currentIndex + 1} of {results.length} results
          </p>
          <button onClick={() => searchStore.previousResult()}>Prev</button>
          <button onClick={() => searchStore.nextResult()}>Next</button>
          <ul>
            {results.map((r, idx) => (
              <li key={r.id} className={idx === currentIndex ? 'selected' : ''}>
                <span className="scope">{r.scope}</span>{' '}
                <span className="page">Page {r.pageNumber}</span>{' '}
                <span className="snippet">{r.snippet}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}