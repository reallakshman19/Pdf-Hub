/*
 * MacroBuilder component.
 *
 * Provides a simple interface for creating and managing macros in
 * preview mode.  Users can add new macros by specifying a name
 * (commands are currently empty).  Existing macros are listed with
 * delete buttons.  Macro editing and command assignment are not
 * implemented here; this component is intended to demonstrate
 * client‑side macro storage and UI wiring.
 */

import React, { useState } from 'react';
import type { MacroStore } from '../../core/macro/store';
import type { Macro } from '../../core/macro/types';

export interface MacroBuilderProps {
  macroStore: MacroStore;
}

export default function MacroBuilder({ macroStore }: MacroBuilderProps): JSX.Element {
  const [macroName, setMacroName] = useState('');
  const macros: Macro[] = macroStore.getMacros();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (macroName.trim().length === 0) return;
    macroStore.createMacro(macroName, [], `Custom macro: ${macroName}`);
    setMacroName('');
  };

  const handleDelete = (id: string) => {
    macroStore.deleteMacro(id);
    // force rerender by updating state (React hook will not detect store change otherwise)
    setMacroName((v) => v);
  };

  return (
    <div className="doccraft-macro-builder">
      <h3>Macro Builder</h3>
      <form onSubmit={handleAdd} style={{ marginBottom: '1em' }}>
        <input
          type="text"
          value={macroName}
          onChange={(e) => setMacroName(e.target.value)}
          placeholder="Macro name"
        />
        <button type="submit">Add Macro</button>
      </form>
      {macros.length === 0 ? (
        <p>No macros defined.</p>
      ) : (
        <ul>
          {macros.map((macro) => (
            <li key={macro.id}>
              <strong>{macro.name}</strong> – {macro.description || ''}{' '}
              <button onClick={() => handleDelete(macro.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}