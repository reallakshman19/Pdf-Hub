/*
 * MacroConsolePage.
 *
 * A dedicated page that embeds the MacroBuilder component and
 * instantiates its own MacroStore instance.  This allows users
 * to create and manage macros outside of the main editor.  In a
 * larger application this page could be routed from the main UI
 * and integrated with persistent storage.
 */

import React from 'react';
import MacroBuilder from '../components/generate/MacroBuilder';
import { MacroStore } from '../core/macro/store';

const macroStore = new MacroStore();

export default function MacroConsolePage(): JSX.Element {
  return (
    <div className="doccraft-macro-console">
      <MacroBuilder macroStore={macroStore} />
    </div>
  );
}