import type { PageMetric, TextItem } from './types';

/**
 * A lightweight adapter around PDF.js or a similar library.  The real
 * implementation would load and parse PDF documents, render pages into
 * canvases and extract text items.  In the preview‑only environment used
 * during early development, these methods provide stub implementations that
 * return dummy values.  This allows the rest of the application to compile
 * and run without requiring pdfjs-dist to be installed.
 */
export class PdfRendererAdapter {
  private lastDocument: unknown | null = null;

  /**
   * Load a PDF document from raw bytes.  Returns a promise that resolves
   * with an opaque document object.  In preview mode this simply
   * encapsulates the ArrayBuffer without parsing.
   */
  async loadDocument(bytes: Uint8Array): Promise<unknown> {
    // In a real implementation you would call pdfjsLib.getDocument().
    this.lastDocument = { bytes };
    return this.lastDocument;
  }

  /**
   * Get page metrics for every page in the document.  This stub returns a
   * single page with A4 dimensions as a placeholder.  Real code should
   * iterate over each page and call `page.getViewport({ scale: 1 })`.
   */
  async getPageMetrics(doc: unknown): Promise<PageMetric[]> {
    // Without pdfjs we cannot extract real dimensions.  Return a 1‑page
    // document with a common 8.5x11 inch page at 96dpi (816x1056px).
    return [
      {
        pageNumber: 1,
        width: 816,
        height: 1056,
        rotation: 0,
      },
    ];
  }

  /**
   * Render a page into a canvas.  The canvas must already exist and be
   * attached to the DOM.  In preview mode this fills the canvas with a
   * light gray rectangle to indicate that rendering is stubbed out.
   */
  async renderPage(
    doc: unknown,
    pageNumber: number,
    canvas: HTMLCanvasElement,
    scale: number,
  ): Promise<void> {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const width = canvas.width;
    const height = canvas.height;
    ctx.save();
    ctx.fillStyle = '#efefef';
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = '#999999';
    ctx.font = `${Math.max(12, width / 20)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`Page ${pageNumber}`, width / 2, height / 2);
    ctx.restore();
  }

  /**
   * Extract text items from a page.  Since we cannot parse PDF content in
   * preview mode, this returns an empty array.  In a real implementation
   * this would call `page.getTextContent()` and map each item to
   * coordinates at the given scale.
   */
  async getPageTextItems(
    doc: unknown,
    pageNumber: number,
    scale: number,
  ): Promise<TextItem[]> {
    return [];
  }

  /**
   * Render a thumbnail for the given page.  In preview mode this delegates
   * to `renderPage` on a small canvas and returns it.  Real code should
   * render off‑screen to reduce memory usage.
   */
  async renderThumbnail(
    doc: unknown,
    pageNumber: number,
    width: number,
    height: number,
  ): Promise<HTMLCanvasElement | null> {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    await this.renderPage(doc, pageNumber, canvas, 1);
    return canvas;
  }
}

// Export a singleton instance for convenience.  Consumers can also
// instantiate their own adapter if they need separate state.
export const pdfRendererAdapter = new PdfRendererAdapter();