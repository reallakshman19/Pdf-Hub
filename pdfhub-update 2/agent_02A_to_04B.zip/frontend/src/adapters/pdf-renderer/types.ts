/**
 * Common type definitions for the PDF renderer adapter.  These types are
 * intentionally minimal to avoid pulling in the entire PDF.js type system.
 *
 * A `PageMetric` captures the intrinsic width, height and rotation of a
 * single page at 100% scale.  These values are used to reserve space in the
 * viewer before the page finishes rendering, preventing layout shifts.
 */

export interface PageMetric {
  /** 1‑based page number. */
  pageNumber: number;
  /** Width of the page in CSS pixels at scale = 1. */
  width: number;
  /** Height of the page in CSS pixels at scale = 1. */
  height: number;
  /** Rotation of the page in degrees. 0, 90, 180 or 270. */
  rotation: number;
}

/**
 * A simple representation of text content items extracted from a page.  Each
 * item includes its bounding rectangle relative to the top‑left of the page
 * at a given scale and the text string.  For OCR or search overlays you
 * might extend this interface to include a confidence value or source.
 */
export interface TextItem {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
}