import type { PageMetric } from './types';
import { pdfRendererAdapter } from './PdfRendererAdapter';

/**
 * Prefetch page metrics for the given document using the adapter.  In
 * preview mode this simply proxies to the adapter implementation.  The
 * promise resolves with an array of PageMetric objects describing each
 * page’s dimensions and rotation at scale=1.
 */
export async function getPageMetrics(doc: unknown): Promise<PageMetric[]> {
  return pdfRendererAdapter.getPageMetrics(doc);
}