/*
 * Left rail navigation component.  In a full implementation this would
 * provide icons to switch between Pages, Search, Comments, Macros and
 * Bookmarks.  Here it is a placeholder.
 */

import React from 'react';

export default function LeftRail(): JSX.Element {
  return (
    <aside className="doccraft-left-rail">
      {/* Icons for Pages, Search, Comments, Macros and Bookmarks */}
    </aside>
  );
}
