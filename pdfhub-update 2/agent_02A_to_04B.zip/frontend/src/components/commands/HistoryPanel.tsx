import React, { useEffect, useState } from 'react';
import { CommandStore } from '../../core/commands/store';
import type { PdfCommand } from '../../core/commands/types';

/**
 * HistoryPanel displays a list of executed commands and allows the user to
 * undo or redo actions.  It creates its own instance of CommandStore to
 * illustrate how history could be managed.  In a real application a
 * singleton store would be used and the panel would subscribe to its
 * updates.
 */
export const HistoryPanel: React.FC = () => {
  const [history, setHistory] = useState<PdfCommand[]>([]);
  const [future, setFuture] = useState<PdfCommand[]>([]);
  // Create an internal command store instance.  In practice this should
  // come from a context or be imported as a singleton.
  const [store] = useState(() => new CommandStore());

  // Example: subscribe to changes by overriding the apply/undo/redo methods
  useEffect(() => {
    const originalApply = store.apply.bind(store);
    store.apply = (cmd: PdfCommand) => {
      const result = originalApply(cmd);
      setHistory(store.getHistory());
      setFuture(store.getFuture());
      return result;
    };
    // Populate initial state
    setHistory(store.getHistory());
    setFuture(store.getFuture());
  }, [store]);

  return (
    <div className="history-panel" style={{ padding: '0.5rem', borderTop: '1px solid #eee' }}>
      <h3>History</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {history.map((cmd, idx) => (
          <li key={idx} style={{ fontSize: '0.8rem' }}>{cmd.type}</li>
        ))}
      </ul>
      <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button onClick={() => {
            const undone = store.undo();
            setHistory(store.getHistory());
            setFuture(store.getFuture());
          }} disabled={history.length === 0}>Undo</button>
          <button onClick={() => {
            const redone = store.redo();
            setHistory(store.getHistory());
            setFuture(store.getFuture());
          }} disabled={future.length === 0}>Redo</button>
      </div>
    </div>
  );
};