/*
 * Contextual toolbar band.  Buttons shown here change depending on the
 * current workbench mode.  At this early stage the component just
 * reserves space for the toolbar.
 */

import React from 'react';

export default function ToolbarBand(): JSX.Element {
  return (
    <nav className="doccraft-toolbar-band">
      {/* Toolbar buttons will be conditionally rendered based on mode */}
    </nav>
  );
}
