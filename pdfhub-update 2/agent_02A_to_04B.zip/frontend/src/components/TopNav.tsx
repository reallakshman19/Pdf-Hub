/*
 * Top navigation bar for the DocCraft workbench.
 */

import React from 'react';

export default function TopNav(): JSX.Element {
  return (
    <header className="doccraft-top-nav">
      <div className="brand">DocCraft</div>
      {/* Additional navigation items (e.g. file name, search, user avatar) will be inserted here. */}
    </header>
  );
}
