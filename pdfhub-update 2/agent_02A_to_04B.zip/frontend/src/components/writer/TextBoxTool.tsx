import React from 'react';
import { writerStore } from '../../core/writer/store';
import type { WriterTextBoxElement } from '../../core/writer/types';

/**
 * TextBoxTool inserts a text box overlay onto the first page.  In a
 * production implementation the user would click and drag to define
 * the position and size.  Here we use a fixed position and size and
 * sample text.  The element is added to the writer store.
 */
export const TextBoxTool: React.FC = () => {
  function addTextBox() {
    const id = Math.random().toString(36).substring(2);
    const element: WriterTextBoxElement = {
      id,
      type: 'textBox',
      pageNumber: 1,
      rect: { x: 50, y: 600, width: 300, height: 80 },
      text: 'Sample text',
      style: {
        fontFamily: 'Helvetica',
        fontSize: 14,
        bold: false,
        italic: false,
        underline: false,
        color: '#000000',
        align: 'left',
      },
    };
    writerStore.addElement(element);
  }
  return <button onClick={addTextBox}>Add Text Box</button>;
};