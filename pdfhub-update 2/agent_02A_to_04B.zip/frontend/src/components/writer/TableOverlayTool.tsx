import React from 'react';
import { writerStore } from '../../core/writer/store';
import type { WriterTableOverlayElement } from '../../core/writer/types';

/**
 * TableOverlayTool inserts a simple 2x2 table overlay.  Cells start
 * empty.  In a complete implementation the user could specify the
 * dimensions and edit cell contents directly on the page.
 */
export const TableOverlayTool: React.FC = () => {
  function addTable() {
    const id = Math.random().toString(36).substring(2);
    const rows = 2;
    const columns = 2;
    const cells: WriterTableOverlayElement['cells'] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < columns; c++) {
        cells.push({ row: r, column: c, text: '' });
      }
    }
    const element: WriterTableOverlayElement = {
      id,
      type: 'tableOverlay',
      pageNumber: 1,
      rect: { x: 400, y: 600, width: 200, height: 100 },
      rows,
      columns,
      cells,
    };
    writerStore.addElement(element);
  }
  return <button onClick={addTable}>Add Table</button>;
};