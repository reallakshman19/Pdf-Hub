import React from 'react';
import { writerStore } from '../../core/writer/store';
import type { WriterImageElement } from '../../core/writer/types';

/**
 * ImageTool inserts an image overlay onto the document.  In a real
 * implementation the user would choose an image file from disk.  This
 * stub creates a placeholder image element with no actual content.
 */
export const ImageTool: React.FC = () => {
  function addImage() {
    const id = Math.random().toString(36).substring(2);
    const element: WriterImageElement = {
      id,
      type: 'image',
      pageNumber: 1,
      rect: { x: 100, y: 700, width: 200, height: 150 },
      imageId: 'placeholder',
      mimeType: 'image/png',
      altText: 'Placeholder image',
    };
    writerStore.addElement(element);
  }
  return <button onClick={addImage}>Add Image</button>;
};