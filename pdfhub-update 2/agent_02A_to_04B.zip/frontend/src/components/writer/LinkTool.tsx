import React from 'react';
import { writerStore } from '../../core/writer/store';
import type { WriterLinkElement } from '../../core/writer/types';

/**
 * LinkTool inserts a hyperlink overlay.  The link opens in a new
 * tab when clicked.  In the preview build the overlay itself does
 * nothing; it is flattened into the PDF on export.
 */
export const LinkTool: React.FC = () => {
  function addLink() {
    const id = Math.random().toString(36).substring(2);
    const element: WriterLinkElement = {
      id,
      type: 'link',
      pageNumber: 1,
      rect: { x: 350, y: 750, width: 150, height: 30 },
      url: 'https://example.com',
      label: 'Example Link',
    };
    writerStore.addElement(element);
  }
  return <button onClick={addLink}>Add Link</button>;
};