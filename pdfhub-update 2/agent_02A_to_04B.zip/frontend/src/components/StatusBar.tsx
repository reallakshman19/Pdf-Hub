/*
 * Status bar component.  Displays helpful information such as page number,
 * zoom level, selection info or connection status.  For now it is a
 * placeholder.
 */

import React from 'react';

export default function StatusBar(): JSX.Element {
  return (
    <footer className="doccraft-status-bar">
      {/* Status information will be rendered here */}
    </footer>
  );
}
