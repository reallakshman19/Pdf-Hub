import React, { useRef } from 'react';
import { sessionStore } from '../../core/session/store';
import { annotationStore } from '../../core/annotations/store';
import { writerStore } from '../../core/writer/store';
import { composeCommittedPdf } from '../../core/document/composePdf';
import { downloadBlob } from '../../core/document/download';

/**
 * ToolbarFile provides basic file operations: opening a PDF file and
 * downloading the current document with annotations and overlays
 * flattened.  In the preview build, saving always produces an empty
 * PDF because the compose function is stubbed out.  This component
 * demonstrates how file input and download can be wired into the
 * session store.
 */
export const ToolbarFile: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  // Load a PDF file selected by the user
  async function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const arrayBuffer = await file.arrayBuffer();
    // Update the viewer by loading the new file via session store
    // This could also trigger a callback passed down from a parent component
    const bytes = new Uint8Array(arrayBuffer);
    // For now we simply reload by reassigning fileData in the PdfViewer
    // via sessionStore.loadSession.  The PdfViewer component will detect
    // the new session and re-render pages.  In a full implementation
    // the fileData prop could be lifted up to AppShell.
    sessionStore.loadSession({
      documentKey: Math.random().toString(36).substring(2),
      fileName: file.name,
      pageCount: 1,
      dirty: false,
    });
    // Since PdfViewer does not accept new props here, the page will not
    // display the file.  A real implementation would set state in a
    // parent component.  This function shows how the file could be
    // read and passed onward.
    void bytes;
  }
  async function handleSave() {
    const session = sessionStore.session;
    if (!session) return;
    // Compose a committed PDF with stubbed compose function.  We pass an
    // empty Uint8Array for base bytes because we cannot access the
    // original file in preview mode.
    const base = new Uint8Array();
    const annotations = annotationStore.getAll();
    const overlays = writerStore.getAll();
    const outBytes = await composeCommittedPdf(base, annotations as any, overlays as any);
    const blob = new Blob([outBytes], { type: 'application/pdf' });
    const filename = session.fileName || 'document.pdf';
    downloadBlob(blob, filename);
    // Reset dirty flag
    session.dirty = false;
  }
  return (
    <div className="toolbar-file" style={{ display: 'flex', gap: '0.5rem' }}>
      <input
        type="file"
        accept="application/pdf"
        ref={fileInputRef}
        style={{ display: 'none' }}
        onChange={handleFileChange}
      />
      <button
        onClick={() => {
          fileInputRef.current?.click();
        }}
      >
        Open
      </button>
      <button onClick={handleSave}>Download PDF</button>
    </div>
  );
};