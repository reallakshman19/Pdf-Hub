import React from 'react';
import { annotationStore } from '../../core/annotations/store';
// uuid import removed: using a simple random ID generator instead

/**
 * HighlightTool is a rudimentary component that demonstrates how an
 * annotation tool might work.  When clicked it adds a highlight
 * annotation on the current active page at a fixed position.  In a
 * full implementation the user would drag to create an arbitrary
 * rectangle on the page.
 */
export const HighlightTool: React.FC = () => {
  function addHighlight() {
    const id = Math.random().toString(36).substring(2);
    annotationStore.addAnnotation({
      id,
      type: 'highlight',
      pageNumber: 1,
      rect: { x: 100, y: 100, width: 200, height: 30 },
      color: 'rgba(255,255,0,0.4)',
    } as any);
  }
  return <button onClick={addHighlight}>Add Highlight</button>;
};