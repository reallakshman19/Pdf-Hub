import React from 'react';
import { annotationStore } from '../../core/annotations/store';

/**
 * FreehandTool adds a freehand annotation with a fixed set of points.
 * A real implementation would track mouse movements and create
 * arbitrary ink paths.  This stub draws a small zig‑zag line on
 * page 1 to demonstrate the data structure.
 */
export const FreehandTool: React.FC = () => {
  function addFreehand() {
    const id = Math.random().toString(36).substring(2);
    const points = [
      { x: 300, y: 500 },
      { x: 320, y: 520 },
      { x: 340, y: 500 },
      { x: 360, y: 520 },
    ];
    annotationStore.addAnnotation({
      id,
      type: 'freehand',
      pageNumber: 1,
      rect: { x: 300, y: 500, width: 60, height: 40 },
      points,
      color: '#00ff00',
      width: 2,
    } as any);
  }
  return <button onClick={addFreehand}>Add Freehand</button>;
};