import React from 'react';
import { annotationStore } from '../../core/annotations/store';

/**
 * StampTool adds a simple stamp annotation.  A real stamp tool would
 * allow choosing different stamp types (approved, draft, etc.).  Here we
 * default to a generic stamp.
 */
export const StampTool: React.FC = () => {
  function addStamp() {
    const id = Math.random().toString(36).substring(2);
    annotationStore.addAnnotation({
      id,
      type: 'stamp',
      pageNumber: 1,
      rect: { x: 200, y: 300, width: 80, height: 40 },
      stampType: 'approved',
    } as any);
  }
  return <button onClick={addStamp}>Add Stamp</button>;
};