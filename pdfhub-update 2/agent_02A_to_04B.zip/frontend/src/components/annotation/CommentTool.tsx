import React from 'react';
import { annotationStore } from '../../core/annotations/store';

/**
 * CommentTool is a simple example tool that adds a sticky note
 * annotation.  In a full implementation the user would click on a
 * location to place the note.  Here we use a fixed position and page.
 */
export const CommentTool: React.FC = () => {
  function addComment() {
    const id = Math.random().toString(36).substring(2);
    annotationStore.addAnnotation({
      id,
      type: 'sticky-note',
      pageNumber: 1,
      rect: { x: 150, y: 200, width: 32, height: 32 },
      content: 'New note',
    } as any);
  }
  return <button onClick={addComment}>Add Note</button>;
};