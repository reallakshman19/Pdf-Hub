import React from 'react';
import { annotationStore } from '../../core/annotations/store';

/**
 * ShapeTool adds a rectangle or ellipse annotation.  For simplicity the
 * tool always adds a rectangle.  In a full implementation the user
 * would choose the shape type and draw it on the page.
 */
export const ShapeTool: React.FC = () => {
  function addRectangle() {
    const id = Math.random().toString(36).substring(2);
    annotationStore.addAnnotation({
      id,
      type: 'rectangle',
      pageNumber: 1,
      rect: { x: 250, y: 400, width: 120, height: 80 },
      strokeColor: '#ff0000',
      fillColor: 'rgba(255,0,0,0.1)',
    } as any);
  }
  return <button onClick={addRectangle}>Add Rectangle</button>;
};