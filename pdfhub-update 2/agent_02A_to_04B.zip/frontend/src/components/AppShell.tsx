/*
 * Root shell component for the DocCraft PDF workbench.
 *
 * This component assembles the top navigation, toolbar, side rails,
 * document workspace, inspector panel and status bar.  In a complete
 * implementation, it would also provide context providers for stores and
 * coordinate layout.  For now it returns a simple DOM structure.
 */

import React from 'react';
import TopNav from './TopNav';
import ToolbarBand from './ToolbarBand';
import LeftRail from './LeftRail';
import SidebarPanel from './SidebarPanel';
import DocumentWorkspace from './DocumentWorkspace';
import InspectorPanel from './InspectorPanel';
import StatusBar from './StatusBar';

export default function AppShell(): JSX.Element {
  return (
    <div className="doccraft-app-shell">
      <TopNav />
      <ToolbarBand />
      <div className="doccraft-body" style={{ display: 'flex', flex: 1 }}>
        <LeftRail />
        <SidebarPanel />
        <DocumentWorkspace />
        <InspectorPanel />
      </div>
      <StatusBar />
    </div>
  );
}
