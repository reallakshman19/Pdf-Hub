import React, { useEffect, useState } from 'react';
import { annotationStore } from '../../core/annotations/store';
import type { Annotation } from '../../core/annotations/types';

/**
 * CommentsPanel lists all comment and sticky note annotations in the
 * document.  It displays the content and page number for each item.
 * Editing and deleting comments are not implemented in the preview
 * release.
 */
export const CommentsPanel: React.FC = () => {
  const [comments, setComments] = useState<Annotation[]>([]);
  useEffect(() => {
    return annotationStore.subscribe(() => {
      const annos = annotationStore.getAll();
      setComments(annos.filter((a) => a.type === 'comment' || a.type === 'sticky-note'));
    });
  }, []);
  if (comments.length === 0) {
    return <div className="comments-panel">No comments</div>;
  }
  return (
    <div className="comments-panel" style={{ padding: '0.5rem' }}>
      <h3>Comments</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {comments.map((c) => (
          <li key={c.id} style={{ marginBottom: '0.5rem' }}>
            <strong>Page {c.pageNumber}:</strong> {(c as any).content}
          </li>
        ))}
      </ul>
    </div>
  );
};