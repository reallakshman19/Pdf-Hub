import React, { useEffect, useState } from 'react';
import { annotationStore } from '../../core/annotations/store';
import type { Annotation } from '../../core/annotations/types';

export interface AnnotationOverlayProps {
  /** Page number of the underlying page; only annotations on this page
   * will be rendered. */
  pageNumber: number;
  /** Scale applied to the underlying page; annotation positions are
   * multiplied by this scale. */
  scale: number;
}

/**
 * AnnotationOverlay renders simple rectangles for annotations on a
 * particular page.  Only highlight and shape annotations are shown in
 * the preview build.  Other types can be added by extending the switch
 * statement.  All annotations are absolutely positioned based on their
 * page coordinates.
 */
export const AnnotationOverlay: React.FC<AnnotationOverlayProps> = ({ pageNumber, scale }) => {
  const [annos, setAnnos] = useState<Annotation[]>([]);
  useEffect(() => {
    // Subscribe to annotation changes
    return annotationStore.subscribe(() => {
      setAnnos(annotationStore.getAll());
    });
  }, []);

  const pageAnnos = annos.filter((a) => a.pageNumber === pageNumber);

  return (
    <div className="annotation-overlay" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, pointerEvents: 'none' }}>
      {pageAnnos.map((a) => {
        const { x, y, width, height } = a.rect;
        const style: React.CSSProperties = {
          position: 'absolute',
          left: x * scale,
          top: y * scale,
          width: width * scale,
          height: height * scale,
          pointerEvents: 'auto',
        };
        switch (a.type) {
          case 'highlight':
          case 'underline':
          case 'strikeout':
          case 'squiggly':
            return (
              <div
                key={a.id}
                style={{
                  ...style,
                  backgroundColor: (a as any).color || 'rgba(255,255,0,0.4)',
                }}
              />
            );
          case 'rectangle':
          case 'ellipse':
            return (
              <div
                key={a.id}
                style={{
                  ...style,
                  border: `1px solid ${(a as any).strokeColor || '#00f'}`,
                  backgroundColor: (a as any).fillColor || 'rgba(0, 0, 255, 0.1)',
                  borderRadius: a.type === 'ellipse' ? '50%' : '0%',
                }}
              />
            );
          default:
            return null;
        }
      })}
    </div>
  );
};