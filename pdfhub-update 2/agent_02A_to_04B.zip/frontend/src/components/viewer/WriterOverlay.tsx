import React, { useEffect, useState } from 'react';
import { writerStore } from '../../core/writer/store';
import type { WriterElement } from '../../core/writer/types';

export interface WriterOverlayProps {
  pageNumber: number;
  scale: number;
}

/**
 * WriterOverlay renders writer elements on top of a page.  In the
 * preview build only text boxes are visibly rendered as simple
 * absolutely positioned divs.  Image, table and link overlays are
 * represented by coloured boxes for demonstration.  The overlay
 * container is pointer‑events enabled so that future interactions may
 * be added.
 */
export const WriterOverlay: React.FC<WriterOverlayProps> = ({ pageNumber, scale }) => {
  const [elements, setElements] = useState<WriterElement[]>([]);
  useEffect(() => {
    return writerStore.subscribe(() => {
      setElements(writerStore.getAll());
    });
  }, []);
  const pageElements = elements.filter((e) => e.pageNumber === pageNumber);
  return (
    <div className="writer-overlay" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
      {pageElements.map((e) => {
        const { x, y, width, height } = e.rect;
        const commonStyle: React.CSSProperties = {
          position: 'absolute',
          left: x * scale,
          top: y * scale,
          width: width * scale,
          height: height * scale,
        };
        switch (e.type) {
          case 'textBox':
            return (
              <div key={e.id} style={{ ...commonStyle, color: e.style.color, fontFamily: e.style.fontFamily, fontSize: e.style.fontSize }}>
                {e.text}
              </div>
            );
          case 'image':
            return (
              <div key={e.id} style={{ ...commonStyle, background: '#ddd', border: '1px dashed #999' }}>
                Image
              </div>
            );
          case 'tableOverlay':
            return (
              <div key={e.id} style={{ ...commonStyle, border: '1px solid #333', fontSize: 10 }}>
                Table ({e.rows}x{e.columns})
              </div>
            );
          case 'link':
            return (
              <div key={e.id} style={{ ...commonStyle, color: '#0000EE', textDecoration: 'underline', cursor: 'pointer' }}>
                {e.label || e.url}
              </div>
            );
          default:
            return null;
        }
      })}
    </div>
  );
};