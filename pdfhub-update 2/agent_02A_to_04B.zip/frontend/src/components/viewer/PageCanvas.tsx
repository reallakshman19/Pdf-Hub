import React, { useEffect, useRef } from 'react';
import { pdfRendererAdapter } from '../../adapters/pdf-renderer/PdfRendererAdapter';
import type { PageMetric } from '../../adapters/pdf-renderer/types';

export interface PageCanvasProps {
  doc: unknown;
  pageNumber: number;
  metric: PageMetric;
  /** Optional zoom scale; if omitted the page will render at its intrinsic size. */
  scale?: number;
}

/**
 * PageCanvas renders a single page of the PDF into a canvas.  It sets
 * the canvas dimensions based on the provided PageMetric and scale and
 * delegates rendering to the PdfRendererAdapter.  In preview mode this
 * results in a gray placeholder with the page number.
 */
export const PageCanvas: React.FC<PageCanvasProps> = ({ doc, pageNumber, metric, scale = 1 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Render the page whenever the document, page number, metric or scale changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Set canvas size based on metric and scale
    canvas.width = Math.floor(metric.width * scale);
    canvas.height = Math.floor(metric.height * scale);
    pdfRendererAdapter.renderPage(doc, pageNumber, canvas, scale).catch(() => {
      // ignore rendering errors in preview mode
    });
  }, [doc, pageNumber, metric.width, metric.height, scale]);

  return <canvas ref={canvasRef} style={{ maxWidth: '100%' }} />;
};