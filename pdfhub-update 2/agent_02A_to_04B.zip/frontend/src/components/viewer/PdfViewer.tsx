import React, { useEffect, useRef, useState } from 'react';
import { sessionStore } from '../../core/session/store';
import type { DocumentSession } from '../../core/session/types';
import { pdfRendererAdapter } from '../../adapters/pdf-renderer/PdfRendererAdapter';
import { getPageMetrics } from '../../adapters/pdf-renderer/pageMetrics';
import { PageCanvas } from './PageCanvas';

/**
 * PdfViewer is responsible for loading a PDF document, computing page
 * metrics and rendering each page using PageCanvas.  In the initial
 * implementation it accepts raw byte data via the `fileData` prop.  A
 * production version may instead obtain the bytes through user file
 * selection or an API call.
 */
export interface PdfViewerProps {
  /** Raw bytes of the PDF file.  When provided, the document will be
   * loaded on mount.  If omitted the viewer remains empty until a
   * session is loaded externally via the sessionStore. */
  fileData?: Uint8Array;
}

export const PdfViewer: React.FC<PdfViewerProps> = ({ fileData }) => {
  const [doc, setDoc] = useState<unknown | null>(null);
  const [pageMetrics, setPageMetrics] = useState<ReturnType<typeof getPageMetrics> extends Promise<infer U> ? U : never>([] as any);

  // Load document when fileData changes
  useEffect(() => {
    let mounted = true;
    async function load() {
      if (fileData) {
        const documentRef = await pdfRendererAdapter.loadDocument(fileData);
        if (!mounted) return;
        setDoc(documentRef);
        const metrics = await getPageMetrics(documentRef);
        if (!mounted) return;
        setPageMetrics(metrics);
        // Update session with dummy key (could be hashed)
        sessionStore.loadSession({
          documentKey: Math.random().toString(36).substring(2),
          fileName: 'Untitled.pdf',
          pageCount: metrics.length,
          dirty: false,
        });
      }
    }
    load();
    return () => {
      mounted = false;
    };
  }, [fileData]);

  // Subscribe to active page updates (not strictly necessary here but
  // demonstrates listening to session state changes).  We store it in
  // local state purely for demonstration; the activePage could also be
  // read directly from sessionStore.viewState.
  const [, setActivePage] = useState<number>(1);
  useEffect(() => {
    return sessionStore.subscribeViewState((v) => {
      setActivePage(v.activePage);
    });
  }, []);

  // Render nothing if no document is loaded yet
  if (!doc) {
    return <div className="pdf-viewer-empty">No document loaded</div>;
  }

  return (
    <div className="pdf-viewer" style={{ overflowY: 'auto', width: '100%', height: '100%' }}>
      {pageMetrics.map((metric) => (
        <div key={metric.pageNumber} style={{ marginBottom: '16px' }}>
          <PageCanvas
            doc={doc}
            pageNumber={metric.pageNumber}
            metric={metric}
          />
        </div>
      ))}
    </div>
  );
};