/*
 * Central workspace where the PDF viewer and overlays will be rendered.
 */

import React from 'react';

export default function DocumentWorkspace(): JSX.Element {
  return (
    <section className="doccraft-document-workspace" style={{ flex: 1 }}>
      {/* PDF pages and interactive layers will be inserted here */}
    </section>
  );
}
