/*
 * Inspector panel for displaying properties of selected objects.  The
 * redesign calls for multiple tabs (properties, style, geometry, etc.)
 * which will be added later.  Currently this component is a stub.
 */

import React from 'react';

export default function InspectorPanel(): JSX.Element {
  return (
    <aside className="doccraft-inspector-panel">
      {/* Inspector content goes here */}
    </aside>
  );
}
