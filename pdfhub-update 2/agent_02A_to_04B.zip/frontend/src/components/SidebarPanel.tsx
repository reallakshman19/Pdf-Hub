/*
 * Sidebar panel component.  Displays context sensitive panels such as
 * thumbnails, search results, comments or macros.  This placeholder
 * simply reserves space for future panels.
 */

import React from 'react';

export default function SidebarPanel(): JSX.Element {
  return (
    <section className="doccraft-sidebar-panel">
      {/* Contextual sidebar content */}
    </section>
  );
}
