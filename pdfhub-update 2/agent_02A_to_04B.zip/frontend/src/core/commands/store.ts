/*
 * Command store for DocCraft.
 *
 * The store records all executed commands in chronological order and
 * provides undo/redo functionality.  It delegates actual execution to
 * handlers registered in the registry module.
 */

import { PdfCommand, PdfCommandResult } from './types';
import { getCommandHandler } from './registry';

export class CommandStore {
  private history: PdfCommand[] = [];
  private future: PdfCommand[] = [];

  /**
   * Execute a command by dispatching it to the registered handler and
   * recording it in the history.  If no handler is registered the
   * command is still recorded but no side effects occur.
   */
  apply(command: PdfCommand): PdfCommandResult {
    const handler = getCommandHandler(command.type);
    if (handler) {
      try {
        handler(command);
      } catch (err) {
        return {
          commandId: command.id,
          ok: false,
          dirty: false,
          message: (err as Error).message,
        };
      }
    }
    this.history.push(command);
    // clearing future commands after a new command is applied
    this.future = [];
    return {
      commandId: command.id,
      ok: true,
      dirty: true,
    };
  }

  /**
   * Undo the most recently executed command by popping it from the history
   * and pushing it onto the future stack.  This method does not
   * automatically run inverse commands; handlers should record their own
   * inverses if needed.
   */
  undo(): PdfCommand | undefined {
    const cmd = this.history.pop();
    if (cmd) {
      this.future.push(cmd);
    }
    return cmd;
  }

  /**
   * Redo the most recently undone command by popping it from the future
   * stack and pushing it back onto the history.  Does not re‑execute the
   * command handler; the caller should handle re‑execution if necessary.
   */
  redo(): PdfCommand | undefined {
    const cmd = this.future.pop();
    if (cmd) {
      this.history.push(cmd);
    }
    return cmd;
  }

  /**
   * Returns a copy of the executed command history.  Useful for debugging.
   */
  getHistory(): PdfCommand[] {
    return [...this.history];
  }

  /**
   * Returns a copy of the future stack.  Useful for debugging.
   */
  getFuture(): PdfCommand[] {
    return [...this.future];
  }
}
