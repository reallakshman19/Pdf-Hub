import { useCallback } from 'react';
import type { PdfCommand } from './types';
import { executeCommand } from './executor';
import { previewCommand } from './preview';

/**
 * A React hook that returns a dispatcher for PDF commands.  The
 * dispatcher optionally previews the command and waits for user
 * confirmation before executing if the command is considered
 * destructive.  In the preview build the hook always executes the
 * command immediately.
 */
export function useCommandDispatcher() {
  return useCallback(async (cmd: PdfCommand) => {
    // In a full implementation we would inspect cmd.risk and prompt
    // confirmation for destructive actions.  For now, execute directly.
    const _preview = previewCommand(cmd);
    return executeCommand(cmd);
  }, []);
}