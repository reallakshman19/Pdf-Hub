/*
 * Validators for DocCraft command objects.
 *
 * A validator ensures that a command is structurally sound before it is
 * dispatched to a handler.  Additional validation can be implemented
 * elsewhere (for example, verifying that a page number exists) but basic
 * structural checks belong here.
 */

import { PdfCommand } from './types';

/**
 * Validate that a command has the expected properties.  This function
 * performs minimal type checking and should be extended as new command
 * properties are added.  It returns `true` if the command is valid and
 * `false` otherwise.
 */
export function validateCommand(cmd: PdfCommand): boolean {
  if (!cmd) return false;
  if (typeof cmd.id !== 'string') return false;
  if (typeof cmd.type !== 'string') return false;
  if (!cmd.documentKey || typeof cmd.documentKey !== 'string') return false;
  // A command must have a creation timestamp; we do not validate its format
  if (typeof cmd.createdAt !== 'string') return false;
  // The payload may be an object or undefined depending on the type; no
  // further checks performed here.
  return true;
}
