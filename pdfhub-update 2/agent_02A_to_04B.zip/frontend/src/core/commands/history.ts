/*
 * Simplified history management for the DocCraft command system.
 *
 * This module exposes a standalone history structure separate from the
 * CommandStore.  Consumers may choose to use this class instead of
 * maintaining their own arrays in CommandStore.  Each entry records only
 * the command identifier; the full command is stored elsewhere.
 */

export interface HistoryEntry {
  commandId: string;
}

export class CommandHistory {
  private past: HistoryEntry[] = [];
  private future: HistoryEntry[] = [];

  add(entry: HistoryEntry): void {
    this.past.push(entry);
    this.future = [];
  }

  undo(): HistoryEntry | undefined {
    const entry = this.past.pop();
    if (entry) {
      this.future.push(entry);
    }
    return entry;
  }

  redo(): HistoryEntry | undefined {
    const entry = this.future.pop();
    if (entry) {
      this.past.push(entry);
    }
    return entry;
  }

  clear(): void {
    this.past = [];
    this.future = [];
  }

  getPast(): HistoryEntry[] {
    return [...this.past];
  }

  getFuture(): HistoryEntry[] {
    return [...this.future];
  }
}
