/*
 * Command type definitions for the DocCraft PDF workbench.
 *
 * Each command represents a single atomic operation that can be applied to a
 * PDF document or its overlays.  Commands are versioned by their `type`
 * property and extended via the `payload` property.  The contract defined
 * here must remain backwards compatible; adding new command types is
 * permitted, but existing types must not be removed or radically changed.
 */

export type PdfCommandSource =
  | 'user'
  | 'macro'
  | 'ai'
  | 'system';

export type PdfCommandRisk =
  | 'safe'
  | 'destructive-preview-required'
  | 'destructive-confirm-required'
  | 'server-only';

/**
 * Base interface for all commands.  A command must have a unique `id` and
 * specify its `type`.  The `payload` generic parameter allows each
 * command to define its own structure while preserving common metadata.
 */
export interface PdfCommandBase<TType extends string, TPayload> {
  id: string;
  type: TType;
  source: PdfCommandSource;
  risk: PdfCommandRisk;
  createdAt: string;
  documentKey: string;
  payload: TPayload;
}

export interface PdfCommandResult {
  commandId: string;
  ok: boolean;
  dirty: boolean;
  message?: string;
  inverseCommand?: PdfCommand;
  diagnostics?: Record<string, unknown>;
}

export interface PdfCommandPreview {
  commandId: string;
  title: string;
  summary: string;
  affectedPages: number[];
  warnings: string[];
  before?: unknown;
  after?: unknown;
}

export type Rect = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type PdfPoint = {
  pageNumber: number;
  x: number;
  y: number;
  coordinateSpace: 'pdf-points';
};

/*
 * Annotation commands
 */
export type AddAnnotationCommand = PdfCommandBase<
  'ANNOTATION_ADD',
  {
    annotationType:
      | 'highlight'
      | 'note'
      | 'callout'
      | 'stamp'
      | 'ink'
      | 'shape';
    pageNumber: number;
    rect: Rect;
    style: Record<string, unknown>;
    content?: string;
  }
>;

export type UpdateAnnotationCommand = PdfCommandBase<
  'ANNOTATION_UPDATE',
  {
    annotationId: string;
    patch: Record<string, unknown>;
  }
>;

export type DeleteAnnotationCommand = PdfCommandBase<
  'ANNOTATION_DELETE',
  {
    annotationIds: string[];
  }
>;

/*
 * Writer overlay commands
 */
export type AddWriterOverlayCommand = PdfCommandBase<
  'WRITER_OVERLAY_ADD',
  {
    overlayType: 'textBox' | 'image' | 'table' | 'link';
    pageNumber: number;
    rect: Rect;
    content: unknown;
    style: Record<string, unknown>;
  }
>;

export type UpdateWriterOverlayCommand = PdfCommandBase<
  'WRITER_OVERLAY_UPDATE',
  {
    overlayId: string;
    patch: Record<string, unknown>;
  }
>;

export type DeleteWriterOverlayCommand = PdfCommandBase<
  'WRITER_OVERLAY_DELETE',
  {
    overlayIds: string[];
  }
>;

/*
 * Page organize commands
 */
export type OrganizePagesCommand = PdfCommandBase<
  'PAGES_ORGANIZE',
  {
    operation:
      | 'insertBlank'
      | 'insertFromFile'
      | 'delete'
      | 'duplicate'
      | 'rotate'
      | 'replace'
      | 'reorder'
      | 'extract'
      | 'split';
    pageNumbers: number[];
    targetIndex?: number;
    rotation?: 90 | 180 | 270;
    sourceDocumentKey?: string;
    sourcePageNumbers?: number[];
  }
>;

/*
 * OCR commands
 */
export type StartOcrCommand = PdfCommandBase<
  'OCR_START',
  {
    pageNumbers: number[];
    mode: 'auto' | 'region';
    language: string;
    regions?: Array<{
      pageNumber: number;
      rect: Rect;
    }>;
  }
>;

export type CommitOcrTextLayerCommand = PdfCommandBase<
  'OCR_COMMIT_TEXT_LAYER',
  {
    jobId: string;
    pageNumbers: number[];
    searchable: boolean;
  }
>;

/*
 * Bookmark commands
 */
export type AddBookmarkCommand = PdfCommandBase<
  'BOOKMARK_ADD',
  {
    title: string;
    pageNumber: number;
    x?: number;
    y?: number;
    parentId?: string;
  }
>;

export type UpdateBookmarkCommand = PdfCommandBase<
  'BOOKMARK_UPDATE',
  {
    bookmarkId: string;
    patch: Record<string, unknown>;
  }
>;

export type DeleteBookmarkCommand = PdfCommandBase<
  'BOOKMARK_DELETE',
  {
    bookmarkIds: string[];
  }
>;

/*
 * Macro and AI commands
 */
export type MacroCommand = PdfCommandBase<
  'MACRO_RUN',
  {
    macroId: string;
    commands: PdfCommand[];
  }
>;

export type AiGeneratedCommand = PdfCommandBase<
  'AI_GENERATED_COMMAND',
  {
    prompt: string;
    proposedCommands: PdfCommand[];
    explanation: string;
    requiresUserConfirmation: true;
  }
>;

/*
 * Redaction commands
 */
export type PreviewRedactionCommand = PdfCommandBase<
  'REDACTION_PREVIEW',
  {
    pageNumber: number;
    rects: Rect[];
    reason?: string;
  }
>;

export type ApplyRedactionCommand = PdfCommandBase<
  'REDACTION_APPLY',
  {
    redactionPreviewId: string;
    pageRects: Array<{
      pageNumber: number;
      rects: Rect[];
    }>;
    removeText: true;
    removeImages: true;
    removeAnnotations: true;
    removeOcrText: true;
  }
>;

/*
 * Union type for all commands.  Extending this union should be done by
 * appending additional command types rather than replacing it.
 */
export type PdfCommand =
  | AddAnnotationCommand
  | UpdateAnnotationCommand
  | DeleteAnnotationCommand
  | AddWriterOverlayCommand
  | UpdateWriterOverlayCommand
  | DeleteWriterOverlayCommand
  | OrganizePagesCommand
  | StartOcrCommand
  | CommitOcrTextLayerCommand
  | AddBookmarkCommand
  | UpdateBookmarkCommand
  | DeleteBookmarkCommand
  | MacroCommand
  | AiGeneratedCommand
  | PreviewRedactionCommand
  | ApplyRedactionCommand;
