/*
 * Command registry for the DocCraft PDF workbench.
 *
 * Handlers registered here receive validated command objects and perform
 * whatever side effects are appropriate for the running environment.  In
 * preview mode, handlers might update in‑memory state; in server mode they
 * should call the backend.  This file exposes functions to register and
 * retrieve handlers.
 */

import { PdfCommand } from './types';

export type CommandHandler = (command: PdfCommand) => void;

// Internal map from command type to handler function.  Handlers can be
// registered at runtime; only one handler may exist per command type.
const commandRegistry: Record<string, CommandHandler> = {};

/**
 * Register a handler for a specific command type.  If a handler is already
 * registered for this type it will be replaced.
 */
export function registerCommand(
  type: string,
  handler: CommandHandler
): void {
  commandRegistry[type] = handler;
}

/**
 * Retrieve the handler for a command type.  Returns `undefined` if no
 * handler is registered.
 */
export function getCommandHandler(type: string): CommandHandler | undefined {
  return commandRegistry[type];
}

/**
 * Reset the registry.  Primarily used in tests to ensure a clean slate.
 */
export function clearRegistry(): void {
  Object.keys(commandRegistry).forEach((key) => {
    delete commandRegistry[key];
  });
}
