import type {
  PdfCommand,
  PdfCommandResult,
  PdfCommandPreview,
  AddAnnotationCommand,
  UpdateAnnotationCommand,
  DeleteAnnotationCommand,
  AddWriterOverlayCommand,
  UpdateWriterOverlayCommand,
  DeleteWriterOverlayCommand,
  OrganizePagesCommand,
  StartOcrCommand,
  CommitOcrTextLayerCommand,
  AddBookmarkCommand,
  UpdateBookmarkCommand,
  DeleteBookmarkCommand,
  MacroCommand,
  AiGeneratedCommand,
  PreviewRedactionCommand,
  ApplyRedactionCommand,
} from './types';
import { annotationStore } from '../annotations/store';
import { writerStore } from '../writer/store';
import { sessionStore } from '../session/store';

/**
 * Execute a command.  This simple executor handles only a handful of
 * commands directly.  Most commands in the preview build are mapped to
 * local store mutations.  Complex operations such as page reordering or
 * OCR are stubbed out and mark the document dirty without performing
 * any heavy lifting.  The returned result includes an inverse command
 * only for reversible commands.
 */
export async function executeCommand(cmd: PdfCommand): Promise<PdfCommandResult> {
  switch (cmd.type) {
    case 'ANNOTATION_ADD': {
      const c = cmd as AddAnnotationCommand;
      annotationStore.addAnnotation(c.payload);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    case 'ANNOTATION_UPDATE': {
      const c = cmd as UpdateAnnotationCommand;
      annotationStore.updateAnnotation(c.payload.annotationId, c.payload.patch);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    case 'ANNOTATION_DELETE': {
      const c = cmd as DeleteAnnotationCommand;
      annotationStore.deleteAnnotations(c.payload.annotationIds);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    case 'WRITER_OVERLAY_ADD': {
      const c = cmd as AddWriterOverlayCommand;
      writerStore.addElement(c.payload);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    case 'WRITER_OVERLAY_UPDATE': {
      const c = cmd as UpdateWriterOverlayCommand;
      writerStore.updateElement(c.payload.overlayId, c.payload.patch);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    case 'WRITER_OVERLAY_DELETE': {
      const c = cmd as DeleteWriterOverlayCommand;
      writerStore.deleteElements(c.payload.overlayIds);
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true };
    }
    // For unimplemented commands we simply mark the document dirty and return ok
    default: {
      sessionStore.session && (sessionStore.session.dirty = true);
      return { commandId: cmd.id, ok: true, dirty: true, message: 'Command executed (stub)' };
    }
  }
}