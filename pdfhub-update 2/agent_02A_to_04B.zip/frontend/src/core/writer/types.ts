/**
 * Type definitions for writer overlay elements.  These overlays are
 * separate from the underlying PDF text and are merged into the final
 * document only when exported.  Each element shares a common base with
 * geometry and locked status, but has specific fields depending on
 * its type.
 */

export type WriterElementType =
  | 'textBox'
  | 'image'
  | 'tableOverlay'
  | 'link';

export interface WriterElementBase {
  id: string;
  type: WriterElementType;
  pageNumber: number;
  rect: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  locked?: boolean;
}

export interface WriterTextBoxElement extends WriterElementBase {
  type: 'textBox';
  text: string;
  style: {
    fontFamily: string;
    fontSize: number;
    bold: boolean;
    italic: boolean;
    underline: boolean;
    color: string;
    align: 'left' | 'center' | 'right' | 'justify';
  };
}

export interface WriterImageElement extends WriterElementBase {
  type: 'image';
  imageId: string;
  mimeType: string;
  altText?: string;
}

export interface WriterTableOverlayElement extends WriterElementBase {
  type: 'tableOverlay';
  rows: number;
  columns: number;
  cells: Array<{
    row: number;
    column: number;
    text: string;
  }>;
}

export interface WriterLinkElement extends WriterElementBase {
  type: 'link';
  url: string;
  label?: string;
}

export type WriterElement =
  | WriterTextBoxElement
  | WriterImageElement
  | WriterTableOverlayElement
  | WriterLinkElement;