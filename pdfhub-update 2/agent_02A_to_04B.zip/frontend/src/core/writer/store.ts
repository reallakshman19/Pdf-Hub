import { WriterElement } from './types';

/**
 * A simple in‑memory store for writer overlay elements.  Each element is
 * stored by id and the store notifies subscribers on changes.  The
 * store does not persist by itself; persistence should be implemented
 * by higher layers.
 */
class WriterStore {
  private elements = new Map<string, WriterElement>();
  private subscribers = new Set<() => void>();

  subscribe(cb: () => void): () => void {
    this.subscribers.add(cb);
    cb();
    return () => {
      this.subscribers.delete(cb);
    };
  }

  private notify(): void {
    this.subscribers.forEach((cb) => cb());
  }

  getAll(): WriterElement[] {
    return Array.from(this.elements.values());
  }

  addElement(element: WriterElement): void {
    this.elements.set(element.id, element);
    this.notify();
  }

  updateElement(id: string, patch: Partial<WriterElement>): void {
    const existing = this.elements.get(id);
    if (!existing) return;
    const updated = { ...existing, ...patch } as WriterElement;
    this.elements.set(id, updated);
    this.notify();
  }

  deleteElements(ids: string[]): void {
    ids.forEach((id) => this.elements.delete(id));
    this.notify();
  }

  clear(): void {
    this.elements.clear();
    this.notify();
  }
}

export const writerStore = new WriterStore();