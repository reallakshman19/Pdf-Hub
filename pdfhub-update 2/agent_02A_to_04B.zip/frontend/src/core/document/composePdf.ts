import { Annotation } from '../annotations/types';
import { WriterElement } from '../writer/types';

/**
 * Compose a new PDF from the base document and current annotations and
 * writer overlays.  In the preview build this function simply returns
 * the original bytes unchanged.  A real implementation would use
 * pdf-lib or a server to flatten annotations and overlays into the
 * document.
 */
export async function composeCommittedPdf(
  baseBytes: Uint8Array,
  annotations: Annotation[],
  overlays: WriterElement[],
): Promise<Uint8Array> {
  void annotations;
  void overlays;
  // Return a copy of the input bytes to avoid mutating the caller's buffer
  return new Uint8Array(baseBytes);
}