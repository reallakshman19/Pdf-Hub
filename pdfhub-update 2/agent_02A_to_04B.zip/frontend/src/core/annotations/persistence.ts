import { Annotation } from './types';

/**
 * Persistence utilities for annotations.  These functions abstract
 * saving and loading annotations to and from client‑side storage.
 * In the preview build they simply resolve immediately and do not
 * actually persist data.  Future implementations may use IndexedDB
 * (preferred) or other storage mechanisms.
 */

/** Save annotations for a document key. */
export async function saveAnnotations(documentKey: string, annos: Annotation[]): Promise<void> {
  // In preview mode, do nothing.  This stub resolves immediately.
  void documentKey;
  void annos;
  return;
}

/** Load annotations for a document key. */
export async function loadAnnotations(documentKey: string): Promise<Annotation[]> {
  void documentKey;
  // Always return an empty array in preview mode.
  return [];
}