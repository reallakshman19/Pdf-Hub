/**
 * Type definitions for PDF annotations.  These types describe the
 * basic properties shared by all annotations (id, page, geometry and
 * author) along with specialised annotation payloads for specific
 * tools.  Additional properties can be added over time without
 * breaking existing annotations.  Annotation IDs should be unique
 * within a document.
 */

export type AnnotationType =
  | 'highlight'
  | 'underline'
  | 'strikeout'
  | 'squiggly'
  | 'sticky-note'
  | 'comment'
  | 'callout'
  | 'stamp'
  | 'rectangle'
  | 'ellipse'
  | 'line'
  | 'arrow'
  | 'freehand';

export interface AnnotationBase {
  /** Unique identifier for the annotation. */
  id: string;
  /** The page number (1‑based) this annotation belongs to. */
  pageNumber: number;
  /** Position and size of the annotation on the page. */
  rect: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  /** Optional author of the annotation. */
  author?: string;
  /** Optional creation timestamp. */
  createdAt?: string;
  /** Optional last modification timestamp. */
  modifiedAt?: string;
  /** Whether the annotation is locked against editing. */
  locked?: boolean;
}

export interface HighlightAnnotation extends AnnotationBase {
  type: 'highlight';
  color: string;
}

export interface UnderlineAnnotation extends AnnotationBase {
  type: 'underline';
  color: string;
}

export interface StrikeoutAnnotation extends AnnotationBase {
  type: 'strikeout';
  color: string;
}

export interface SquigglyAnnotation extends AnnotationBase {
  type: 'squiggly';
  color: string;
}

export interface StickyNoteAnnotation extends AnnotationBase {
  type: 'sticky-note';
  content: string;
}

export interface CommentAnnotation extends AnnotationBase {
  type: 'comment';
  content: string;
}

export interface CalloutAnnotation extends AnnotationBase {
  type: 'callout';
  content: string;
  pointer: {
    x: number;
    y: number;
  };
}

export interface StampAnnotation extends AnnotationBase {
  type: 'stamp';
  stampType: string;
}

export interface ShapeAnnotation extends AnnotationBase {
  type: 'rectangle' | 'ellipse';
  strokeColor: string;
  fillColor: string;
}

export interface LineAnnotation extends AnnotationBase {
  type: 'line' | 'arrow';
  end: {
    x: number;
    y: number;
  };
  color: string;
}

export interface FreehandAnnotation extends AnnotationBase {
  type: 'freehand';
  points: Array<{ x: number; y: number }>;
  color: string;
  width: number;
}

export type Annotation =
  | HighlightAnnotation
  | UnderlineAnnotation
  | StrikeoutAnnotation
  | SquigglyAnnotation
  | StickyNoteAnnotation
  | CommentAnnotation
  | CalloutAnnotation
  | StampAnnotation
  | ShapeAnnotation
  | LineAnnotation
  | FreehandAnnotation;