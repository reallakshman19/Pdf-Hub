import { Annotation } from './types';

/**
 * A basic in‑memory annotation store.  Each annotation is stored in a
 * map keyed by its id.  Consumers can subscribe to changes to be
 * notified whenever annotations are added, updated or removed.  The
 * store does not persist annotations; persistence must be handled by
 * higher‑level code.
 */
class AnnotationStore {
  private annotations = new Map<string, Annotation>();
  private subscribers = new Set<() => void>();

  subscribe(cb: () => void): () => void {
    this.subscribers.add(cb);
    // Immediately notify subscriber of current state
    cb();
    return () => {
      this.subscribers.delete(cb);
    };
  }

  private notify(): void {
    this.subscribers.forEach((cb) => cb());
  }

  /** Get an array of all annotations. */
  getAll(): Annotation[] {
    return Array.from(this.annotations.values());
  }

  /** Add a new annotation.  If an annotation with the same id exists
   * it will be overwritten. */
  addAnnotation(anno: Annotation): void {
    this.annotations.set(anno.id, anno);
    this.notify();
  }

  /** Update an annotation by id.  Only the fields provided in the patch
   * are updated.  If the annotation does not exist nothing happens. */
  updateAnnotation(id: string, patch: Partial<Annotation>): void {
    const existing = this.annotations.get(id);
    if (!existing) return;
    const updated = { ...existing, ...patch } as Annotation;
    this.annotations.set(id, updated);
    this.notify();
  }

  /** Delete one or more annotations by id. */
  deleteAnnotations(ids: string[]): void {
    ids.forEach((id) => this.annotations.delete(id));
    this.notify();
  }

  /** Clear all annotations. */
  clear(): void {
    this.annotations.clear();
    this.notify();
  }
}

export const annotationStore = new AnnotationStore();