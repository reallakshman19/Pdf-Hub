/*
 * Types for the DocCraft editor state.
 *
 * The editor state tracks high‑level information about the current
 * application mode and any global UI flags.  It does not include
 * per‑document state such as annotations or writer overlays; those are
 * stored separately in their respective modules.
 */

export type WorkbenchMode =
  | 'view'
  | 'annotate'
  | 'draw'
  | 'write'
  | 'organize'
  | 'generate';

export interface EditorState {
  /**
   * The current mode of the workbench.  Determines which toolbar and
   * interactions are active.
   */
  mode: WorkbenchMode;
}
