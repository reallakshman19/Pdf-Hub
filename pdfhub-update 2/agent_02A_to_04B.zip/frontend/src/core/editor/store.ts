/*
 * Editor state store for DocCraft.
 *
 * This class tracks the current mode and exposes methods to get and set
 * the editor state.  It does not depend on any external state management
 * library so that tests can run without React or Zustand installed.
 */

import { EditorState, WorkbenchMode } from './types';

export class EditorStore {
  private state: EditorState;

  constructor(initialMode: WorkbenchMode = 'view') {
    this.state = { mode: initialMode };
  }

  /**
   * Returns a copy of the current editor state.
   */
  getState(): EditorState {
    return { ...this.state };
  }

  /**
   * Sets the current workbench mode.  No validation is performed here; it
   * is the caller's responsibility to pass a valid `WorkbenchMode`.
   */
  setMode(mode: WorkbenchMode): void {
    this.state.mode = mode;
  }

  /**
   * Resets the editor state to its default values.
   */
  reset(): void {
    this.state.mode = 'view';
  }
}
