import { DocumentSession, ViewState, LayoutMode } from './types';

/**
 * A simple in‑memory store for managing the current document session and view
 * state.  This store is deliberately lightweight and does not rely on
 * external state management libraries.  It exposes subscribe methods that
 * allow components to react to changes.  The store does not persist
 * automatically; external code must handle serialisation if required.
 */
export class SessionStore {
  private _session: DocumentSession | null = null;
  private _viewState: ViewState = {
    zoom: 1,
    activePage: 1,
    layout: 'continuous',
    tool: 'pan',
  };

  private sessionSubscribers = new Set<(s: DocumentSession | null) => void>();
  private viewStateSubscribers = new Set<(v: ViewState) => void>();

  /**
   * Subscribe to session changes.  The callback is invoked whenever a new
   * document is loaded or the session is cleared.  Returns an unsubscribe
   * function.
   */
  subscribeSession(cb: (s: DocumentSession | null) => void): () => void {
    this.sessionSubscribers.add(cb);
    cb(this._session);
    return () => {
      this.sessionSubscribers.delete(cb);
    };
  }

  /**
   * Subscribe to view state changes.  The callback is invoked whenever the
   * zoom, active page or layout changes.  Returns an unsubscribe function.
   */
  subscribeViewState(cb: (v: ViewState) => void): () => void {
    this.viewStateSubscribers.add(cb);
    cb(this._viewState);
    return () => {
      this.viewStateSubscribers.delete(cb);
    };
  }

  /** Load a new document into the session. */
  loadSession(session: DocumentSession): void {
    this._session = session;
    // Reset view state on new load
    this._viewState = {
      zoom: 1,
      activePage: 1,
      layout: 'continuous',
      tool: 'pan',
    };
    this.sessionSubscribers.forEach((cb) => cb(session));
    this.viewStateSubscribers.forEach((cb) => cb(this._viewState));
  }

  /** Clear the current session. */
  clearSession(): void {
    this._session = null;
    this.sessionSubscribers.forEach((cb) => cb(null));
  }

  get session(): DocumentSession | null {
    return this._session;
  }

  get viewState(): ViewState {
    return this._viewState;
  }

  /** Set the zoom level. */
  setZoom(zoom: number): void {
    if (zoom <= 0) return;
    this._viewState = { ...this._viewState, zoom };
    this.viewStateSubscribers.forEach((cb) => cb(this._viewState));
  }

  /** Set the active page (1‑based). */
  setActivePage(pageNumber: number): void {
    if (pageNumber < 1 || !this._session) return;
    const clamped = Math.min(Math.max(pageNumber, 1), this._session.pageCount);
    this._viewState = { ...this._viewState, activePage: clamped };
    this.viewStateSubscribers.forEach((cb) => cb(this._viewState));
  }

  /** Set the layout mode. */
  setLayout(layout: LayoutMode): void {
    this._viewState = { ...this._viewState, layout };
    this.viewStateSubscribers.forEach((cb) => cb(this._viewState));
  }

  /** Set the current tool (e.g. pan or select). */
  setTool(tool: 'select' | 'pan'): void {
    this._viewState = { ...this._viewState, tool };
    this.viewStateSubscribers.forEach((cb) => cb(this._viewState));
  }
}

// Export a singleton instance of the session store.  In a larger application
// this could be provided via dependency injection instead of a global.
export const sessionStore = new SessionStore();