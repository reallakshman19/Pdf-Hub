/**
 * Types for managing the current PDF document session and viewer state.
 *
 * The `DocumentSession` tracks metadata about the currently loaded PDF file,
 * including a stable key used for caching and persistence, the human‑readable
 * file name, the total number of pages and whether the document has been
 * modified (dirty flag).  This structure can be extended to include
 * additional information such as file size or checksum without breaking
 * existing code.
 *
 * The `ViewState` describes how the user is currently viewing the document.
 * It captures the zoom level, which page is considered the active page
 * (usually the one in the centre of the viewport) and the layout mode.  The
 * layout can be continuous (default), single page or two‑page spreads.  A
 * simple pan/select tool is included here to allow future input modes (e.g.
 * pan, select, annotation) to be tracked globally.
 */

export interface DocumentSession {
  /** A unique key derived from the file contents (e.g. hash) for caching. */
  documentKey: string;
  /** The original file name of the loaded PDF, used for display. */
  fileName: string;
  /** Total number of pages in the document. */
  pageCount: number;
  /** Whether the document has unsaved modifications. */
  dirty: boolean;
}

export type LayoutMode = 'continuous' | 'single' | 'two-page';

export interface ViewState {
  /** Current zoom level as a multiplier (1 = 100% scaling). */
  zoom: number;
  /** The currently active page number (1‑based). */
  activePage: number;
  /** Layout mode for displaying pages. */
  layout: LayoutMode;
  /** Current tool used in view mode (pan/scroll or selection). */
  tool: 'select' | 'pan';
}