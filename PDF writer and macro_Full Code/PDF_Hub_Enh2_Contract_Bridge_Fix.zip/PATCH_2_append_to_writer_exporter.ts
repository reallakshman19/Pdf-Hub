/**
 * PDF_Hub_Enh2 Contract Bridge
 * --------------------------------
 * Add this line near the bottom of:
 *   frontend/src/core/writer/exporter.ts
 *
 * Some base files import visibleWriterElementsForExport from exporter.ts.
 * The canonical implementation lives in writerObjects.ts.
 */

export {
  visibleWriterElementsForExport,
} from './writerObjects';
