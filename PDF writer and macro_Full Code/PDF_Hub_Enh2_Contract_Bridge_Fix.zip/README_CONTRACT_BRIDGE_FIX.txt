PDF_HUB_ENH2 — CONTRACT BRIDGE FIX PACK
=======================================

Use this fix when the applied Phase B–J files produce many TypeScript errors such as:

- macro/types.ts expects WriterStyles and WriterTableData from writer/types.ts
- writer/types.ts only has WriterElementStyle and WriterTableModel
- writer store expects WriterTool
- visibleWriterElementsForExport is imported from exporter.ts but only exists in writerObjects.ts
- content-ops.ts returns StepResult synchronously but registry expects Promise<StepResult>

This is a contract-version mismatch. Apply this bridge before manually patching call sites.

Application:
  1. Append PATCH_1 to frontend/src/core/writer/types.ts
  2. Append PATCH_2 to frontend/src/core/writer/exporter.ts
  3. Replace frontend/src/core/macro/registry.ts with PATCH_3
  4. Append PATCH_4 to frontend/src/core/macro/types.ts only if required
  5. Copy PATCH_5 to frontend/scripts/enh2-contract-bridge-audit.mjs

Then run:
  cd frontend
  npm run typecheck
  node scripts/enh2-contract-bridge-audit.mjs
  npm run audit:writer
  npm run audit:macro
