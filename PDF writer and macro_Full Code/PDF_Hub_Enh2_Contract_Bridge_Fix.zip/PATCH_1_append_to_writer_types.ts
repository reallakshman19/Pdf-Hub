/**
 * PDF_Hub_Enh2 Contract Bridge
 * --------------------------------
 * Add this block at the END of:
 *   frontend/src/core/writer/types.ts
 *
 * Purpose:
 * Keeps older/base writer+macro files compiling after Phase B introduced
 * WriterElementStyle / WriterTableModel canonical names.
 *
 * Do not remove the canonical Phase B names.
 * These are compatibility aliases and small missing contracts.
 */

export type WriterTool =
  | 'select'
  | 'pan'
  | 'text'
  | 'rich-text'
  | 'table'
  | 'image'
  | 'template'
  | 'header-footer'
  | 'inspect'
  | 'object-list';

/**
 * Legacy/base alias.
 * Canonical Phase B name remains WriterElementStyle.
 */
export type WriterStyles = WriterElementStyle;

/**
 * Legacy/base alias.
 * Canonical Phase B name remains WriterTableModel.
 */
export type WriterTableData = WriterTableModel;

export interface WriterSelectionState {
  selectedElementId: string | null;
  selectedTool: WriterTool;
}

export interface WriterStoreSnapshot {
  tool: WriterTool;
  elements: PlacedElement[];
  selectedElementId: string | null;
}
