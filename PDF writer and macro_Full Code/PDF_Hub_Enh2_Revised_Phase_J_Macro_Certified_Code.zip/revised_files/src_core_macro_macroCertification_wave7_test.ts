import { describe, expect, it, beforeEach } from 'vitest';
import type {
  MacroExecutionContext,
  MacroRecipe,
} from './types';
import {
  executeMacroRecipe,
} from './executor';
import {
  macroRegistry,
} from './registry';
import {
  validateMacroRecipe,
} from './validator';
import {
  validateMacroRecipeWithSchema,
} from './builder/recipeBuilderState';
import {
  getBuiltInMacroRecipes,
} from './recipes/builtInRecipes';
import {
  importMacroRecipeJson,
  upsertCustomMacroRecipe,
  loadCustomMacroRecipes,
} from './recipes/recipeStorage';
import {
  createMacroExecutionContextFromSnapshot,
  applyMacroBytesToSnapshot,
} from './integration/macroExecutionContextAdapter';
import {
  safeMacroFontFamily,
} from './security';
import {
  createContentDiagnostics,
} from './steps/content-ops';
import './register-all';

function ctx(): MacroExecutionContext {
  return {
    workingBytes: new Uint8Array([1, 2, 3, 4]),
    pageCount: 3,
    selectedPages: [2],
    currentPage: 1,
    fileName: 'sample.pdf',
    options: {
      abortOnError: true,
    },
  };
}

describe('macro certification wave 7', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('registry has critical operations', () => {
    expect(macroRegistry.has('select_pages')).toBe(true);
    expect(macroRegistry.has('conditional')).toBe(true);
    expect(macroRegistry.has('place_table')).toBe(true);
    expect(macroRegistry.has('adjust_image')).toBe(true);
  });

  it('dry-run does not mutate bytes', async () => {
    const context = ctx();
    const result = await executeMacroRecipe(
      {
        id: 'dry',
        name: 'Dry',
        dryRun: true,
        steps: [
          {
            op: 'draw_text_on_pages',
            selector: { mode: 'all' },
            text: 'DRAFT',
            x: 10,
            y: 10,
            fontSize: 12,
          },
        ],
      },
      context,
    );

    expect(result.success).toBe(true);
    expect(result.finalBytes).toBe(context.workingBytes);
    expect(result.outputFiles).toEqual([]);
  });

  it('rollback restores selection after aborting error', async () => {
    const result = await executeMacroRecipe(
      {
        id: 'rollback',
        name: 'Rollback',
        steps: [
          {
            op: 'select_pages',
            selector: { mode: 'all' },
          },
          {
            op: 'replace_page',
            targetPage: 1,
            donorFileId: 'missing',
            donorPage: 1,
          },
        ],
      },
      ctx(),
    );

    expect(result.success).toBe(false);
    expect(result.selectedPages).toEqual([2]);
    expect(Array.from(result.finalBytes)).toEqual([1, 2, 3, 4]);
    expect(result.logs.some((line) => line.includes('rollback'))).toBe(true);
  });

  it('rejects invalid nested conditional schema recipe', () => {
    const result = validateMacroRecipeWithSchema({
      id: 'bad-nested',
      name: 'Bad Nested',
      steps: [
        {
          op: 'conditional',
          condition: {
            type: 'page_count_gt',
            value: 1,
          },
          then: [
            {
              op: 'not_registered',
            } as never,
          ],
        },
      ],
    });

    expect(result.valid).toBe(false);
    expect(result.issues.some((issue) => issue.field.includes('then'))).toBe(true);
  });

  it('unsafe image diagnostic does not report success', () => {
    const result = createContentDiagnostics({
      op: 'adjust_image',
      x: 0,
      y: 0,
      width: 100,
      height: 100,
      base64Image: 'javascript:alert(1)',
    });

    expect(result.status).toBe('error');
    expect(result.message).toContain('Unsafe image source blocked');
  });



  it('unsafe image execution step emits no bytes_updated side effect', async () => {
    const result = await executeMacroRecipe(
      {
        id: 'unsafe-image',
        name: 'Unsafe Image',
        steps: [
          {
            op: 'adjust_image',
            x: 0,
            y: 0,
            width: 100,
            height: 100,
            base64Image: 'javascript:alert(1)',
          },
        ],
      },
      {
        ...ctx(),
        options: {
          abortOnError: false,
        },
      },
    );

    expect(result.success).toBe(false);
    expect(result.stepResults[0].status).toBe('error');
    expect(result.stepResults[0].sideEffects.some((effect) => effect.type === 'bytes_updated')).toBe(false);
  });

  it('safeMacroFontFamily rejects active CSS payloads', () => {
    expect(safeMacroFontFamily('Arial; background:url(javascript:alert(1))')).toBe('Arial');
    expect(safeMacroFontFamily('Arial expression(alert(1))')).toBe('Arial');
    expect(safeMacroFontFamily('Arial javascript:alert(1)')).toBe('Arial');
  });

  it('every built-in recipe validates', () => {
    const recipes = getBuiltInMacroRecipes();

    expect(recipes.length).toBeGreaterThanOrEqual(20);

    for (const item of recipes) {
      const schemaResult = validateMacroRecipeWithSchema(item.recipe);
      const runtimeResult = validateMacroRecipe(item.recipe);

      expect(schemaResult.valid).toBe(true);
      expect(runtimeResult.valid).toBe(true);
    }
  });

  it('custom storage rejects invalid recipe import', () => {
    expect(() => importMacroRecipeJson('{bad')).toThrow(/Invalid macro recipe JSON/);

    expect(() =>
      importMacroRecipeJson(JSON.stringify({
        id: 'bad',
        name: '',
        steps: [],
      })),
    ).toThrow(/invalid/i);
  });

  it('custom storage saves valid recipe', () => {
    const recipe: MacroRecipe = {
      id: 'valid',
      name: 'Valid',
      steps: [
        {
          op: 'select_pages',
          selector: { mode: 'current' },
        },
      ],
    };

    upsertCustomMacroRecipe(recipe);

    expect(loadCustomMacroRecipes().length).toBe(1);
  });

  it('execution context adapter validates and clones runtime state', () => {
    const context = createMacroExecutionContextFromSnapshot({
      workingBytes: new Uint8Array([1, 2, 3]),
      pageCount: 5,
      selectedPages: [0, 1, 99, 2],
      currentPage: 99,
      fileName: 'x.pdf',
    });

    expect(Array.from(context.workingBytes)).toEqual([1, 2, 3]);
    expect(context.selectedPages).toEqual([1, 2]);
    expect(context.currentPage).toBe(5);

    const next = applyMacroBytesToSnapshot(
      {
        workingBytes: new Uint8Array([1]),
        pageCount: 1,
      },
      new Uint8Array([9]),
    );

    expect(Array.from(next.workingBytes)).toEqual([9]);
  });
});
