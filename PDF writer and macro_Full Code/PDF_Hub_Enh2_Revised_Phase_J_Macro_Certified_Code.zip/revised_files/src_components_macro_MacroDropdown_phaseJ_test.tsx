import React from 'react';
import { describe, expect, it, vi, beforeEach } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MacroDropdown } from './MacroDropdown';
import type {
  MacroExecutionContext,
} from '@/core/macro/types';

const executionContext: MacroExecutionContext = {
  workingBytes: new Uint8Array([1, 2, 3]),
  pageCount: 1,
  selectedPages: [],
  currentPage: 1,
  fileName: 'sample.pdf',
  options: {
    abortOnError: true,
  },
};

describe('MacroDropdown phase J', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('renders dropdown and opens builder', () => {
    const onOpenBuilder = vi.fn();

    render(
      <MacroDropdown
        executionContext={executionContext}
        onOpenBuilder={onOpenBuilder}
      />,
    );

    expect(screen.getByText('Macro Recipes')).toBeTruthy();

    fireEvent.click(screen.getByText('Builder'));

    expect(onOpenBuilder).toHaveBeenCalled();
  });

  it('runs dry-run recipe from dropdown', async () => {
    const onRunResult = vi.fn();

    render(
      <MacroDropdown
        executionContext={executionContext}
        onOpenBuilder={vi.fn()}
        onRunResult={onRunResult}
      />,
    );

    fireEvent.click(screen.getAllByText('Dry Run')[0]);

    await waitFor(() => expect(onRunResult).toHaveBeenCalled());

    expect(onRunResult.mock.calls[0][0].success).toBe(true);
  });

  it('reports missing execution context', async () => {
    const onError = vi.fn();

    render(
      <MacroDropdown
        onOpenBuilder={vi.fn()}
        onError={onError}
      />,
    );

    fireEvent.click(screen.getAllByText('Dry Run')[0]);

    await waitFor(() => expect(onError).toHaveBeenCalled());

    expect(onError.mock.calls[0][0]).toContain('No macro execution context');
  });

  it('opens builder with cloned recipe from card edit', () => {
    const onOpenBuilder = vi.fn();

    render(
      <MacroDropdown
        executionContext={executionContext}
        onOpenBuilder={onOpenBuilder}
      />,
    );

    fireEvent.click(screen.getAllByText('Edit')[0]);

    expect(onOpenBuilder).toHaveBeenCalled();
    expect(onOpenBuilder.mock.calls[0][0].id).toContain('custom-');
  });
});
