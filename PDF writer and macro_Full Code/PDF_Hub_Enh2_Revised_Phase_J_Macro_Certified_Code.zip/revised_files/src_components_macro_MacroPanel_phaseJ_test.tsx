import React from 'react';
import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MacroPanel } from './MacroPanel';
import type {
  MacroExecutionContext,
} from '@/core/macro/types';

const executionContext: MacroExecutionContext = {
  workingBytes: new Uint8Array([1, 2, 3]),
  pageCount: 1,
  selectedPages: [],
  currentPage: 1,
  fileName: 'sample.pdf',
  options: {
    abortOnError: true,
  },
};

describe('MacroPanel phase J', () => {
  it('renders panel shell', () => {
    render(<MacroPanel />);

    expect(screen.getByText('Macro Tools')).toBeTruthy();
    expect(screen.getByText('Open the macro dropdown or builder to start.')).toBeTruthy();
  });

  it('opens dropdown', () => {
    render(<MacroPanel />);

    fireEvent.click(screen.getByText('Dropdown'));

    expect(screen.getByText('Macro Recipes')).toBeTruthy();
  });

  it('opens builder', () => {
    render(<MacroPanel />);

    fireEvent.click(screen.getByText('Builder'));

    expect(screen.getByText('Macro Recipe Builder')).toBeTruthy();
  });

  it('does not commit bytes for dry-run result', async () => {
    const onCommitBytes = vi.fn();
    const onRunResult = vi.fn();

    render(
      <MacroPanel
        executionContext={executionContext}
        onCommitBytes={onCommitBytes}
        onRunResult={onRunResult}
      />,
    );

    fireEvent.click(screen.getByText('Dropdown'));
    fireEvent.click(screen.getAllByText('Dry Run')[0]);

    await waitFor(() => expect(onRunResult).toHaveBeenCalled());

    expect(onCommitBytes).not.toHaveBeenCalled();
  });
});
