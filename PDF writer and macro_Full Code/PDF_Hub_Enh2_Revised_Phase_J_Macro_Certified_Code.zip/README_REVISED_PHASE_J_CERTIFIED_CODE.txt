PDF_HUB_ENH2 — REVISED PHASE J MACRO APP INTEGRATION + CERTIFICATION
======================================================================

This ZIP contains the revised Phase J files after certification review.

Copy map:

  revised_files/src_core_macro_integration_macroUiStore.ts
    -> frontend/src/core/macro/integration/macroUiStore.ts

  revised_files/src_core_macro_integration_macroExecutionContextAdapter.ts
    -> frontend/src/core/macro/integration/macroExecutionContextAdapter.ts

  revised_files/src_components_macro_MacroDropdown.tsx
    -> frontend/src/components/macro/MacroDropdown.tsx

  revised_files/src_components_macro_MacroPanel.tsx
    -> frontend/src/components/macro/MacroPanel.tsx

  revised_files/scripts_macro_static_audit.mjs
    -> frontend/scripts/macro-static-audit.mjs

  revised_files/src_core_macro_macroCertification_wave7_test.ts
    -> frontend/src/core/macro/macroCertification.wave7.test.ts

  revised_files/src_components_macro_MacroDropdown_phaseJ_test.tsx
    -> frontend/src/components/macro/MacroDropdown.phaseJ.test.tsx

  revised_files/src_components_macro_MacroPanel_phaseJ_test.tsx
    -> frontend/src/components/macro/MacroPanel.phaseJ.test.tsx

  revised_files/MACRO_CERTIFICATION.md
    -> frontend/MACRO_CERTIFICATION.md

Fixes included:

  J-001: MacroPanel now exposes onCommitBytes and commits only successful non-dry-run results.
  J-002: MacroDropdown missing-context action is reachable and reports the issue instead of silently disabling buttons.
  J-003: macro-static-audit.mjs now checks the content-ops error branch without false-positive scanning into the success branch.
  J-004: MacroPanel test proves dry-run does not call onCommitBytes.
  J-005: Macro certification test proves unsafe image execution emits no bytes_updated side effect.

Run from frontend/:

  npm run typecheck
  npx vitest run src/core/macro/macroCertification.wave7.test.ts
  npx vitest run src/components/macro/MacroDropdown.phaseJ.test.tsx
  npx vitest run src/components/macro/MacroPanel.phaseJ.test.tsx
  npm run audit:macro
  npm run build
  npm run certify:macro

Phase J status after copying and local pass:
  PASS
