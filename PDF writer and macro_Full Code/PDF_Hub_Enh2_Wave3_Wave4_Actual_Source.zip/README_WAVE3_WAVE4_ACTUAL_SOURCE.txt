PDF_HUB_ENH2 — WAVE 3 + WAVE 4 ACTUAL SOURCE PACKAGE
====================================================

This ZIP contains real source files for the missing macro Wave 3 and Wave 4 implementation.

It is not a Markdown/WI-only pack.

Included:
- Wave 3 / Phase H schema, recipe catalog, storage, builder-state helpers, tests
- Wave 4 / Phase I custom recipe builder UI components and tests
- Revised Phase H Full PASS Fix already overlaid
- Revised Phase I Full PASS Fix already overlaid

Apply by unzipping/copying the `frontend/` folder over the existing project.

After applying:

  cd frontend
  pnpm run typecheck
  pnpm run audit:macro
  pnpm run build

Targeted tests:

  pnpm vitest run src/core/macro/schema/opSchema.phaseH.test.ts
  pnpm vitest run src/core/macro/builder/recipeBuilderState.phaseH.test.ts
  pnpm vitest run src/core/macro/recipes/builtInRecipes.phaseH.test.ts
  pnpm vitest run src/core/macro/recipes/recipeStorage.phaseH.test.ts
  pnpm vitest run src/components/macro/builder/MacroRecipeBuilder.phaseI.test.tsx
  pnpm vitest run src/components/macro/builder/MacroStepEditor.phaseI.test.tsx
  pnpm vitest run src/components/macro/builder/MacroRecipeImportExport.phaseI.test.tsx

Extraction summary:
{
  "phase_h_base_files": 9,
  "phase_i_base_files": 14,
  "phase_h_revised_overlay": [
    "frontend/src/core/macro/builder/recipeBuilderState.ts",
    "frontend/src/core/macro/builder/recipeBuilderState.phaseH.test.ts"
  ],
  "phase_i_revised_overlay": [
    "frontend/src/components/macro/builder/MacroFieldEditor.tsx",
    "frontend/src/components/macro/builder/MacroRecipeBuilder.tsx",
    "frontend/src/components/macro/builder/MacroRecipeBuilder.phaseI.test.tsx",
    "frontend/src/components/macro/builder/MacroRecipeImportExport.phaseI.test.tsx"
  ]
}
