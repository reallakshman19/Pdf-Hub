import React from 'react';
import type {
  MacroExecutionResult,
} from '@/core/macro/executor';

export interface MacroRunResultPanelProps {
  result: MacroExecutionResult | null;
}

export const MacroRunResultPanel: React.FC<MacroRunResultPanelProps> = ({
  result,
}) => {
  return (
    <section className="p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div>
          <div className="text-sm font-semibold">Run Result</div>
          <div className="text-xs text-slate-500">
            {result ? `${result.stepResults.length} step result(s)` : 'No run result yet.'}
          </div>
        </div>

        {result && (
          <span
            className={[
              'rounded px-2 py-1 text-xs',
              result.success
                ? 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300'
                : 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300',
            ].join(' ')}
          >
            {result.success ? 'SUCCESS' : 'ERROR'}
          </span>
        )}
      </div>

      {result && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <Metric label="Output files" value={String(result.outputFiles.length)} />
            <Metric label="Selected pages" value={result.selectedPages.join(', ') || '-'} />
          </div>

          <div className="space-y-1">
            {result.stepResults.map((step, index) => (
              <div
                key={`${index}-${step.status}`}
                className="rounded border border-slate-200 p-2 text-xs dark:border-slate-800"
              >
                <div className="font-medium">
                  Step {index + 1}: {step.status}
                </div>
                {step.message && <div className="text-slate-500">{step.message}</div>}
              </div>
            ))}
          </div>

          {result.logs.length > 0 && (
            <pre className="max-h-36 overflow-auto rounded bg-slate-100 p-2 text-[11px] dark:bg-slate-900">
              {result.logs.join('\n')}
            </pre>
          )}
        </div>
      )}
    </section>
  );
};

function Metric(props: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded bg-slate-50 p-2 dark:bg-slate-900">
      <div className="text-[10px] uppercase tracking-wide text-slate-500">{props.label}</div>
      <div className="font-medium">{props.value}</div>
    </div>
  );
}
