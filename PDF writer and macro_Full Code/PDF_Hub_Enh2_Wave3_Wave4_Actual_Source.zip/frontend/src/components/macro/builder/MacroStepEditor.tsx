import React from 'react';
import type {
  MacroStep,
} from '@/core/macro/types';
import {
  getMacroOpSchema,
} from '@/core/macro/schema/opSchema';
import { MacroFieldEditor } from './MacroFieldEditor';

export interface MacroStepEditorProps {
  step: MacroStep | null;
  stepIndex: number | null;
  onChange: (step: MacroStep) => void;
}

export const MacroStepEditor: React.FC<MacroStepEditorProps> = ({
  step,
  stepIndex,
  onChange,
}) => {
  if (!step || stepIndex === null) {
    return (
      <div className="rounded border border-dashed border-slate-300 p-6 text-sm text-slate-500 dark:border-slate-700">
        Select a step to edit.
      </div>
    );
  }

  let schema;

  try {
    schema = getMacroOpSchema(step.op);
  } catch (err) {
    return (
      <div className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
        {err instanceof Error ? err.message : String(err)}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="text-sm font-semibold">
          Step {stepIndex + 1}: {schema.label}
        </div>
        <div className="text-xs text-slate-500">{schema.description}</div>
      </div>

      <div className="space-y-3">
        {schema.fields.map((field) => (
          <MacroFieldEditor
            key={field.key}
            field={field}
            value={readField(step, field.key)}
            onChange={(value) => {
              onChange({
                ...step,
                [field.key]: value,
              } as MacroStep);
            }}
          />
        ))}
      </div>
    </div>
  );
};

function readField(step: MacroStep, key: string): unknown {
  return (step as unknown as Record<string, unknown>)[key];
}
