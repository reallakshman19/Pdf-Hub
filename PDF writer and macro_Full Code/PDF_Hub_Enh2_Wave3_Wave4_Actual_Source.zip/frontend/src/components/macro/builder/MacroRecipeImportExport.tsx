import React, { useMemo, useState } from 'react';
import type {
  MacroRecipe,
} from '@/core/macro/types';
import {
  exportMacroRecipeJson,
  importMacroRecipeJson,
} from '@/core/macro/recipes/recipeStorage';

export interface MacroRecipeImportExportProps {
  recipe: MacroRecipe;
  onImport: (recipe: MacroRecipe) => void;
}

export const MacroRecipeImportExport: React.FC<MacroRecipeImportExportProps> = ({
  recipe,
  onImport,
}) => {
  const exported = useMemo(() => {
    try {
      return exportMacroRecipeJson(recipe);
    } catch (err) {
      return err instanceof Error ? err.message : String(err);
    }
  }, [recipe]);

  const [importText, setImportText] = useState('');
  const [status, setStatus] = useState('');

  const doImport = () => {
    try {
      const parsed = importMacroRecipeJson(importText);
      onImport(parsed);
      setStatus('Recipe imported.');
    } catch (err) {
      setStatus(err instanceof Error ? err.message : String(err));
    }
  };

  const copyExport = async () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(exported);
        setStatus('Export JSON copied.');
      } else {
        setStatus('Clipboard write is not available.');
      }
    } catch (err) {
      setStatus(err instanceof Error ? err.message : String(err));
    }
  };

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <section className="space-y-2">
        <div>
          <div className="text-sm font-semibold">Export Recipe JSON</div>
          <div className="text-xs text-slate-500">
            Export current recipe for sharing or backup.
          </div>
        </div>

        <textarea
          readOnly
          value={exported}
          className="h-96 w-full rounded border border-slate-300 bg-white p-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
          data-macro-builder="true"
        />

        <button
          type="button"
          className="h-8 rounded bg-slate-100 px-3 text-xs hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
          onClick={() => void copyExport()}
        >
          Copy Export
        </button>
      </section>

      <section className="space-y-2">
        <div>
          <div className="text-sm font-semibold">Import Recipe JSON</div>
          <div className="text-xs text-slate-500">
            Paste recipe JSON. Invalid recipes are rejected.
          </div>
        </div>

        <textarea
          value={importText}
          onChange={(event) => setImportText(event.target.value)}
          className="h-96 w-full rounded border border-slate-300 bg-white p-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
          data-macro-builder="true"
        />

        <button
          type="button"
          className="h-8 rounded bg-blue-600 px-3 text-xs text-white"
          onClick={doImport}
        >
          Import
        </button>

        {status && <div className="text-xs text-slate-500">{status}</div>}
      </section>
    </div>
  );
};
