import React from 'react';
import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import { MacroStepEditor } from './MacroStepEditor';

describe('MacroStepEditor phase I', () => {
  it('renders empty state', () => {
    render(
      <MacroStepEditor
        step={null}
        stepIndex={null}
        onChange={vi.fn()}
      />,
    );

    expect(screen.getByText('Select a step to edit.')).toBeTruthy();
  });

  it('edits text field', () => {
    const onChange = vi.fn();

    render(
      <MacroStepEditor
        step={{
          op: 'draw_text_on_pages',
          selector: { mode: 'current' },
          text: 'Hello',
          x: 72,
          y: 72,
          fontSize: 12,
        }}
        stepIndex={0}
        onChange={onChange}
      />,
    );

    fireEvent.change(screen.getByDisplayValue('Hello'), {
      target: {
        value: 'Changed',
      },
    });

    expect(onChange).toHaveBeenCalled();
  });

  it('edits page selector mode', () => {
    const onChange = vi.fn();

    render(
      <MacroStepEditor
        step={{
          op: 'select_pages',
          selector: { mode: 'current' },
        }}
        stepIndex={0}
        onChange={onChange}
      />,
    );

    fireEvent.change(screen.getByDisplayValue('Current'), {
      target: {
        value: 'all',
      },
    });

    expect(onChange).toHaveBeenCalledWith({
      op: 'select_pages',
      selector: { mode: 'all' },
    });
  });
});
