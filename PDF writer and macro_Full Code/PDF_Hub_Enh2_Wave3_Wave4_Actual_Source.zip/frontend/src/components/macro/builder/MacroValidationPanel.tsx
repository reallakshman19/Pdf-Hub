import React from 'react';
import type {
  MacroRecipeValidationSummary,
} from '@/core/macro/builder/recipeBuilderState';

export interface MacroValidationPanelProps {
  validation: MacroRecipeValidationSummary;
}

export const MacroValidationPanel: React.FC<MacroValidationPanelProps> = ({
  validation,
}) => {
  return (
    <section className="border-b border-slate-200 p-3 dark:border-slate-800">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div>
          <div className="text-sm font-semibold">Validation</div>
          <div className="text-xs text-slate-500">
            {validation.valid ? 'Recipe is valid.' : `${validation.issues.length} issue(s).`}
          </div>
        </div>

        <span
          className={[
            'rounded px-2 py-1 text-xs',
            validation.valid
              ? 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300'
              : 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300',
          ].join(' ')}
        >
          {validation.valid ? 'PASS' : 'FAIL'}
        </span>
      </div>

      {validation.issues.length > 0 && (
        <div className="space-y-2">
          {validation.issues.map((issue, index) => (
            <div
              key={`${issue.stepIndex}-${issue.field}-${index}`}
              className="rounded border border-red-200 bg-red-50 p-2 text-xs text-red-800 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300"
            >
              <div className="font-medium">
                Step {issue.stepIndex >= 0 ? issue.stepIndex + 1 : 'Recipe'} · {issue.op}
              </div>
              <div>{issue.field}: {issue.message}</div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
