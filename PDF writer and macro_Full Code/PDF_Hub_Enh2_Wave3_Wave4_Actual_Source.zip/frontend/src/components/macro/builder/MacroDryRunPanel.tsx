import React from 'react';
import type {
  MacroExecutionResult,
} from '@/core/macro/executor';

export interface MacroDryRunPanelProps {
  result: MacroExecutionResult | null;
}

export const MacroDryRunPanel: React.FC<MacroDryRunPanelProps> = ({
  result,
}) => {
  const dryRunDiff = result && 'dryRunDiff' in result
    ? (result as MacroExecutionResult & {
        dryRunDiff?: {
          wouldMutateBytes: boolean;
          pageCountBefore: number;
          pageCountAfter: number;
          selectedPagesBefore: number[];
          selectedPagesAfter: number[];
          outputFiles: Array<{ name: string; reason: string }>;
        };
      }).dryRunDiff
    : undefined;

  return (
    <section className="border-b border-slate-200 p-3 dark:border-slate-800">
      <div className="text-sm font-semibold">Dry Run</div>

      {!dryRunDiff && (
        <div className="mt-1 text-xs text-slate-500">
          Run dry-run to preview macro effects without mutating PDF bytes.
        </div>
      )}

      {dryRunDiff && (
        <div className="mt-2 space-y-2 text-xs">
          <Row label="Would mutate bytes" value={dryRunDiff.wouldMutateBytes ? 'Yes' : 'No'} />
          <Row label="Page count" value={`${dryRunDiff.pageCountBefore} → ${dryRunDiff.pageCountAfter}`} />
          <Row label="Selected pages" value={`${dryRunDiff.selectedPagesBefore.join(', ') || '-'} → ${dryRunDiff.selectedPagesAfter.join(', ') || '-'}`} />
          <Row label="Output files" value={String(dryRunDiff.outputFiles.length)} />
        </div>
      )}
    </section>
  );
};

function Row(props: {
  label: string;
  value: string;
}) {
  return (
    <div className="flex justify-between gap-3">
      <span className="text-slate-500">{props.label}</span>
      <span className="font-medium">{props.value}</span>
    </div>
  );
}
