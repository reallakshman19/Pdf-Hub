import React, { useEffect, useMemo, useState } from 'react';
import type {
  InsertPosition,
  PageSelector,
} from '@/core/macro/types';
import type {
  MacroOpFieldSchema,
} from '@/core/macro/schema/opSchema';

export interface MacroFieldEditorProps {
  field: MacroOpFieldSchema;
  value: unknown;
  onChange: (value: unknown) => void;
}

export const MacroFieldEditor: React.FC<MacroFieldEditorProps> = ({
  field,
  value,
  onChange,
}) => {
  return (
    <label className="block">
      <div className="mb-1 flex items-center justify-between gap-2">
        <span className="text-xs font-medium">
          {field.label}
          {field.required && <span className="ml-1 text-red-500">*</span>}
        </span>
        {field.help && <span className="text-[10px] text-slate-500">{field.help}</span>}
      </div>

      {renderField(field, value, onChange)}
    </label>
  );
};

function renderField(
  field: MacroOpFieldSchema,
  value: unknown,
  onChange: (value: unknown) => void,
): React.ReactNode {
  if (field.type === 'textarea') {
    return (
      <textarea
        value={String(value ?? '')}
        onChange={(event) => onChange(event.target.value)}
        className="h-24 w-full rounded border border-slate-300 bg-white p-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />
    );
  }

  if (field.type === 'text' || field.type === 'color') {
    return (
      <input
        type={field.type === 'color' ? 'color' : 'text'}
        value={String(value ?? (field.type === 'color' ? '#111827' : ''))}
        onChange={(event) => onChange(event.target.value)}
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />
    );
  }

  if (field.type === 'number') {
    return (
      <input
        type="number"
        min={field.min}
        max={field.max}
        value={typeof value === 'number' && Number.isFinite(value) ? value : ''}
        onChange={(event) => {
          const next = event.target.value === '' ? undefined : Number(event.target.value);
          onChange(next);
        }}
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />
    );
  }

  if (field.type === 'boolean') {
    return (
      <label className="flex h-8 items-center gap-2 rounded border border-slate-300 px-2 text-xs dark:border-slate-700">
        <input
          type="checkbox"
          checked={Boolean(value)}
          onChange={(event) => onChange(event.target.checked)}
        />
        Enabled
      </label>
    );
  }

  if (field.type === 'select') {
    return (
      <select
        value={String(value ?? '')}
        onChange={(event) => {
          const option = field.options?.find((item) => String(item.value) === event.target.value);
          onChange(option?.value ?? event.target.value);
        }}
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
      >
        {(field.options ?? []).map((option) => (
          <option key={String(option.value)} value={String(option.value)}>
            {option.label}
          </option>
        ))}
      </select>
    );
  }

  if (field.type === 'page-selector') {
    return (
      <MacroPageSelectorField
        value={isPageSelector(value) ? value : { mode: 'current' }}
        onChange={onChange}
      />
    );
  }

  if (field.type === 'insert-position') {
    return (
      <MacroInsertPositionField
        value={isInsertPosition(value) ? value : { mode: 'end' }}
        onChange={onChange}
      />
    );
  }

  if (field.type === 'number-list') {
    return (
      <input
        value={Array.isArray(value) ? value.join(', ') : ''}
        onChange={(event) =>
          onChange(
            event.target.value
              .split(',')
              .map((item) => Number(item.trim()))
              .filter((item) => Number.isFinite(item)),
          )
        }
        placeholder="1, 2, 3"
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />
    );
  }

  if (field.type === 'string-list') {
    return (
      <input
        value={Array.isArray(value) ? value.join(', ') : ''}
        onChange={(event) =>
          onChange(
            event.target.value
              .split(',')
              .map((item) => item.trim())
              .filter(Boolean),
          )
        }
        placeholder="tag-1, tag-2"
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />
    );
  }

  return (
    <JsonEditor
      value={value}
      onChange={onChange}
    />
  );
}

function MacroPageSelectorField(props: {
  value: PageSelector;
  onChange: (value: PageSelector) => void;
}) {
  const value = props.value;

  return (
    <div className="space-y-2 rounded border border-slate-300 p-2 dark:border-slate-700">
      <select
        value={value.mode}
        onChange={(event) => {
          const mode = event.target.value as PageSelector['mode'];

          if (mode === 'current') props.onChange({ mode: 'current' });
          if (mode === 'selected') props.onChange({ mode: 'selected' });
          if (mode === 'all') props.onChange({ mode: 'all' });
          if (mode === 'range') props.onChange({ mode: 'range', from: 1, to: 1 });
          if (mode === 'explicit') props.onChange({ mode: 'explicit', pages: [1] });
        }}
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
      >
        <option value="current">Current</option>
        <option value="selected">Selected</option>
        <option value="all">All</option>
        <option value="range">Range</option>
        <option value="explicit">Explicit</option>
      </select>

      {value.mode === 'range' && (
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            min={1}
            value={value.from}
            onChange={(event) =>
              props.onChange({
                ...value,
                from: Number(event.target.value) || 1,
              })
            }
            className="h-8 rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
          />
          <input
            type="number"
            min={1}
            value={value.to}
            onChange={(event) =>
              props.onChange({
                ...value,
                to: Number(event.target.value) || 1,
              })
            }
            className="h-8 rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
          />
        </div>
      )}

      {value.mode === 'explicit' && (
        <input
          value={value.pages.join(', ')}
          onChange={(event) =>
            props.onChange({
              mode: 'explicit',
              pages: event.target.value
                .split(',')
                .map((item) => Number(item.trim()))
                .filter((page) => Number.isFinite(page)),
            })
          }
          className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
          placeholder="1, 2, 3"
        />
      )}
    </div>
  );
}

function MacroInsertPositionField(props: {
  value: InsertPosition;
  onChange: (value: InsertPosition) => void;
}) {
  const value = props.value;

  return (
    <div className="space-y-2 rounded border border-slate-300 p-2 dark:border-slate-700">
      <select
        value={value.mode}
        onChange={(event) => {
          const mode = event.target.value as InsertPosition['mode'];

          if (mode === 'start') props.onChange({ mode: 'start' });
          if (mode === 'end') props.onChange({ mode: 'end' });
          if (mode === 'before') props.onChange({ mode: 'before', page: 1 });
          if (mode === 'after') props.onChange({ mode: 'after', page: 1 });
        }}
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
      >
        <option value="start">Start</option>
        <option value="end">End</option>
        <option value="before">Before page</option>
        <option value="after">After page</option>
      </select>

      {(value.mode === 'before' || value.mode === 'after') && (
        <input
          type="number"
          min={1}
          value={value.page}
          onChange={(event) =>
            props.onChange({
              ...value,
              page: Number(event.target.value) || 1,
            })
          }
          className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        />
      )}
    </div>
  );
}

function JsonEditor(props: {
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const serialized = useMemo(
    () => JSON.stringify(props.value ?? {}, null, 2),
    [props.value],
  );
  const [text, setText] = useState(serialized);
  const [error, setError] = useState('');

  useEffect(() => {
    setText(serialized);
    setError('');
  }, [serialized]);

  return (
    <div className="space-y-1">
      <textarea
        value={text}
        onChange={(event) => {
          const next = event.target.value;
          setText(next);

          try {
            const parsed = JSON.parse(next);
            setError('');
            props.onChange(parsed);
          } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
          }
        }}
        className="h-36 w-full rounded border border-slate-300 bg-white p-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
        data-macro-builder="true"
      />

      {error && <div className="text-[11px] text-red-600">{error}</div>}
    </div>
  );
}

function isPageSelector(value: unknown): value is PageSelector {
  return Boolean(value && typeof value === 'object' && 'mode' in value);
}

function isInsertPosition(value: unknown): value is InsertPosition {
  return Boolean(value && typeof value === 'object' && 'mode' in value);
}
