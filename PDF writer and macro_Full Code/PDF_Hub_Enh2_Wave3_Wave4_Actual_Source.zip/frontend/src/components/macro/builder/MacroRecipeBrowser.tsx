import React, { useMemo, useState } from 'react';
import type {
  MacroRecipe,
} from '@/core/macro/types';
import {
  getBuiltInMacroRecipes,
  getRecommendedMacroRecipes,
  type MacroRecipeCatalogCategory,
  type MacroRecipeCatalogItem,
} from '@/core/macro/recipes/builtInRecipes';
import {
  loadCustomMacroRecipes,
} from '@/core/macro/recipes/recipeStorage';
import {
  cloneMacroRecipe,
} from '@/core/macro/builder/recipeBuilderState';

export interface MacroRecipeBrowserProps {
  onLoadRecipe: (recipe: MacroRecipe) => void;
}

export const MacroRecipeBrowser: React.FC<MacroRecipeBrowserProps> = ({
  onLoadRecipe,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<'all' | MacroRecipeCatalogCategory | 'custom'>('all');
  const [showRecommendedOnly, setShowRecommendedOnly] = useState(false);

  const catalogItems = useMemo(() => {
    const builtIns = showRecommendedOnly ? getRecommendedMacroRecipes() : getBuiltInMacroRecipes();
    const custom = loadCustomMacroRecipes().map((recipe) => ({
      id: `custom-${recipe.id}`,
      name: recipe.name,
      description: 'Custom macro recipe',
      category: 'custom' as const,
      tags: ['custom'],
      recipe,
      requiredOps: recipe.steps.map((step) => step.op),
    }));

    return [...builtIns, ...custom];
  }, [showRecommendedOnly]);

  const visible = catalogItems.filter((item) => {
    const q = query.trim().toLowerCase();
    const categoryOk = category === 'all' || item.category === category;

    if (!categoryOk) return false;

    if (!q) return true;

    return [
      item.name,
      item.description,
      item.category,
      ...item.tags,
      ...item.requiredOps,
    ].join(' ').toLowerCase().includes(q);
  });

  return (
    <div className="p-3 space-y-3">
      <div>
        <div className="text-sm font-semibold">Recipe Browser</div>
        <div className="text-xs text-slate-500">
          Load built-in, recommended, or custom recipes.
        </div>
      </div>

      <div className="grid gap-2">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search recipe..."
          className="h-8 rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        />

        <div className="grid grid-cols-2 gap-2">
          <select
            value={category}
            onChange={(event) => setCategory(event.target.value as never)}
            className="h-8 rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
          >
            <option value="all">All categories</option>
            <option value="document-control">Document control</option>
            <option value="review">Review</option>
            <option value="stamps">Stamps</option>
            <option value="tables">Tables</option>
            <option value="page-cleanup">Page cleanup</option>
            <option value="authoring">Authoring</option>
            <option value="custom">Custom</option>
          </select>

          <label className="flex items-center gap-2 rounded border border-slate-300 px-2 text-xs dark:border-slate-700">
            <input
              type="checkbox"
              checked={showRecommendedOnly}
              onChange={(event) => setShowRecommendedOnly(event.target.checked)}
            />
            Recommended
          </label>
        </div>
      </div>

      <div className="space-y-2">
        {visible.map((item) => (
          <RecipeCard
            key={item.id}
            item={item}
            onLoad={() => onLoadRecipe(cloneForEditing(item))}
          />
        ))}

        {visible.length === 0 && (
          <div className="rounded border border-dashed border-slate-300 p-4 text-sm text-slate-500 dark:border-slate-700">
            No matching recipes.
          </div>
        )}
      </div>
    </div>
  );
};

function RecipeCard(props: {
  item: MacroRecipeCatalogItem | {
    id: string;
    name: string;
    description: string;
    category: 'custom';
    tags: string[];
    recipe: MacroRecipe;
    requiredOps: string[];
  };
  onLoad: () => void;
}) {
  return (
    <div className="rounded border border-slate-200 p-3 dark:border-slate-800">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-medium">{props.item.name}</div>
          <div className="mt-0.5 text-xs text-slate-500">
            {props.item.description}
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {props.item.tags.map((tag) => (
              <span
                key={tag}
                className="rounded bg-slate-100 px-2 py-0.5 text-[10px] dark:bg-slate-800"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <button
          type="button"
          className="h-8 shrink-0 rounded bg-blue-600 px-3 text-xs text-white"
          onClick={props.onLoad}
        >
          Load
        </button>
      </div>
    </div>
  );
}

function cloneForEditing(item: MacroRecipeCatalogItem | { recipe: MacroRecipe }): MacroRecipe {
  const cloned = cloneMacroRecipe(item.recipe);

  return {
    ...cloned,
    id: `custom-${cloned.id}-${Date.now().toString(36)}`,
    name: cloned.name,
    dryRun: true,
  };
}
