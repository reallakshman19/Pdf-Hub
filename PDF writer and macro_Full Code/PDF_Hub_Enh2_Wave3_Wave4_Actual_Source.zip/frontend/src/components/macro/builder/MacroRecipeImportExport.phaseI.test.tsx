import React from 'react';
import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import { MacroRecipeImportExport } from './MacroRecipeImportExport';

describe('MacroRecipeImportExport phase I', () => {
  it('exports recipe JSON', () => {
    render(
      <MacroRecipeImportExport
        recipe={{
          id: 'r1',
          name: 'Recipe',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        }}
        onImport={vi.fn()}
      />,
    );

    expect(screen.getByText('Export Recipe JSON')).toBeTruthy();
    expect(screen.getByDisplayValue(/"id": "r1"/)).toBeTruthy();
  });

  it('imports recipe JSON', () => {
    const onImport = vi.fn();

    render(
      <MacroRecipeImportExport
        recipe={{
          id: 'r1',
          name: 'Recipe',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        }}
        onImport={onImport}
      />,
    );

    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: {
        value: JSON.stringify({
          id: 'r2',
          name: 'Imported',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'all' },
            },
          ],
        }),
      },
    });

    fireEvent.click(screen.getByText('Import'));

    expect(onImport).toHaveBeenCalledWith({
      id: 'r2',
      name: 'Imported',
      steps: [
        {
          op: 'select_pages',
          selector: { mode: 'all' },
        },
      ],
    });
  });

  it('rejects invalid import JSON', () => {
    const onImport = vi.fn();

    render(
      <MacroRecipeImportExport
        recipe={{
          id: 'r1',
          name: 'Recipe',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        }}
        onImport={onImport}
      />,
    );

    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: {
        value: '{bad',
      },
    });

    fireEvent.click(screen.getByText('Import'));

    expect(onImport).not.toHaveBeenCalled();
    expect(screen.getByText(/Invalid macro recipe JSON/i)).toBeTruthy();
  });

  it('rejects invalid imported recipe', () => {
    const onImport = vi.fn();

    render(
      <MacroRecipeImportExport
        recipe={{
          id: 'r1',
          name: 'Recipe',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        }}
        onImport={onImport}
      />,
    );

    fireEvent.change(screen.getAllByRole('textbox')[1], {
      target: {
        value: JSON.stringify({
          id: 'bad',
          name: '',
          steps: [],
        }),
      },
    });

    fireEvent.click(screen.getByText('Import'));

    expect(onImport).not.toHaveBeenCalled();
    expect(screen.getByText(/Imported macro recipe is invalid/i)).toBeTruthy();
  });
});
