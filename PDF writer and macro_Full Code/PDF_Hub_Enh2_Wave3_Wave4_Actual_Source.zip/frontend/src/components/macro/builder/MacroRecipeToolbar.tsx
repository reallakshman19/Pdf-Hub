import React from 'react';
import type {
  MacroRecipe,
} from '@/core/macro/types';
import type {
  MacroRecipeValidationSummary,
} from '@/core/macro/builder/recipeBuilderState';

export interface MacroRecipeToolbarProps {
  recipe: MacroRecipe;
  validation: MacroRecipeValidationSummary;
  saveStatus?: string;
  runStatus?: string;
  canRun: boolean;
  onRename: (name: string) => void;
  onDryRunChange: (dryRun: boolean) => void;
  onSaveCustom: () => void;
  onDryRun: () => void;
  onRun: () => void;
}

export const MacroRecipeToolbar: React.FC<MacroRecipeToolbarProps> = ({
  recipe,
  validation,
  saveStatus,
  runStatus,
  canRun,
  onRename,
  onDryRunChange,
  onSaveCustom,
  onDryRun,
  onRun,
}) => {
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-slate-200 p-3 dark:border-slate-800">
      <label className="flex items-center gap-2">
        <span className="text-xs font-medium">Name</span>
        <input
          value={recipe.name}
          onChange={(event) => onRename(event.target.value)}
          className="h-8 w-64 rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
        />
      </label>

      <label className="flex items-center gap-2 text-xs">
        <input
          type="checkbox"
          checked={Boolean(recipe.dryRun)}
          onChange={(event) => onDryRunChange(event.target.checked)}
        />
        Default dry-run
      </label>

      <StatusBadge valid={validation.valid} count={validation.issues.length} />

      <button
        type="button"
        className="h-8 rounded bg-slate-100 px-3 text-xs hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
        onClick={onSaveCustom}
      >
        Save Custom
      </button>

      <button
        type="button"
        disabled={!canRun}
        className="h-8 rounded bg-amber-600 px-3 text-xs text-white disabled:cursor-not-allowed disabled:opacity-50"
        onClick={onDryRun}
      >
        Dry Run
      </button>

      <button
        type="button"
        disabled={!canRun || !validation.valid}
        className="h-8 rounded bg-green-600 px-3 text-xs text-white disabled:cursor-not-allowed disabled:opacity-50"
        onClick={onRun}
      >
        Run
      </button>

      <div className="min-w-[180px] text-xs text-slate-500">
        {saveStatus || runStatus || `${recipe.steps.length} step(s)`}
      </div>
    </div>
  );
};

function StatusBadge(props: {
  valid: boolean;
  count: number;
}) {
  return (
    <span
      className={[
        'rounded px-2 py-1 text-xs',
        props.valid
          ? 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-300'
          : 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-300',
      ].join(' ')}
    >
      {props.valid ? 'Valid' : `${props.count} issue(s)`}
    </span>
  );
}
