import React, { useMemo, useState } from 'react';
import type {
  MacroExecutionContext,
  MacroRecipe,
  MacroStep,
} from '@/core/macro/types';
import type {
  MacroExecutionResult,
} from '@/core/macro/executor';
import {
  executeMacroRecipe,
} from '@/core/macro/executor';
import {
  appendDefaultMacroStep,
  cloneMacroRecipe,
  createEmptyMacroRecipe,
  duplicateMacroStep,
  moveMacroStep,
  removeMacroStep,
  renameMacroRecipe,
  setMacroRecipeDryRun,
  updateMacroStep,
  validateMacroRecipeWithSchema,
} from '@/core/macro/builder/recipeBuilderState';
import {
  upsertCustomMacroRecipe,
} from '@/core/macro/recipes/recipeStorage';
import { MacroRecipeBrowser } from './MacroRecipeBrowser';
import { MacroRecipeToolbar } from './MacroRecipeToolbar';
import { MacroStepPalette } from './MacroStepPalette';
import { MacroStepList } from './MacroStepList';
import { MacroStepEditor } from './MacroStepEditor';
import { MacroValidationPanel } from './MacroValidationPanel';
import { MacroDryRunPanel } from './MacroDryRunPanel';
import { MacroRunResultPanel } from './MacroRunResultPanel';
import { MacroRecipeImportExport } from './MacroRecipeImportExport';

export interface MacroRecipeBuilderProps {
  initialRecipe?: MacroRecipe;
  executionContext?: MacroExecutionContext;
  onRecipeChange?: (recipe: MacroRecipe) => void;
  onRunResult?: (result: MacroExecutionResult) => void;
  onClose?: () => void;
}

export const MacroRecipeBuilder: React.FC<MacroRecipeBuilderProps> = ({
  initialRecipe,
  executionContext,
  onRecipeChange,
  onRunResult,
  onClose,
}) => {
  const [recipe, setRecipeState] = useState<MacroRecipe>(() =>
    initialRecipe ? cloneMacroRecipe(initialRecipe) : createEmptyMacroRecipe(),
  );
  const [selectedStepIndex, setSelectedStepIndex] = useState<number | null>(null);
  const [result, setResult] = useState<MacroExecutionResult | null>(null);
  const [runStatus, setRunStatus] = useState('');
  const [saveStatus, setSaveStatus] = useState('');
  const [activeTab, setActiveTab] = useState<'builder' | 'browser' | 'import-export'>('builder');

  const validation = useMemo(() => validateMacroRecipeWithSchema(recipe), [recipe]);

  const selectedStep =
    selectedStepIndex === null ? null : recipe.steps[selectedStepIndex] ?? null;

  const setRecipe = (nextRecipe: MacroRecipe) => {
    setRecipeState(nextRecipe);
    onRecipeChange?.(nextRecipe);

    if (
      selectedStepIndex !== null &&
      selectedStepIndex >= nextRecipe.steps.length
    ) {
      setSelectedStepIndex(nextRecipe.steps.length > 0 ? nextRecipe.steps.length - 1 : null);
    }
  };

  const addStep = (op: MacroStep['op']) => {
    const next = appendDefaultMacroStep(recipe, op);
    setRecipe(next);
    setSelectedStepIndex(next.steps.length - 1);
  };

  const updateSelectedStep = (step: MacroStep) => {
    if (selectedStepIndex === null) return;

    setRecipe(updateMacroStep(recipe, selectedStepIndex, step));
  };

  const runRecipe = async (dryRun: boolean) => {
    if (!executionContext) {
      setRunStatus('No macro execution context is available.');
      return;
    }

    const recipeToRun: MacroRecipe = {
      ...recipe,
      dryRun,
    };

    const currentValidation = validateMacroRecipeWithSchema(recipeToRun);

    if (!currentValidation.valid) {
      setRunStatus(`Recipe is invalid: ${currentValidation.issues[0]?.message ?? 'unknown issue'}`);
      return;
    }

    setRunStatus(dryRun ? 'Running dry-run...' : 'Running macro...');

    const nextResult = await executeMacroRecipe(recipeToRun, executionContext);

    setResult(nextResult);
    setRunStatus(nextResult.success ? 'Macro completed.' : 'Macro completed with errors.');
    onRunResult?.(nextResult);
  };

  const saveCustom = () => {
    const currentValidation = validateMacroRecipeWithSchema(recipe);

    if (!currentValidation.valid) {
      setSaveStatus(`Cannot save invalid recipe: ${currentValidation.issues[0]?.message ?? 'unknown issue'}`);
      return;
    }

    try {
      upsertCustomMacroRecipe(recipe);
      setSaveStatus('Saved custom recipe.');
    } catch (err) {
      setSaveStatus(err instanceof Error ? err.message : String(err));
    }
  };

  return (
    <div
      className="flex h-full min-h-[680px] flex-col rounded border border-slate-200 bg-white text-slate-900 shadow-sm dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100"
      data-macro-builder="true"
    >
      <div className="flex items-center justify-between border-b border-slate-200 p-3 dark:border-slate-800">
        <div>
          <div className="text-sm font-semibold">Macro Recipe Builder</div>
          <div className="text-xs text-slate-500">
            Build, validate, dry-run, run, import and export macro recipes.
          </div>
        </div>

        <div className="flex gap-2">
          <TabButton active={activeTab === 'builder'} onClick={() => setActiveTab('builder')}>
            Builder
          </TabButton>
          <TabButton active={activeTab === 'browser'} onClick={() => setActiveTab('browser')}>
            Recipes
          </TabButton>
          <TabButton active={activeTab === 'import-export'} onClick={() => setActiveTab('import-export')}>
            Import/Export
          </TabButton>
          {onClose && (
            <button
              type="button"
              className="h-8 rounded bg-slate-100 px-3 text-xs hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
              onClick={onClose}
            >
              Close
            </button>
          )}
        </div>
      </div>

      <MacroRecipeToolbar
        recipe={recipe}
        validation={validation}
        saveStatus={saveStatus}
        runStatus={runStatus}
        canRun={Boolean(executionContext)}
        onRename={(name) => setRecipe(renameMacroRecipe(recipe, name))}
        onDryRunChange={(dryRun) => setRecipe(setMacroRecipeDryRun(recipe, dryRun))}
        onSaveCustom={saveCustom}
        onDryRun={() => void runRecipe(true)}
        onRun={() => void runRecipe(false)}
      />

      {activeTab === 'browser' && (
        <div className="min-h-0 flex-1 overflow-auto">
          <MacroRecipeBrowser
            onLoadRecipe={(nextRecipe) => {
              setRecipe(nextRecipe);
              setSelectedStepIndex(nextRecipe.steps.length > 0 ? 0 : null);
              setActiveTab('builder');
            }}
          />
        </div>
      )}

      {activeTab === 'import-export' && (
        <div className="min-h-0 flex-1 overflow-auto p-3">
          <MacroRecipeImportExport
            recipe={recipe}
            onImport={(nextRecipe) => {
              setRecipe(nextRecipe);
              setSelectedStepIndex(nextRecipe.steps.length > 0 ? 0 : null);
              setActiveTab('builder');
            }}
          />
        </div>
      )}

      {activeTab === 'builder' && (
        <div className="grid min-h-0 flex-1 grid-cols-[280px_320px_1fr_320px]">
          <div className="min-h-0 overflow-auto border-r border-slate-200 dark:border-slate-800">
            <MacroStepPalette onAddStep={addStep} />
          </div>

          <div className="min-h-0 overflow-auto border-r border-slate-200 dark:border-slate-800">
            <MacroStepList
              steps={recipe.steps}
              selectedIndex={selectedStepIndex}
              onSelect={setSelectedStepIndex}
              onMove={(from, to) => {
                setRecipe(moveMacroStep(recipe, from, to));
                setSelectedStepIndex(to);
              }}
              onDuplicate={(index) => {
                setRecipe(duplicateMacroStep(recipe, index));
                setSelectedStepIndex(index + 1);
              }}
              onRemove={(index) => {
                setRecipe(removeMacroStep(recipe, index));
                setSelectedStepIndex(null);
              }}
            />
          </div>

          <div className="min-h-0 overflow-auto p-3">
            <MacroStepEditor
              step={selectedStep}
              stepIndex={selectedStepIndex}
              onChange={updateSelectedStep}
            />
          </div>

          <div className="min-h-0 overflow-auto border-l border-slate-200 dark:border-slate-800">
            <MacroValidationPanel validation={validation} />
            <MacroDryRunPanel result={result} />
            <MacroRunResultPanel result={result} />
          </div>
        </div>
      )}
    </div>
  );
};

function TabButton(props: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      className={[
        'h-8 rounded px-3 text-xs',
        props.active
          ? 'bg-blue-600 text-white'
          : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700',
      ].join(' ')}
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
}
