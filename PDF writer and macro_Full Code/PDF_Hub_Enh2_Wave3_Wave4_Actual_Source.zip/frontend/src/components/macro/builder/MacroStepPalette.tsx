import React, { useState } from 'react';
import type {
  MacroStep,
} from '@/core/macro/types';
import {
  getMacroOpsByCategory,
  type MacroOpSchema,
} from '@/core/macro/schema/opSchema';

export interface MacroStepPaletteProps {
  onAddStep: (op: MacroStep['op']) => void;
}

export const MacroStepPalette: React.FC<MacroStepPaletteProps> = ({
  onAddStep,
}) => {
  const grouped = getMacroOpsByCategory();
  const [query, setQuery] = useState('');

  const groups = Object.entries(grouped) as Array<[MacroOpSchema['category'], MacroOpSchema[]]>;

  return (
    <div className="p-3 space-y-3">
      <div>
        <div className="text-sm font-semibold">Step Palette</div>
        <div className="text-xs text-slate-500">Add operations to the recipe.</div>
      </div>

      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search operation..."
        className="h-8 w-full rounded border border-slate-300 bg-white px-2 text-xs dark:border-slate-700 dark:bg-slate-950"
      />

      <div className="space-y-4">
        {groups.map(([category, schemas]) => {
          const visible = schemas.filter((schema) =>
            [schema.label, schema.op, schema.description, schema.category]
              .join(' ')
              .toLowerCase()
              .includes(query.trim().toLowerCase()),
          );

          if (visible.length === 0) return null;

          return (
            <section key={category}>
              <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                {category}
              </div>

              <div className="space-y-2">
                {visible.map((schema) => (
                  <button
                    key={schema.op}
                    type="button"
                    className="w-full rounded border border-slate-200 p-2 text-left hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-900"
                    onClick={() => onAddStep(schema.op)}
                  >
                    <div className="text-xs font-medium">{schema.label}</div>
                    <div className="mt-0.5 text-[11px] text-slate-500">
                      {schema.description}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
};
