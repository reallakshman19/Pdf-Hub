import React from 'react';
import { describe, expect, it, beforeEach, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MacroRecipeBuilder } from './MacroRecipeBuilder';
import type {
  MacroExecutionContext,
} from '@/core/macro/types';

const executionContext: MacroExecutionContext = {
  workingBytes: new Uint8Array([1, 2, 3]),
  pageCount: 1,
  selectedPages: [],
  currentPage: 1,
  fileName: 'sample.pdf',
  options: {
    abortOnError: true,
  },
};

describe('MacroRecipeBuilder phase I', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('renders builder shell', () => {
    render(<MacroRecipeBuilder />);

    expect(screen.getByText('Macro Recipe Builder')).toBeTruthy();
    expect(screen.getByText('Step Palette')).toBeTruthy();
    expect(screen.getByText('Recipe Steps')).toBeTruthy();
    expect(screen.getByText('Validation')).toBeTruthy();
  });

  it('adds a step from palette', () => {
    render(<MacroRecipeBuilder />);

    fireEvent.click(screen.getByText('Select Pages'));

    expect(screen.getByText(/Step 1: Select Pages/)).toBeTruthy();
  });

  it('renames recipe', () => {
    const onRecipeChange = vi.fn();

    render(<MacroRecipeBuilder onRecipeChange={onRecipeChange} />);

    const input = screen.getByDisplayValue('Untitled Macro Recipe');

    fireEvent.change(input, {
      target: {
        value: 'My Recipe',
      },
    });

    expect(onRecipeChange).toHaveBeenCalled();
  });

  it('opens recipe browser', () => {
    render(<MacroRecipeBuilder />);

    fireEvent.click(screen.getByText('Recipes'));

    expect(screen.getByText('Recipe Browser')).toBeTruthy();
  });

  it('opens import export panel', () => {
    render(<MacroRecipeBuilder />);

    fireEvent.click(screen.getByText('Import/Export'));

    expect(screen.getByText('Export Recipe JSON')).toBeTruthy();
    expect(screen.getByText('Import Recipe JSON')).toBeTruthy();
  });

  it('runs dry-run through execution context', async () => {
    const onRunResult = vi.fn();

    render(
      <MacroRecipeBuilder
        executionContext={executionContext}
        onRunResult={onRunResult}
        initialRecipe={{
          id: 'r1',
          name: 'Recipe',
          steps: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        }}
      />,
    );

    fireEvent.click(screen.getByText('Dry Run'));

    await waitFor(() => expect(onRunResult).toHaveBeenCalled());

    const result = onRunResult.mock.calls[0][0];
    expect(result.success).toBe(true);
    expect(result.logs.some((line: string) => line.includes('dry-run'))).toBe(true);
  });

  it('does not run invalid recipe', async () => {
    const onRunResult = vi.fn();

    render(
      <MacroRecipeBuilder
        executionContext={executionContext}
        onRunResult={onRunResult}
        initialRecipe={{
          id: 'bad',
          name: 'Bad',
          steps: [
            {
              op: 'select_pages',
              selector: {
                mode: 'explicit',
                pages: [0],
              },
            },
          ],
        }}
      />,
    );

    fireEvent.click(screen.getByText('Dry Run'));

    await waitFor(() =>
      expect(screen.getByText(/Recipe is invalid/i)).toBeTruthy(),
    );

    expect(onRunResult).not.toHaveBeenCalled();
  });
});
