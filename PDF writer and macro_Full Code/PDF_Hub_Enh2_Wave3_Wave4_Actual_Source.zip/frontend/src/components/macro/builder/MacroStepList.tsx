import React from 'react';
import type {
  MacroStep,
} from '@/core/macro/types';
import {
  getMacroOpSchema,
} from '@/core/macro/schema/opSchema';

export interface MacroStepListProps {
  steps: MacroStep[];
  selectedIndex: number | null;
  onSelect: (index: number) => void;
  onMove: (from: number, to: number) => void;
  onDuplicate: (index: number) => void;
  onRemove: (index: number) => void;
}

export const MacroStepList: React.FC<MacroStepListProps> = ({
  steps,
  selectedIndex,
  onSelect,
  onMove,
  onDuplicate,
  onRemove,
}) => {
  return (
    <div className="p-3 space-y-3">
      <div>
        <div className="text-sm font-semibold">Recipe Steps</div>
        <div className="text-xs text-slate-500">{steps.length} step(s)</div>
      </div>

      {steps.length === 0 && (
        <div className="rounded border border-dashed border-slate-300 p-4 text-sm text-slate-500 dark:border-slate-700">
          Add a step from the palette.
        </div>
      )}

      <div className="space-y-2">
        {steps.map((step, index) => {
          const label = safeLabel(step);

          return (
            <div
              key={`${index}-${step.op}`}
              className={[
                'rounded border p-2',
                selectedIndex === index
                  ? 'border-blue-400 bg-blue-50 dark:bg-blue-950/30'
                  : 'border-slate-200 dark:border-slate-800',
              ].join(' ')}
            >
              <button
                type="button"
                className="w-full text-left"
                onClick={() => onSelect(index)}
              >
                <div className="text-sm font-medium">
                  {index + 1}. {label}
                </div>
                <div className="text-[11px] text-slate-500">{step.op}</div>
              </button>

              <div className="mt-2 flex flex-wrap gap-1">
                <MiniButton disabled={index === 0} onClick={() => onMove(index, index - 1)}>
                  Up
                </MiniButton>
                <MiniButton disabled={index === steps.length - 1} onClick={() => onMove(index, index + 1)}>
                  Down
                </MiniButton>
                <MiniButton onClick={() => onDuplicate(index)}>Duplicate</MiniButton>
                <MiniButton danger onClick={() => onRemove(index)}>Remove</MiniButton>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

function safeLabel(step: MacroStep): string {
  try {
    return getMacroOpSchema(step.op).label;
  } catch {
    return step.op;
  }
}

function MiniButton(props: {
  disabled?: boolean;
  danger?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      disabled={props.disabled}
      className={[
        'h-6 rounded px-2 text-[11px] disabled:cursor-not-allowed disabled:opacity-50',
        props.danger
          ? 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300'
          : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700',
      ].join(' ')}
      onClick={props.onClick}
    >
      {props.children}
    </button>
  );
}
