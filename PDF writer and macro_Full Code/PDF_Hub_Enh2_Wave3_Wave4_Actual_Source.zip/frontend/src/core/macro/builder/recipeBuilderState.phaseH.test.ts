import { describe, expect, it } from 'vitest';
import {
  appendDefaultMacroStep,
  cloneMacroRecipe,
  createEmptyMacroRecipe,
  duplicateMacroStep,
  insertMacroStep,
  moveMacroStep,
  removeMacroStep,
  renameMacroRecipe,
  setMacroRecipeDryRun,
  updateMacroStep,
  validateMacroRecipeWithSchema,
} from './recipeBuilderState';

describe('macro recipe builder state phase H', () => {
  it('creates empty recipe', () => {
    const recipe = createEmptyMacroRecipe();

    expect(recipe.steps).toEqual([]);
    expect(recipe.dryRun).toBe(true);
  });

  it('inserts, updates, duplicates, moves, and removes step', () => {
    let recipe = createEmptyMacroRecipe();

    recipe = insertMacroStep(recipe, 0, {
      op: 'select_pages',
      selector: { mode: 'current' },
    });

    expect(recipe.steps.length).toBe(1);

    recipe = updateMacroStep(recipe, 0, {
      op: 'select_pages',
      selector: { mode: 'all' },
    });

    expect(recipe.steps[0]).toEqual({
      op: 'select_pages',
      selector: { mode: 'all' },
    });

    recipe = duplicateMacroStep(recipe, 0);
    expect(recipe.steps.length).toBe(2);

    recipe = moveMacroStep(recipe, 0, 1);
    expect(recipe.steps.length).toBe(2);

    recipe = removeMacroStep(recipe, 1);
    expect(recipe.steps.length).toBe(1);
  });

  it('appends default step', () => {
    const recipe = appendDefaultMacroStep(createEmptyMacroRecipe(), 'draw_text_on_pages');

    expect(recipe.steps[0].op).toBe('draw_text_on_pages');
  });

  it('renames and toggles dryRun', () => {
    let recipe = createEmptyMacroRecipe();

    recipe = renameMacroRecipe(recipe, 'New Name');
    recipe = setMacroRecipeDryRun(recipe, false);

    expect(recipe.name).toBe('New Name');
    expect(recipe.dryRun).toBe(false);
  });

  it('clones recipe', () => {
    const recipe = appendDefaultMacroStep(createEmptyMacroRecipe(), 'select_pages');
    const clone = cloneMacroRecipe(recipe);

    expect(clone).toEqual(recipe);
    expect(clone).not.toBe(recipe);
  });

  it('validates required fields', () => {
    const invalid = validateMacroRecipeWithSchema({
      id: 'bad',
      name: '',
      steps: [],
    });

    expect(invalid.valid).toBe(false);

    const valid = validateMacroRecipeWithSchema({
      id: 'good',
      name: 'Good',
      steps: [
        {
          op: 'select_pages',
          selector: { mode: 'current' },
        },
      ],
    });

    expect(valid.valid).toBe(true);
  });

  it('rejects invalid nested conditional op', () => {
    const result = validateMacroRecipeWithSchema({
      id: 'bad-nested',
      name: 'Bad Nested Conditional',
      steps: [
        {
          op: 'conditional',
          condition: {
            type: 'page_count_gt',
            value: 1,
          },
          then: [
            {
              op: 'not_registered',
            } as never,
          ],
          else: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        },
      ],
    });

    expect(result.valid).toBe(false);
    expect(result.issues.some((issue) =>
      issue.field.includes('then') &&
      issue.field.includes('op') &&
      issue.message.includes('No macro op schema registered')
    )).toBe(true);
  });

  it('rejects invalid nested conditional step fields', () => {
    const result = validateMacroRecipeWithSchema({
      id: 'bad-nested-fields',
      name: 'Bad Nested Fields',
      steps: [
        {
          op: 'conditional',
          condition: {
            type: 'page_count_gt',
            value: 1,
          },
          then: [
            {
              op: 'place_rich_textbox',
              x: 10,
              y: 10,
              width: -5,
              content: 'Invalid width',
            },
          ],
        },
      ],
    });

    expect(result.valid).toBe(false);
    expect(result.issues.some((issue) =>
      issue.field.includes('then') &&
      issue.field.includes('width')
    )).toBe(true);
  });

  it('accepts valid nested conditional steps', () => {
    const result = validateMacroRecipeWithSchema({
      id: 'good-nested',
      name: 'Good Nested Conditional',
      steps: [
        {
          op: 'conditional',
          condition: {
            type: 'page_count_gt',
            value: 1,
          },
          then: [
            {
              op: 'select_pages',
              selector: { mode: 'all' },
            },
          ],
          else: [
            {
              op: 'select_pages',
              selector: { mode: 'current' },
            },
          ],
        },
      ],
    });

    expect(result.valid).toBe(true);
    expect(result.issues).toEqual([]);
  });
});
