import { describe, expect, it } from 'vitest';
import {
  getBuiltInMacroRecipes,
  getMacroRecipesByCategory,
  getRecommendedMacroRecipes,
} from './builtInRecipes';
import {
  validateMacroRecipeWithSchema,
} from '../builder/recipeBuilderState';

describe('macro built-in recipes phase H', () => {
  it('has target built-in recipe count', () => {
    const recipes = getBuiltInMacroRecipes();

    expect(recipes.length).toBeGreaterThanOrEqual(20);
  });

  it('has unique recipe ids', () => {
    const recipes = getBuiltInMacroRecipes();
    const ids = recipes.map((recipe) => recipe.id);

    expect(new Set(ids).size).toBe(ids.length);
  });

  it('has recommended recipes', () => {
    expect(getRecommendedMacroRecipes().length).toBeGreaterThan(0);
  });

  it('filters by category', () => {
    expect(getMacroRecipesByCategory('document-control').length).toBeGreaterThan(0);
    expect(getMacroRecipesByCategory('review').length).toBeGreaterThan(0);
  });

  it('every built-in recipe schema-validates', () => {
    const recipes = getBuiltInMacroRecipes();

    for (const item of recipes) {
      const result = validateMacroRecipeWithSchema(item.recipe);

      expect(result.issues).toEqual([]);
    }
  });
});
