import { beforeEach, describe, expect, it } from 'vitest';
import type {
  MacroRecipe,
} from '../types';
import {
  deleteCustomMacroRecipe,
  exportMacroRecipeJson,
  importMacroRecipeJson,
  loadCustomMacroRecipes,
  upsertCustomMacroRecipe,
} from './recipeStorage';

const sampleRecipe = (): MacroRecipe => ({
  id: 'custom-1',
  name: 'Custom Recipe',
  steps: [
    {
      op: 'select_pages',
      selector: { mode: 'current' },
    },
  ],
});

describe('macro recipe storage phase H', () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it('loads empty safely', () => {
    expect(loadCustomMacroRecipes()).toEqual([]);
  });

  it('saves and loads custom recipe', () => {
    upsertCustomMacroRecipe(sampleRecipe());

    const loaded = loadCustomMacroRecipes();

    expect(loaded.length).toBe(1);
    expect(loaded[0].id).toBe('custom-1');
    expect(loaded[0].version).toBe(1);
  });

  it('deletes custom recipe', () => {
    upsertCustomMacroRecipe(sampleRecipe());

    const afterDelete = deleteCustomMacroRecipe('custom-1');

    expect(afterDelete).toEqual([]);
    expect(loadCustomMacroRecipes()).toEqual([]);
  });

  it('exports and imports JSON', () => {
    const json = exportMacroRecipeJson(sampleRecipe());
    const imported = importMacroRecipeJson(json);

    expect(imported.id).toBe('custom-1');
    expect(imported.steps[0].op).toBe('select_pages');
  });

  it('rejects invalid import JSON', () => {
    expect(() => importMacroRecipeJson('{bad')).toThrow(/Invalid macro recipe JSON/);
  });

  it('rejects invalid imported recipe', () => {
    expect(() => importMacroRecipeJson(JSON.stringify({
      id: 'bad',
      name: '',
      steps: [],
    }))).toThrow(/invalid/i);
  });
});
