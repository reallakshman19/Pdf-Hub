import type {
  MacroRecipe,
  MacroStep,
} from '../types';

export type MacroRecipeCatalogCategory =
  | 'page-cleanup'
  | 'review'
  | 'stamps'
  | 'tables'
  | 'document-control'
  | 'authoring';

export interface MacroRecipeCatalogItem {
  id: string;
  name: string;
  description: string;
  category: MacroRecipeCatalogCategory;
  tags: string[];
  recipe: MacroRecipe;
  requiredOps: MacroStep['op'][];
  recommended?: boolean;
}

function recipe(
  id: string,
  name: string,
  steps: MacroStep[],
  dryRun = true,
): MacroRecipe {
  return {
    id,
    name,
    dryRun,
    steps,
  };
}

const reviewTable = () => ({
  columns: [
    { id: 'item', label: 'Item' },
    { id: 'status', label: 'Status' },
    { id: 'remarks', label: 'Remarks' },
  ],
  rows: [
    {
      id: 'r1',
      cells: [
        { id: 'c1', text: 'Drawing number checked' },
        { id: 'c2', text: '' },
        { id: 'c3', text: '' },
      ],
    },
    {
      id: 'r2',
      cells: [
        { id: 'c4', text: 'Revision checked' },
        { id: 'c5', text: '' },
        { id: 'c6', text: '' },
      ],
    },
    {
      id: 'r3',
      cells: [
        { id: 'c7', text: 'Attachments checked' },
        { id: 'c8', text: '' },
        { id: 'c9', text: '' },
      ],
    },
  ],
  style: {
    borderColor: '#d1d5db',
    headerBg: '#f1f5f9',
    fontSize: 10,
  },
});

export const BUILT_IN_MACRO_RECIPES: MacroRecipeCatalogItem[] = [
  {
    id: 'builtin-page-numbers-footer',
    name: 'Add Page Numbers Footer',
    description: 'Adds centered page numbering to all pages.',
    category: 'document-control',
    tags: ['footer', 'page-number', 'document-control'],
    recommended: true,
    requiredOps: ['header_footer_text'],
    recipe: recipe('builtin-page-numbers-footer', 'Add Page Numbers Footer', [
      {
        op: 'header_footer_text',
        selector: { mode: 'all' },
        zone: 'footer',
        text: 'Page {{current_page}} of {{page_count}}',
        align: 'center',
        marginX: 36,
        marginY: 24,
        fontSize: 10,
        color: '#475569',
        opacity: 1,
        pageNumberToken: true,
      },
    ]),
  },
  {
    id: 'builtin-file-name-header',
    name: 'Add File Name Header',
    description: 'Adds file name in the page header.',
    category: 'document-control',
    tags: ['header', 'filename'],
    recommended: true,
    requiredOps: ['header_footer_text'],
    recipe: recipe('builtin-file-name-header', 'Add File Name Header', [
      {
        op: 'header_footer_text',
        selector: { mode: 'all' },
        zone: 'header',
        text: '{{filename}}',
        align: 'left',
        marginX: 36,
        marginY: 24,
        fontSize: 10,
        color: '#475569',
        opacity: 1,
        fileNameToken: true,
      },
    ]),
  },
  {
    id: 'builtin-draft-watermark',
    name: 'DRAFT Watermark',
    description: 'Adds DRAFT text to every page.',
    category: 'stamps',
    tags: ['watermark', 'draft'],
    recommended: true,
    requiredOps: ['draw_text_on_pages'],
    recipe: recipe('builtin-draft-watermark', 'DRAFT Watermark', [
      {
        op: 'draw_text_on_pages',
        selector: { mode: 'all' },
        text: 'DRAFT',
        x: 180,
        y: 360,
        fontSize: 54,
        color: '#ef4444',
        opacity: 0.16,
        align: 'center',
      },
    ]),
  },
  {
    id: 'builtin-reviewed-current-page',
    name: 'Reviewed Stamp — Current Page',
    description: 'Adds a reviewed stamp to the current page.',
    category: 'review',
    tags: ['review', 'stamp'],
    recommended: true,
    requiredOps: ['draw_text_on_pages'],
    recipe: recipe('builtin-reviewed-current-page', 'Reviewed Stamp — Current Page', [
      {
        op: 'draw_text_on_pages',
        selector: { mode: 'current' },
        text: 'REVIEWED {{date}}',
        x: 380,
        y: 72,
        fontSize: 14,
        color: '#15803d',
        opacity: 1,
        dateToken: true,
      },
    ]),
  },
  {
    id: 'builtin-review-checklist-table',
    name: 'Review Checklist Table',
    description: 'Places a review checklist table on the current page.',
    category: 'tables',
    tags: ['review', 'table', 'checklist'],
    recommended: true,
    requiredOps: ['place_table'],
    recipe: recipe('builtin-review-checklist-table', 'Review Checklist Table', [
      {
        op: 'place_table',
        x: 72,
        y: 140,
        width: 420,
        tableData: reviewTable(),
      },
    ]),
  },
  {
    id: 'builtin-engineering-note-box',
    name: 'Engineering Note Box',
    description: 'Adds a note box for engineering comments.',
    category: 'authoring',
    tags: ['note', 'engineering'],
    recommended: true,
    requiredOps: ['place_rich_textbox'],
    recipe: recipe('builtin-engineering-note-box', 'Engineering Note Box', [
      {
        op: 'place_rich_textbox',
        x: 72,
        y: 120,
        width: 360,
        height: 100,
        content: '<p><strong>Engineering Note:</strong></p><p>Add comment here.</p>',
        styles: {
          fontFamily: 'Arial',
          fontSize: 12,
          color: '#111827',
          backgroundColor: '#f8fafc',
        },
      },
    ]),
  },
  {
    id: 'builtin-rotate-selected-90',
    name: 'Rotate Selected Pages 90°',
    description: 'Rotates selected pages by 90 degrees.',
    category: 'page-cleanup',
    tags: ['rotate', 'pages'],
    requiredOps: ['rotate_pages'],
    recipe: recipe('builtin-rotate-selected-90', 'Rotate Selected Pages 90°', [
      {
        op: 'rotate_pages',
        selector: { mode: 'selected' },
        degrees: 90,
      },
    ]),
  },
  {
    id: 'builtin-duplicate-selected-pages',
    name: 'Duplicate Selected Pages',
    description: 'Duplicates currently selected pages.',
    category: 'page-cleanup',
    tags: ['duplicate', 'pages'],
    requiredOps: ['duplicate_pages'],
    recipe: recipe('builtin-duplicate-selected-pages', 'Duplicate Selected Pages', [
      {
        op: 'duplicate_pages',
        selector: { mode: 'selected' },
      },
    ]),
  },
  {
    id: 'builtin-extract-current-page',
    name: 'Extract Current Page',
    description: 'Extracts current page to an output PDF.',
    category: 'document-control',
    tags: ['extract', 'current-page'],
    requiredOps: ['extract_pages'],
    recipe: recipe('builtin-extract-current-page', 'Extract Current Page', [
      {
        op: 'extract_pages',
        selector: { mode: 'current' },
        outputName: 'current-page.pdf',
      },
    ]),
  },
  {
    id: 'builtin-insert-a4-blank-end',
    name: 'Insert A4 Blank Page at End',
    description: 'Inserts one A4 blank page at the end.',
    category: 'page-cleanup',
    tags: ['blank-page', 'insert'],
    requiredOps: ['insert_blank_page'],
    recipe: recipe('builtin-insert-a4-blank-end', 'Insert A4 Blank Page at End', [
      {
        op: 'insert_blank_page',
        position: { mode: 'end' },
        size: 'a4',
        count: 1,
      },
    ]),
  },
  {
    id: 'builtin-confidential-footer',
    name: 'Confidential Footer',
    description: 'Adds confidential footer text.',
    category: 'document-control',
    tags: ['footer', 'confidential'],
    requiredOps: ['header_footer_text'],
    recipe: recipe('builtin-confidential-footer', 'Confidential Footer', [
      {
        op: 'header_footer_text',
        selector: { mode: 'all' },
        zone: 'footer',
        text: 'CONFIDENTIAL',
        align: 'right',
        marginX: 36,
        marginY: 24,
        fontSize: 9,
        color: '#b91c1c',
        opacity: 1,
      },
    ]),
  },
  {
    id: 'builtin-remove-selected-pages',
    name: 'Remove Selected Pages',
    description: 'Removes selected pages.',
    category: 'page-cleanup',
    tags: ['remove', 'pages'],
    requiredOps: ['remove_pages'],
    recipe: recipe('builtin-remove-selected-pages', 'Remove Selected Pages', [
      {
        op: 'remove_pages',
        selector: { mode: 'selected' },
      },
    ]),
  },
  {
    id: 'builtin-extract-selected-pages',
    name: 'Extract Selected Pages',
    description: 'Extracts selected pages into a separate output file.',
    category: 'document-control',
    tags: ['extract', 'selected'],
    requiredOps: ['extract_pages'],
    recipe: recipe('builtin-extract-selected-pages', 'Extract Selected Pages', [
      {
        op: 'extract_pages',
        selector: { mode: 'selected' },
        outputName: 'selected-pages.pdf',
      },
    ]),
  },
  {
    id: 'builtin-select-all-pages',
    name: 'Select All Pages',
    description: 'Selects every page in the document.',
    category: 'page-cleanup',
    tags: ['select', 'all'],
    requiredOps: ['select_pages'],
    recipe: recipe('builtin-select-all-pages', 'Select All Pages', [
      {
        op: 'select_pages',
        selector: { mode: 'all' },
      },
    ]),
  },
  {
    id: 'builtin-select-current-page',
    name: 'Select Current Page',
    description: 'Selects only the current page.',
    category: 'page-cleanup',
    tags: ['select', 'current'],
    requiredOps: ['select_pages'],
    recipe: recipe('builtin-select-current-page', 'Select Current Page', [
      {
        op: 'select_pages',
        selector: { mode: 'current' },
      },
    ]),
  },
  {
    id: 'builtin-add-reviewer-var',
    name: 'Set Reviewer Variable',
    description: 'Sets reviewer template variable for later recipes.',
    category: 'review',
    tags: ['template', 'reviewer'],
    requiredOps: ['apply_template_vars'],
    recipe: recipe('builtin-add-reviewer-var', 'Set Reviewer Variable', [
      {
        op: 'apply_template_vars',
        vars: {
          reviewer: 'LK',
        },
      },
    ]),
  },
  {
    id: 'builtin-reviewed-by-var',
    name: 'Reviewed By Variable Stamp',
    description: 'Sets reviewer variable and stamps it on current page.',
    category: 'review',
    tags: ['review', 'template', 'stamp'],
    requiredOps: ['apply_template_vars', 'draw_text_on_pages'],
    recipe: recipe('builtin-reviewed-by-var', 'Reviewed By Variable Stamp', [
      {
        op: 'apply_template_vars',
        vars: {
          reviewer: 'LK',
        },
      },
      {
        op: 'draw_text_on_pages',
        selector: { mode: 'current' },
        text: 'Reviewed by {{reviewer}}',
        x: 72,
        y: 72,
        fontSize: 12,
        color: '#15803d',
        opacity: 1,
      },
    ]),
  },
  {
    id: 'builtin-conditional-page-count',
    name: 'Conditional Page Count Selector',
    description: 'Selects all pages if document has more than one page; otherwise current page.',
    category: 'document-control',
    tags: ['conditional', 'select'],
    requiredOps: ['conditional'],
    recipe: recipe('builtin-conditional-page-count', 'Conditional Page Count Selector', [
      {
        op: 'conditional',
        condition: {
          type: 'page_count_gt',
          value: 1,
        },
        then: [
          {
            op: 'select_pages',
            selector: { mode: 'all' },
          },
        ],
        else: [
          {
            op: 'select_pages',
            selector: { mode: 'current' },
          },
        ],
      },
    ]),
  },
  {
    id: 'builtin-title-block-note',
    name: 'Title Block Note',
    description: 'Adds a small title-block note.',
    category: 'authoring',
    tags: ['note', 'title-block'],
    requiredOps: ['place_rich_textbox'],
    recipe: recipe('builtin-title-block-note', 'Title Block Note', [
      {
        op: 'place_rich_textbox',
        x: 360,
        y: 680,
        width: 180,
        height: 48,
        content: '<p>Checked against latest revision.</p>',
        styles: {
          fontFamily: 'Arial',
          fontSize: 9,
          color: '#111827',
        },
      },
    ]),
  },
  {
    id: 'builtin-action-item-table',
    name: 'Action Item Table',
    description: 'Adds a small action item tracking table.',
    category: 'tables',
    tags: ['table', 'action'],
    requiredOps: ['place_table'],
    recipe: recipe('builtin-action-item-table', 'Action Item Table', [
      {
        op: 'place_table',
        x: 72,
        y: 180,
        width: 480,
        tableData: {
          columns: [
            { id: 'no', label: 'No.' },
            { id: 'action', label: 'Action' },
            { id: 'owner', label: 'Owner' },
            { id: 'due', label: 'Due' },
          ],
          rows: [
            {
              id: 'r1',
              cells: [
                { id: 'c1', text: '1' },
                { id: 'c2', text: '' },
                { id: 'c3', text: '' },
                { id: 'c4', text: '' },
              ],
            },
          ],
          style: {
            borderColor: '#d1d5db',
            headerBg: '#f1f5f9',
            fontSize: 10,
          },
        },
      },
    ]),
  },
];

export function getBuiltInMacroRecipes(): MacroRecipeCatalogItem[] {
  return JSON.parse(JSON.stringify(BUILT_IN_MACRO_RECIPES)) as MacroRecipeCatalogItem[];
}

export function getRecommendedMacroRecipes(): MacroRecipeCatalogItem[] {
  return getBuiltInMacroRecipes().filter((item) => item.recommended);
}

export function getMacroRecipesByCategory(
  category: MacroRecipeCatalogCategory,
): MacroRecipeCatalogItem[] {
  return getBuiltInMacroRecipes().filter((item) => item.category === category);
}
