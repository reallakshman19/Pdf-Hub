import type {
  MacroRecipe,
} from '../types';
import {
  validateMacroRecipeWithSchema,
} from '../builder/recipeBuilderState';

const STORAGE_KEY = 'pdfhub.macro.customRecipes.v1';

export interface StoredMacroRecipe extends MacroRecipe {
  createdAt: number;
  updatedAt: number;
  version: 1;
}

export function loadCustomMacroRecipes(): StoredMacroRecipe[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw) as unknown;

    if (!Array.isArray(parsed)) return [];

    return parsed
      .filter(isStoredMacroRecipe)
      .filter((recipe) => validateMacroRecipeWithSchema(recipe).valid);
  } catch {
    return [];
  }
}

export function saveCustomMacroRecipes(recipes: StoredMacroRecipe[]): void {
  if (typeof window === 'undefined') return;

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(recipes));
}

export function upsertCustomMacroRecipe(recipe: MacroRecipe): StoredMacroRecipe[] {
  const validation = validateMacroRecipeWithSchema(recipe);

  if (!validation.valid) {
    throw new Error(`Cannot save invalid macro recipe: ${validation.issues[0]?.message ?? 'unknown issue'}`);
  }

  const now = Date.now();
  const existing = loadCustomMacroRecipes();
  const previous = existing.find((item) => item.id === recipe.id);

  const stored: StoredMacroRecipe = {
    ...JSON.parse(JSON.stringify(recipe)),
    createdAt: previous?.createdAt ?? now,
    updatedAt: now,
    version: 1,
  };

  const next = [
    ...existing.filter((item) => item.id !== recipe.id),
    stored,
  ].sort((a, b) => b.updatedAt - a.updatedAt);

  saveCustomMacroRecipes(next);

  return next;
}

export function deleteCustomMacroRecipe(recipeId: string): StoredMacroRecipe[] {
  const next = loadCustomMacroRecipes().filter((recipe) => recipe.id !== recipeId);
  saveCustomMacroRecipes(next);
  return next;
}

export function exportMacroRecipeJson(recipe: MacroRecipe): string {
  const validation = validateMacroRecipeWithSchema(recipe);

  if (!validation.valid) {
    throw new Error(`Cannot export invalid macro recipe: ${validation.issues[0]?.message ?? 'unknown issue'}`);
  }

  return JSON.stringify(recipe, null, 2);
}

export function importMacroRecipeJson(json: string): MacroRecipe {
  let parsed: unknown;

  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error('Invalid macro recipe JSON.');
  }

  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Imported macro recipe must be an object.');
  }

  const recipe = parsed as MacroRecipe;
  const validation = validateMacroRecipeWithSchema(recipe);

  if (!validation.valid) {
    throw new Error(`Imported macro recipe is invalid: ${validation.issues[0]?.message ?? 'unknown issue'}`);
  }

  return recipe;
}

function isStoredMacroRecipe(value: unknown): value is StoredMacroRecipe {
  if (!value || typeof value !== 'object') return false;

  const recipe = value as StoredMacroRecipe;

  return (
    typeof recipe.id === 'string' &&
    typeof recipe.name === 'string' &&
    Array.isArray(recipe.steps) &&
    typeof recipe.createdAt === 'number' &&
    typeof recipe.updatedAt === 'number' &&
    recipe.version === 1
  );
}
