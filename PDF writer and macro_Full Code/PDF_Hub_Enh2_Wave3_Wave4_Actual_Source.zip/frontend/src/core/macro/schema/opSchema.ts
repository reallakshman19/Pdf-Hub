import type {
  MacroStep,
  PageSelector,
  InsertPosition,
  MacroTableData,
} from '../types';

export type MacroFieldType =
  | 'text'
  | 'textarea'
  | 'number'
  | 'color'
  | 'boolean'
  | 'select'
  | 'page-selector'
  | 'insert-position'
  | 'string-list'
  | 'number-list'
  | 'json'
  | 'table-data'
  | 'content-blocks';

export interface MacroOpFieldSchema {
  key: string;
  label: string;
  type: MacroFieldType;
  required?: boolean;
  min?: number;
  max?: number;
  help?: string;
  options?: Array<{ label: string; value: string | number | boolean }>;
}

export interface MacroOpSchema {
  op: MacroStep['op'];
  label: string;
  category: 'pages' | 'content' | 'files' | 'logic' | 'templates' | 'authoring';
  description: string;
  fields: MacroOpFieldSchema[];
  defaultStep: () => MacroStep;
}

const currentSelector = (): PageSelector => ({ mode: 'current' });
const selectedSelector = (): PageSelector => ({ mode: 'selected' });
const allSelector = (): PageSelector => ({ mode: 'all' });
const endPosition = (): InsertPosition => ({ mode: 'end' });

const defaultTable = (): MacroTableData => ({
  columns: [
    { id: 'col-1', label: 'Item' },
    { id: 'col-2', label: 'Status' },
    { id: 'col-3', label: 'Remarks' },
  ],
  rows: [
    {
      id: 'row-1',
      cells: [
        { id: 'cell-1', text: 'Drawing number checked' },
        { id: 'cell-2', text: '' },
        { id: 'cell-3', text: '' },
      ],
    },
    {
      id: 'row-2',
      cells: [
        { id: 'cell-4', text: 'Revision checked' },
        { id: 'cell-5', text: '' },
        { id: 'cell-6', text: '' },
      ],
    },
  ],
  style: {
    borderColor: '#d1d5db',
    headerBg: '#f1f5f9',
    fontSize: 10,
  },
});

export const MACRO_OP_SCHEMAS: MacroOpSchema[] = [
  {
    op: 'select_pages',
    label: 'Select Pages',
    category: 'pages',
    description: 'Select current, selected, all, range, or explicit pages for later macro steps.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
    ],
    defaultStep: () => ({
      op: 'select_pages',
      selector: currentSelector(),
    }),
  },
  {
    op: 'rotate_pages',
    label: 'Rotate Pages',
    category: 'pages',
    description: 'Rotate pages by a fixed degree value.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      {
        key: 'degrees',
        label: 'Degrees',
        type: 'select',
        required: true,
        options: [
          { label: '90°', value: 90 },
          { label: '180°', value: 180 },
          { label: '270°', value: 270 },
        ],
      },
    ],
    defaultStep: () => ({
      op: 'rotate_pages',
      selector: selectedSelector(),
      degrees: 90,
    }),
  },
  {
    op: 'extract_pages',
    label: 'Extract Pages',
    category: 'files',
    description: 'Extract matching pages to a separate output file.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      { key: 'outputName', label: 'Output name', type: 'text', required: false },
    ],
    defaultStep: () => ({
      op: 'extract_pages',
      selector: currentSelector(),
      outputName: 'extracted-pages.pdf',
    }),
  },
  {
    op: 'split_pages',
    label: 'Split Pages',
    category: 'files',
    description: 'Split matching pages into an output while removing them from the working document.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      { key: 'outputName', label: 'Output name', type: 'text', required: false },
    ],
    defaultStep: () => ({
      op: 'split_pages',
      selector: selectedSelector(),
      outputName: 'split-pages.pdf',
    }),
  },
  {
    op: 'duplicate_pages',
    label: 'Duplicate Pages',
    category: 'pages',
    description: 'Duplicate selected or matching pages.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
    ],
    defaultStep: () => ({
      op: 'duplicate_pages',
      selector: selectedSelector(),
    }),
  },
  {
    op: 'remove_pages',
    label: 'Remove Pages',
    category: 'pages',
    description: 'Remove selected or matching pages.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
    ],
    defaultStep: () => ({
      op: 'remove_pages',
      selector: selectedSelector(),
    }),
  },
  {
    op: 'insert_blank_page',
    label: 'Insert Blank Page',
    category: 'pages',
    description: 'Insert one or more blank pages.',
    fields: [
      { key: 'position', label: 'Position', type: 'insert-position', required: true },
      {
        key: 'size',
        label: 'Size',
        type: 'select',
        required: false,
        options: [
          { label: 'Match current', value: 'match-current' },
          { label: 'A4', value: 'a4' },
          { label: 'Letter', value: 'letter' },
        ],
      },
      { key: 'count', label: 'Count', type: 'number', min: 1, required: false },
    ],
    defaultStep: () => ({
      op: 'insert_blank_page',
      position: endPosition(),
      size: 'match-current',
      count: 1,
    }),
  },
  {
    op: 'replace_page',
    label: 'Replace Page',
    category: 'files',
    description: 'Replace a page with a page from a donor file.',
    fields: [
      { key: 'targetPage', label: 'Target page', type: 'number', min: 1, required: true },
      { key: 'donorFileId', label: 'Donor file ID', type: 'text', required: true },
      { key: 'donorPage', label: 'Donor page', type: 'number', min: 1, required: true },
    ],
    defaultStep: () => ({
      op: 'replace_page',
      targetPage: 1,
      donorFileId: 'donor',
      donorPage: 1,
    }),
  },
  {
    op: 'reorder_pages',
    label: 'Reorder Pages',
    category: 'pages',
    description: 'Reorder document pages using an explicit page order.',
    fields: [
      { key: 'order', label: 'Page order', type: 'number-list', required: true },
    ],
    defaultStep: () => ({
      op: 'reorder_pages',
      order: [1],
    }),
  },
  {
    op: 'draw_text_on_pages',
    label: 'Draw Text On Pages',
    category: 'content',
    description: 'Draw plain text at a fixed page coordinate.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      { key: 'text', label: 'Text', type: 'textarea', required: true },
      { key: 'x', label: 'X', type: 'number', min: 0, required: true },
      { key: 'y', label: 'Y', type: 'number', min: 0, required: true },
      { key: 'fontSize', label: 'Font size', type: 'number', min: 1, required: true },
      { key: 'color', label: 'Color', type: 'color', required: false },
      { key: 'opacity', label: 'Opacity', type: 'number', min: 0, max: 1, required: false },
    ],
    defaultStep: () => ({
      op: 'draw_text_on_pages',
      selector: currentSelector(),
      text: 'Text',
      x: 72,
      y: 72,
      fontSize: 12,
      color: '#111827',
      opacity: 1,
      align: 'left',
    }),
  },
  {
    op: 'header_footer_text',
    label: 'Header / Footer Text',
    category: 'content',
    description: 'Add repeated header or footer text.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      {
        key: 'zone',
        label: 'Zone',
        type: 'select',
        required: true,
        options: [
          { label: 'Header', value: 'header' },
          { label: 'Footer', value: 'footer' },
        ],
      },
      { key: 'text', label: 'Text', type: 'textarea', required: true },
      {
        key: 'align',
        label: 'Alignment',
        type: 'select',
        required: true,
        options: [
          { label: 'Left', value: 'left' },
          { label: 'Center', value: 'center' },
          { label: 'Right', value: 'right' },
        ],
      },
      { key: 'marginX', label: 'Margin X', type: 'number', min: 0, required: true },
      { key: 'marginY', label: 'Margin Y', type: 'number', min: 0, required: true },
      { key: 'fontSize', label: 'Font size', type: 'number', min: 1, required: true },
      { key: 'color', label: 'Color', type: 'color', required: false },
      { key: 'opacity', label: 'Opacity', type: 'number', min: 0, max: 1, required: false },
      { key: 'excludeFirstPage', label: 'Exclude first page', type: 'boolean', required: false },
      { key: 'excludeLastPage', label: 'Exclude last page', type: 'boolean', required: false },
    ],
    defaultStep: () => ({
      op: 'header_footer_text',
      selector: allSelector(),
      zone: 'footer',
      text: 'Page {{current_page}} of {{page_count}}',
      align: 'center',
      marginX: 36,
      marginY: 24,
      fontSize: 10,
      color: '#475569',
      opacity: 1,
      excludeFirstPage: false,
      excludeLastPage: false,
      pageNumberToken: true,
    }),
  },
  {
    op: 'inject_rich_text',
    label: 'Inject Rich Text',
    category: 'content',
    description: 'Place rich text-like formatted text on selected pages.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: true },
      { key: 'text', label: 'Text', type: 'textarea', required: true },
      { key: 'x', label: 'X', type: 'number', min: 0, required: true },
      { key: 'y', label: 'Y', type: 'number', min: 0, required: true },
      { key: 'width', label: 'Width', type: 'number', min: 1, required: false },
      { key: 'height', label: 'Height', type: 'number', min: 1, required: false },
      { key: 'fontSize', label: 'Font size', type: 'number', min: 1, required: true },
      { key: 'fontFamily', label: 'Font family', type: 'text', required: false },
      { key: 'fontWeight', label: 'Font weight', type: 'text', required: false },
      { key: 'fontStyle', label: 'Font style', type: 'text', required: false },
      { key: 'color', label: 'Color', type: 'color', required: false },
      { key: 'opacity', label: 'Opacity', type: 'number', min: 0, max: 1, required: false },
    ],
    defaultStep: () => ({
      op: 'inject_rich_text',
      selector: currentSelector(),
      text: 'Rich text note',
      x: 72,
      y: 120,
      width: 360,
      height: 90,
      fontSize: 12,
      fontFamily: 'Arial',
      color: '#111827',
      opacity: 1,
      textAlign: 'left',
    }),
  },
  {
    op: 'place_rich_textbox',
    label: 'Place Rich Textbox',
    category: 'authoring',
    description: 'Place a rich textbox. Selector is optional; current page is used by UI when omitted.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: false },
      { key: 'x', label: 'X', type: 'number', min: 0, required: true },
      { key: 'y', label: 'Y', type: 'number', min: 0, required: true },
      { key: 'width', label: 'Width', type: 'number', min: 1, required: true },
      { key: 'height', label: 'Height', type: 'number', min: 1, required: false },
      { key: 'content', label: 'Content HTML', type: 'textarea', required: true },
      { key: 'styles', label: 'Styles', type: 'json', required: false },
    ],
    defaultStep: () => ({
      op: 'place_rich_textbox',
      x: 72,
      y: 120,
      width: 360,
      height: 90,
      content: '<p>New rich textbox</p>',
      styles: {
        fontFamily: 'Arial',
        fontSize: 12,
        color: '#111827',
      },
    }),
  },
  {
    op: 'place_table',
    label: 'Place Table',
    category: 'authoring',
    description: 'Place a structured table. Selector is optional; current page is used by UI when omitted.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: false },
      { key: 'x', label: 'X', type: 'number', min: 0, required: true },
      { key: 'y', label: 'Y', type: 'number', min: 0, required: true },
      { key: 'width', label: 'Width', type: 'number', min: 1, required: true },
      { key: 'tableData', label: 'Table data', type: 'table-data', required: true },
    ],
    defaultStep: () => ({
      op: 'place_table',
      x: 72,
      y: 160,
      width: 420,
      tableData: defaultTable(),
    }),
  },
  {
    op: 'adjust_image',
    label: 'Adjust / Place Image',
    category: 'authoring',
    description: 'Place or adjust an image. Selector is optional.',
    fields: [
      { key: 'selector', label: 'Selector', type: 'page-selector', required: false },
      { key: 'x', label: 'X', type: 'number', min: 0, required: true },
      { key: 'y', label: 'Y', type: 'number', min: 0, required: true },
      { key: 'width', label: 'Width', type: 'number', min: 1, required: true },
      { key: 'height', label: 'Height', type: 'number', min: 1, required: true },
      { key: 'opacity', label: 'Opacity', type: 'number', min: 0, max: 1, required: false },
      { key: 'borderWidth', label: 'Border width', type: 'number', min: 0, required: false },
      { key: 'borderColor', label: 'Border color', type: 'color', required: false },
      { key: 'rotation', label: 'Rotation', type: 'number', required: false },
      { key: 'base64Image', label: 'Base64 image', type: 'textarea', required: false },
      { key: 'donorFileId', label: 'Donor file ID', type: 'text', required: false },
    ],
    defaultStep: () => ({
      op: 'adjust_image',
      x: 72,
      y: 120,
      width: 240,
      height: 160,
      opacity: 1,
      borderWidth: 0,
      rotation: 0,
    }),
  },
  {
    op: 'apply_template_vars',
    label: 'Apply Template Variables',
    category: 'templates',
    description: 'Set template variables for later steps.',
    fields: [
      { key: 'vars', label: 'Variables', type: 'json', required: true },
    ],
    defaultStep: () => ({
      op: 'apply_template_vars',
      vars: {
        reviewer: 'LK',
      },
    }),
  },
  {
    op: 'conditional',
    label: 'Conditional',
    category: 'logic',
    description: 'Run nested steps depending on a condition.',
    fields: [
      { key: 'condition', label: 'Condition', type: 'json', required: true },
      { key: 'then', label: 'Then steps', type: 'json', required: true },
      { key: 'else', label: 'Else steps', type: 'json', required: false },
    ],
    defaultStep: () => ({
      op: 'conditional',
      condition: {
        type: 'page_count_gt',
        value: 1,
      },
      then: [
        {
          op: 'select_pages',
          selector: allSelector(),
        },
      ],
      else: [
        {
          op: 'select_pages',
          selector: currentSelector(),
        },
      ],
    }),
  },
];

export const OP_SCHEMA_BY_OP: Record<MacroStep['op'], MacroOpSchema> =
  MACRO_OP_SCHEMAS.reduce((acc, schema) => {
    acc[schema.op] = schema;
    return acc;
  }, {} as Record<MacroStep['op'], MacroOpSchema>);

export function getMacroOpSchema(op: MacroStep['op']): MacroOpSchema {
  const schema = OP_SCHEMA_BY_OP[op];

  if (!schema) {
    throw new Error(`No macro op schema registered for ${op}`);
  }

  return schema;
}

export function getMacroOpsByCategory(): Record<MacroOpSchema['category'], MacroOpSchema[]> {
  return MACRO_OP_SCHEMAS.reduce((acc, schema) => {
    acc[schema.category] ??= [];
    acc[schema.category].push(schema);
    return acc;
  }, {
    pages: [],
    content: [],
    files: [],
    logic: [],
    templates: [],
    authoring: [],
  } as Record<MacroOpSchema['category'], MacroOpSchema[]>);
}

export function createDefaultStep(op: MacroStep['op']): MacroStep {
  return getMacroOpSchema(op).defaultStep();
}
