import { describe, expect, it } from 'vitest';
import {
  createDefaultStep,
  getMacroOpSchema,
  getMacroOpsByCategory,
  MACRO_OP_SCHEMAS,
} from './opSchema';
import {
  validateMacroSchemaCoverage,
} from './schemaCoverage';

describe('macro op schema phase H', () => {
  it('has unique schemas', () => {
    const ops = MACRO_OP_SCHEMAS.map((schema) => schema.op);

    expect(new Set(ops).size).toBe(ops.length);
  });

  it('covers supported macro ops', () => {
    const coverage = validateMacroSchemaCoverage();

    expect(coverage.ok).toBe(true);
    expect(coverage.duplicateOps).toEqual([]);
    expect(coverage.missingOps).toEqual([]);
  });

  it('createDefaultStep returns matching op', () => {
    for (const schema of MACRO_OP_SCHEMAS) {
      const step = createDefaultStep(schema.op);

      expect(step.op).toBe(schema.op);
    }
  });

  it('getMacroOpSchema works', () => {
    expect(getMacroOpSchema('select_pages').op).toBe('select_pages');
  });

  it('category grouping works', () => {
    const grouped = getMacroOpsByCategory();

    expect(grouped.pages.length).toBeGreaterThan(0);
    expect(grouped.content.length).toBeGreaterThan(0);
    expect(grouped.authoring.length).toBeGreaterThan(0);
  });
});
