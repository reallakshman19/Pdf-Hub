import type {
  MacroStep,
} from '../types';
import {
  MACRO_OP_SCHEMAS,
} from './opSchema';

export interface MacroSchemaCoverageResult {
  ok: boolean;
  duplicateOps: string[];
  missingOps: string[];
  schemaOps: string[];
}

export const SUPPORTED_MACRO_OPS: MacroStep['op'][] = [
  'select_pages',
  'rotate_pages',
  'extract_pages',
  'split_pages',
  'duplicate_pages',
  'remove_pages',
  'insert_blank_page',
  'replace_page',
  'reorder_pages',
  'draw_text_on_pages',
  'header_footer_text',
  'inject_rich_text',
  'place_rich_textbox',
  'place_table',
  'adjust_image',
  'apply_template_vars',
  'conditional',
];

export function validateMacroSchemaCoverage(): MacroSchemaCoverageResult {
  const schemaOps = MACRO_OP_SCHEMAS.map((schema) => schema.op);
  const duplicateOps = schemaOps.filter((op, index) => schemaOps.indexOf(op) !== index);
  const missingOps = SUPPORTED_MACRO_OPS.filter((op) => !schemaOps.includes(op));

  return {
    ok: duplicateOps.length === 0 && missingOps.length === 0,
    duplicateOps,
    missingOps,
    schemaOps,
  };
}
