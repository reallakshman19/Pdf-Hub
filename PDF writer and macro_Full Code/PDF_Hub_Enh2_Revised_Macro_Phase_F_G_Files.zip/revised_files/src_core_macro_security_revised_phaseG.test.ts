import { describe, expect, it } from 'vitest';
import {
  safeMacroFontFamily,
} from './security';
import {
  createContentDiagnostics,
} from './steps/content-ops';
import {
  validateMacroRecipe,
} from './validator';
import './register-all';

describe('macro security phase G revised patches', () => {
  it('font family blocks url expression and javascript payloads', () => {
    expect(safeMacroFontFamily('Arial; background:url(javascript:alert(1))')).toBe('Arial');
    expect(safeMacroFontFamily('Arial expression(alert(1))')).toBe('Arial');
    expect(safeMacroFontFamily('Arial javascript:alert(1)')).toBe('Arial');
    expect(safeMacroFontFamily('Arial')).toBe('Arial');
  });

  it('unsafe image diagnostic returns error', () => {
    const result = createContentDiagnostics({
      op: 'adjust_image',
      x: 0,
      y: 0,
      width: 100,
      height: 100,
      base64Image: 'javascript:alert(1)',
    });

    expect(result.status).toBe('error');
    expect(result.message).toContain('Unsafe image source blocked');
  });

  it('validator rejects unsafe base64Image', () => {
    const result = validateMacroRecipe({
      id: 'bad-image',
      name: 'Bad Image',
      steps: [
        {
          op: 'adjust_image',
          x: 0,
          y: 0,
          width: 100,
          height: 100,
          base64Image: 'javascript:alert(1)',
        },
      ],
    });

    expect(result.valid).toBe(false);
    expect(result.issues.some((issue) => issue.field === 'base64Image')).toBe(true);
  });
});
