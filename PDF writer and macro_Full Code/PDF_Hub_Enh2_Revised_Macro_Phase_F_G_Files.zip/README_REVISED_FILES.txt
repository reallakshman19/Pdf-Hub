PDF_HUB_ENH2 — REVISED MACRO PHASE F/G FILES
============================================

This ZIP contains the corrected Phase F/G macro files after certification review.

Copy map:

  revised_files/src_core_macro_side_effects.ts
    -> frontend/src/core/macro/side-effects.ts

  revised_files/src_core_macro_executor.ts
    -> frontend/src/core/macro/executor.ts

  revised_files/src_core_macro_steps_logic_ops.ts
    -> frontend/src/core/macro/steps/logic-ops.ts

  revised_files/src_core_macro_steps_page_ops.ts
    -> frontend/src/core/macro/steps/page-ops.ts

  revised_files/src_core_macro_security.ts
    -> frontend/src/core/macro/security.ts

  revised_files/src_core_macro_steps_content_ops.ts
    -> frontend/src/core/macro/steps/content-ops.ts

  revised_files/src_core_macro_validation_op_validators.ts
    -> frontend/src/core/macro/validation/op-validators.ts

  revised_files/src_core_macro_security_revised_phaseG.test.ts
    -> frontend/src/core/macro/security.revised.phaseG.test.ts

After copying:
  cd frontend
  npm run typecheck
  npx vitest run src/core/macro/executor.phaseF.test.ts src/core/macro/transaction.phaseF.test.ts
  npx vitest run src/core/macro/validator.phaseG.test.ts src/core/macro/security.phaseG.test.ts
  npx vitest run src/core/macro/security.revised.phaseG.test.ts
  npm run build

Expected:
  Phase F: PASS
  Phase G: PASS
