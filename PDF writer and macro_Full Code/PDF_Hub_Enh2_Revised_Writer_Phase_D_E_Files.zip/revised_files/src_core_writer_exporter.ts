import type {
  PlacedElement,
  WriterImageModel,
  WriterRichTextModel,
  WriterTableModel,
} from './types';
import {
  richTextModelToPlainText,
} from './richTextHtml';
import {
  visibleWriterElementsForExport,
} from './writerObjects';

export interface WriterExportPageSize {
  width: number;
  height: number;
}

export interface WriterExportOptions {
  fileName?: string;
  pageCount: number;
  pageSizes?: Record<number, WriterExportPageSize>;
  defaultPageSize?: WriterExportPageSize;
  flattenPdf?: boolean;
}

export interface WriterExportPlan {
  visibleElements: PlacedElement[];
  hiddenSkipped: number;
  pages: Record<number, PlacedElement[]>;
  warnings: string[];
}

export interface WriterExportResult {
  bytes?: Uint8Array;
  html?: string;
  plan: WriterExportPlan;
  warnings: string[];
}

export function createWriterExportPlan(
  elements: PlacedElement[],
  options: WriterExportOptions,
): WriterExportPlan {
  const visibleElements = visibleWriterElementsForExport(elements)
    .filter((element) => element.pageNumber >= 1 && element.pageNumber <= options.pageCount)
    .sort((a, b) => {
      if (a.pageNumber !== b.pageNumber) return a.pageNumber - b.pageNumber;
      return (a.zIndex ?? 0) - (b.zIndex ?? 0);
    });

  const pages: Record<number, PlacedElement[]> = {};
  const warnings: string[] = [];

  for (let page = 1; page <= options.pageCount; page += 1) {
    pages[page] = [];
  }

  for (const element of visibleElements) {
    if (!pages[element.pageNumber]) {
      warnings.push(`Element ${element.id} has invalid page ${element.pageNumber}; skipped.`);
      continue;
    }

    if (!element.contentModel) {
      warnings.push(`Element ${element.id} has no contentModel; legacy content fallback used.`);
    }

    pages[element.pageNumber].push(element);
  }

  return {
    visibleElements,
    hiddenSkipped: elements.length - visibleElements.length,
    pages,
    warnings,
  };
}

export async function exportWriterDocument(
  input: {
    originalPdfBytes?: Uint8Array;
    elements: PlacedElement[];
    options: WriterExportOptions;
  },
): Promise<WriterExportResult> {
  const plan = createWriterExportPlan(input.elements, input.options);

  if (input.options.flattenPdf && input.originalPdfBytes) {
    try {
      const bytes = await flattenWriterElementsToPdf(
        input.originalPdfBytes,
        plan,
        input.options,
      );

      return {
        bytes,
        plan,
        warnings: [...plan.warnings],
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);

      return {
        html: exportWriterElementsToHtml(plan, input.options),
        plan,
        warnings: [
          ...plan.warnings,
          `PDF flattening failed; HTML export returned instead. ${message}`,
        ],
      };
    }
  }

  return {
    html: exportWriterElementsToHtml(plan, input.options),
    plan,
    warnings: [...plan.warnings],
  };
}

export function exportWriterElementsToHtml(
  plan: WriterExportPlan,
  options: WriterExportOptions,
): string {
  const defaultSize = options.defaultPageSize ?? { width: 612, height: 792 };
  const pages: string[] = [];

  for (let page = 1; page <= options.pageCount; page += 1) {
    const size = options.pageSizes?.[page] ?? defaultSize;
    const elements = plan.pages[page] ?? [];

    pages.push(`
      <section class="writer-page" data-page="${page}" style="position:relative;width:${size.width}px;height:${size.height}px;background:white;margin:16px auto;box-shadow:0 1px 8px rgba(15,23,42,.18);">
        ${elements.map(renderElementHtml).join('\n')}
      </section>
    `);
  }

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>${escapeHtml(options.fileName ?? 'writer-export')}</title>
<style>
  body { margin:0; background:#e5e7eb; font-family:Arial, sans-serif; }
  table { border-collapse: collapse; }
  td, th { vertical-align: top; }
</style>
</head>
<body>
${pages.join('\n')}
</body>
</html>`;
}

export async function flattenWriterElementsToPdf(
  originalPdfBytes: Uint8Array,
  plan: WriterExportPlan,
  options: WriterExportOptions,
): Promise<Uint8Array> {
  void options;

  const pdfLib = await importPdfLibRuntime();
  const { PDFDocument, StandardFonts, rgb, degrees } = pdfLib;

  const pdfDoc = await PDFDocument.load(originalPdfBytes);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pages = pdfDoc.getPages();

  for (const [pageNumberText, elements] of Object.entries(plan.pages)) {
    const pageNumber = Number(pageNumberText);
    const page = pages[pageNumber - 1];

    if (!page) continue;

    const pageHeight = page.getHeight();

    for (const element of elements) {
      if (element.hidden) continue;

      if (element.contentModel?.kind === 'rich-text') {
        drawRichTextElement({
          pdfLib,
          page,
          font,
          boldFont,
          element,
          pageHeight,
          model: element.contentModel,
        });
        continue;
      }

      if (element.contentModel?.kind === 'table') {
        drawTableElement({
          pdfLib,
          page,
          font,
          boldFont,
          element,
          pageHeight,
          model: element.contentModel,
        });
        continue;
      }

      if (element.contentModel?.kind === 'image') {
        await drawImageElement({
          pdfDoc,
          page,
          element,
          pageHeight,
          model: element.contentModel,
          degrees,
        });
        continue;
      }

      drawLegacyTextElement({
        pdfLib,
        page,
        font,
        element,
        pageHeight,
      });
    }
  }

  const saved = await pdfDoc.save();
  return saved instanceof Uint8Array ? saved : new Uint8Array(saved);
}

function drawRichTextElement(input: {
  pdfLib: Record<string, unknown>;
  page: any;
  font: any;
  boldFont: any;
  element: PlacedElement;
  pageHeight: number;
  model: WriterRichTextModel;
}): void {
  const { rgb } = input.pdfLib as {
    rgb: (r: number, g: number, b: number) => unknown;
  };

  const fontSize = input.element.style?.fontSize ?? 12;
  const color = cssColorToRgb(input.element.style?.color ?? '#111827', rgb);
  const text = richTextModelToPlainText(input.model);
  const lines = wrapText(text, Math.max(1, input.element.width), fontSize);

  lines.forEach((line, index) => {
    input.page.drawText(line, {
      x: input.element.x,
      y: input.pageHeight - input.element.y - fontSize - index * (fontSize + 3),
      size: fontSize,
      font: input.element.style?.fontWeight === 'bold' ? input.boldFont : input.font,
      color,
      opacity: input.element.style?.opacity ?? 1,
    });
  });
}

function drawLegacyTextElement(input: {
  pdfLib: Record<string, unknown>;
  page: any;
  font: any;
  element: PlacedElement;
  pageHeight: number;
}): void {
  const { rgb } = input.pdfLib as {
    rgb: (r: number, g: number, b: number) => unknown;
  };

  const fontSize = input.element.style?.fontSize ?? 12;
  const color = cssColorToRgb(input.element.style?.color ?? '#111827', rgb);
  const lines = wrapText(input.element.content ?? '', Math.max(1, input.element.width), fontSize);

  lines.forEach((line, index) => {
    input.page.drawText(line, {
      x: input.element.x,
      y: input.pageHeight - input.element.y - fontSize - index * (fontSize + 3),
      size: fontSize,
      font: input.font,
      color,
      opacity: input.element.style?.opacity ?? 1,
    });
  });
}

function drawTableElement(input: {
  pdfLib: Record<string, unknown>;
  page: any;
  font: any;
  boldFont: any;
  element: PlacedElement;
  pageHeight: number;
  model: WriterTableModel;
}): void {
  const { rgb } = input.pdfLib as {
    rgb: (r: number, g: number, b: number) => unknown;
  };

  const rows = input.model.rows;
  const columns = input.model.columns;
  const colCount = Math.max(1, columns.length);
  const rowHeight = 20;
  const colWidth = input.element.width / colCount;
  const fontSize = input.model.style?.fontSize ?? 9;
  const borderColor = cssColorToRgb(input.model.style?.borderColor ?? '#d1d5db', rgb);

  rows.forEach((row, rowIndex) => {
    row.cells.forEach((cell, colIndex) => {
      const x = input.element.x + colIndex * colWidth;
      const yTop = input.element.y + rowIndex * rowHeight;
      const y = input.pageHeight - yTop - rowHeight;

      input.page.drawRectangle({
        x,
        y,
        width: colWidth,
        height: rowHeight,
        borderColor,
        borderWidth: input.model.style?.borderWidth ?? 1,
        opacity: 1,
      });

      input.page.drawText(String(cell.text ?? '').slice(0, 120), {
        x: x + 3,
        y: y + rowHeight - fontSize - 4,
        size: fontSize,
        font: cell.style?.bold || rowIndex === 0 ? input.boldFont : input.font,
        color: cssColorToRgb(cell.style?.color ?? '#111827', rgb),
      });
    });
  });
}

async function drawImageElement(input: {
  pdfDoc: any;
  page: any;
  element: PlacedElement;
  pageHeight: number;
  model: WriterImageModel;
  degrees: (angle: number) => unknown;
}): Promise<void> {
  if (!/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(input.model.src)) {
    return;
  }

  const imageBytes = dataUrlToBytes(input.model.src);
  const isPng = /^data:image\/png/i.test(input.model.src);
  const embedded = isPng
    ? await input.pdfDoc.embedPng(imageBytes)
    : await input.pdfDoc.embedJpg(imageBytes);

  input.page.drawImage(embedded, {
    x: input.element.x,
    y: input.pageHeight - input.element.y - input.element.height,
    width: input.element.width,
    height: input.element.height,
    rotate: input.degrees(input.model.rotation ?? 0),
    opacity: input.model.opacity ?? input.element.style?.opacity ?? 1,
  });
}

function renderElementHtml(element: PlacedElement): string {
  if (element.hidden) return '';

  const style = [
    'position:absolute',
    `left:${safeNumber(element.x)}px`,
    `top:${safeNumber(element.y)}px`,
    `width:${Math.max(1, safeNumber(element.width))}px`,
    `height:${Math.max(1, safeNumber(element.height))}px`,
    `z-index:${Math.floor(element.zIndex ?? 0)}`,
    `opacity:${clamp01(element.style?.opacity ?? 1)}`,
    `background:${escapeStyle(element.style?.backgroundColor ?? 'transparent')}`,
    `border:${Math.max(0, element.style?.borderWidth ?? 0)}px solid ${escapeStyle(element.style?.borderColor ?? 'transparent')}`,
    'overflow:hidden',
    'box-sizing:border-box',
  ].join(';');

  if (element.contentModel?.kind === 'image') {
    const image = element.contentModel;

    if (!/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(image.src)) {
      return `<div style="${style};color:#b91c1c;font-size:12px;padding:4px;">Unsafe image source blocked.</div>`;
    }

    return `<div style="${style}"><img alt="${escapeAttr(image.alt ?? '')}" src="${escapeAttr(image.src)}" style="width:100%;height:100%;object-fit:contain;transform:rotate(${safeNumber(image.rotation ?? 0)}deg);opacity:${clamp01(image.opacity ?? 1)};" /></div>`;
  }

  if (element.contentModel?.kind === 'table') {
    return `<div style="${style}">${renderTableHtml(element.contentModel)}</div>`;
  }

  const text = element.contentModel?.kind === 'rich-text'
    ? richTextModelToPlainText(element.contentModel)
    : element.content;

  return `<div style="${style};font-family:${escapeStyle(element.style?.fontFamily ?? 'Arial')};font-size:${safeNumber(element.style?.fontSize ?? 12)}px;color:${escapeStyle(element.style?.color ?? '#111827')};white-space:pre-wrap;padding:${safeNumber(element.style?.padding ?? 2)}px;">${escapeHtml(text)}</div>`;
}

function renderTableHtml(model: WriterTableModel): string {
  const borderColor = escapeStyle(model.style?.borderColor ?? '#d1d5db');
  const fontSize = safeNumber(model.style?.fontSize ?? 10);

  const rows = model.rows.map((row, rowIndex) => {
    const cells = row.cells.map((cell) => {
      const tag = rowIndex === 0 ? 'th' : 'td';

      return `<${tag} style="border:1px solid ${borderColor};padding:${safeNumber(model.style?.cellPadding ?? 4)}px;font-size:${fontSize}px;text-align:${escapeStyle(cell.style?.align ?? 'left')};color:${escapeStyle(cell.style?.color ?? '#111827')};background:${escapeStyle(cell.style?.backgroundColor ?? (rowIndex === 0 ? model.style?.headerBackgroundColor ?? '#f1f5f9' : 'transparent'))};">${escapeHtml(cell.text)}</${tag}>`;
    }).join('');

    return `<tr>${cells}</tr>`;
  }).join('');

  return `<table style="width:100%;height:100%;border-collapse:collapse;">${rows}</table>`;
}

async function importPdfLibRuntime(): Promise<any> {
  const dynamicImport = new Function('specifier', 'return import(specifier)') as (specifier: string) => Promise<any>;
  return dynamicImport('pdf-lib');
}

function dataUrlToBytes(dataUrl: string): Uint8Array {
  const base64 = dataUrl.split(',')[1] ?? '';

  if (typeof atob !== 'function') {
    throw new Error('Base64 decode is not available in this runtime.');
  }

  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);

  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }

  return bytes;
}

function wrapText(text: string, width: number, fontSize: number): string[] {
  const maxChars = Math.max(1, Math.floor(width / Math.max(4, fontSize * 0.55)));
  const rawLines = String(text ?? '').replace(/\r\n/g, '\n').split('\n');
  const out: string[] = [];

  for (const rawLine of rawLines) {
    let line = rawLine;

    while (line.length > maxChars) {
      out.push(line.slice(0, maxChars));
      line = line.slice(maxChars);
    }

    out.push(line);
  }

  return out;
}

function cssColorToRgb(
  color: string,
  rgb: (r: number, g: number, b: number) => unknown,
): unknown {
  const value = String(color ?? '').trim();

  const hex = /^#([0-9a-fA-F]{6})$/.exec(value);
  if (hex) {
    const int = Number.parseInt(hex[1], 16);
    return rgb(
      ((int >> 16) & 255) / 255,
      ((int >> 8) & 255) / 255,
      (int & 255) / 255,
    );
  }

  return rgb(0.067, 0.094, 0.153);
}

function safeNumber(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : 0;
}

function clamp01(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 1;
  return Math.max(0, Math.min(1, value));
}

function escapeHtml(value: unknown): string {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function escapeAttr(value: unknown): string {
  return escapeHtml(value).replaceAll('`', '');
}

function escapeStyle(value: unknown): string {
  return String(value ?? '').replace(/[<>"'`]/g, '');
}
