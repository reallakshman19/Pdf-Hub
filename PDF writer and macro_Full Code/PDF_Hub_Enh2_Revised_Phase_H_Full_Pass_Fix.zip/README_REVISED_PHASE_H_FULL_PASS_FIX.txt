PDF_HUB_ENH2 — REVISED PHASE H FULL PASS FIX
============================================

This ZIP contains the required fix requested after Phase H certification.

Files:
  revised_files/src_core_macro_builder_recipeBuilderState.ts
    -> copy to frontend/src/core/macro/builder/recipeBuilderState.ts

  revised_files/src_core_macro_builder_recipeBuilderState_phaseH_test.ts
    -> copy to frontend/src/core/macro/builder/recipeBuilderState.phaseH.test.ts

  PHASE_H_FULL_PASS_PATCH.txt
    -> patch description

  PHASE_H_CERTIFICATION_UPDATE.txt
    -> certification status after patch

After copying:
  cd frontend
  npm run typecheck
  npx vitest run src/core/macro/schema/opSchema.phaseH.test.ts
  npx vitest run src/core/macro/builder/recipeBuilderState.phaseH.test.ts
  npx vitest run src/core/macro/recipes/builtInRecipes.phaseH.test.ts
  npx vitest run src/core/macro/recipes/recipeStorage.phaseH.test.ts
  npm run build

Expected:
  Phase H: PASS
